'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_SKILL_BYTES = 256 * 1024;

function ensureDirectory(directory) {
  if (fs.existsSync(directory)) return;
  const parent = path.dirname(directory);
  if (parent && parent !== directory) ensureDirectory(parent);
  try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
}
function makeId(name) {
  const slug = String(name || 'skill').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'skill';
  return `${slug}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
}
function hash(content) { return crypto.createHash('sha256').update(String(content || ''), 'utf8').digest('hex'); }
function validateContent(content) {
  const text = String(content == null ? '' : content).replace(/^\uFEFF/, '');
  if (!text.trim()) throw new Error('Skill 内容为空');
  if (Buffer.byteLength(text, 'utf8') > MAX_SKILL_BYTES) throw new Error('Skill 超过 256 KB 限制');
  return text;
}
function readUtf8(filePath) {
  const buffer = fs.readFileSync(filePath);
  if (buffer.length > MAX_SKILL_BYTES) throw new Error('Skill 超过 256 KB 限制');
  const content = buffer.toString('utf8').replace(/^\uFEFF/, '');
  if (content.includes('\uFFFD')) throw new Error('Skill 不是有效的 UTF-8 Markdown');
  return validateContent(content);
}

class AgentSkillStore {
  constructor(options) {
    options = options || {};
    this.root = path.resolve(options.root);
    this.bundledRoot = options.bundledRoot ? path.resolve(options.bundledRoot) : '';
    this.indexFile = path.join(this.root, 'skills.json');
    this.filesRoot = path.join(this.root, 'files');
    this.versionsRoot = path.join(this.root, 'versions');
    this.state = { schemaVersion: 1, activeSkillId: '', skills: [] };
  }

  ensure() { ensureDirectory(this.root); ensureDirectory(this.filesRoot); ensureDirectory(this.versionsRoot); }

  load() {
    this.ensure();
    if (fs.existsSync(this.indexFile)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(this.indexFile, 'utf8').replace(/^\uFEFF/, ''));
        if (parsed && Array.isArray(parsed.skills)) this.state = Object.assign(this.state, parsed);
      } catch (_) {}
    }
    this.loadBundled();
    this.state.skills = this.state.skills.filter(skill => skill.readOnly || fs.existsSync(skill.path));
    if (!this.state.skills.some(skill => skill.id === this.state.activeSkillId)) this.state.activeSkillId = this.state.skills.length ? this.state.skills[0].id : '';
    this.save();
    return this.state;
  }

  loadBundled() {
    if (!this.bundledRoot || !fs.existsSync(this.bundledRoot)) return;
    for (const name of fs.readdirSync(this.bundledRoot)) {
      if (path.extname(name).toLowerCase() !== '.md') continue;
      const filePath = path.join(this.bundledRoot, name);
      const content = readUtf8(filePath);
      const id = `builtin-${crypto.createHash('sha1').update(name).digest('hex').slice(0, 12)}`;
      const existing = this.state.skills.find(skill => skill.id === id);
      const record = { id, name: path.basename(name, path.extname(name)), path: filePath, version: 1, hash: hash(content), readOnly: true, updatedAt: fs.statSync(filePath).mtimeMs };
      if (existing) Object.assign(existing, record);
      else this.state.skills.push(record);
    }
  }

  save() {
    this.ensure();
    fs.writeFileSync(this.indexFile, `${JSON.stringify(this.state, null, 2)}\n`, 'utf8');
  }

  list() { return this.state.skills.map(skill => Object.assign({}, skill)); }
  find(id) { return this.state.skills.find(skill => skill.id === id) || null; }

  get(id) {
    const record = this.find(id);
    if (!record || !fs.existsSync(record.path)) return null;
    const content = readUtf8(record.path);
    return Object.assign({}, record, { content, hash: hash(content) });
  }

  getActive() { return this.get(this.state.activeSkillId); }

  activate(id) {
    if (!this.find(id)) throw new Error('Skill 不存在');
    this.state.activeSkillId = id;
    this.save();
    return this.getActive();
  }

  importFile(filePath, name) {
    if (path.extname(String(filePath || '')).toLowerCase() !== '.md') throw new Error('仅支持 .md Skill 文件');
    const content = readUtf8(filePath);
    const id = makeId(name || path.basename(filePath, path.extname(filePath)));
    const target = path.join(this.filesRoot, `${id}.md`);
    fs.writeFileSync(target, content, 'utf8');
    const record = { id, name: String(name || path.basename(filePath, path.extname(filePath))).trim() || '未命名 Skill', path: target, version: 1, hash: hash(content), readOnly: false, updatedAt: Date.now() };
    this.state.skills.push(record);
    this.state.activeSkillId = id;
    this.save();
    return this.get(id);
  }

  duplicate(id) {
    const source = this.get(id);
    if (!source) throw new Error('Skill 不存在');
    const newId = makeId(source.name);
    const target = path.join(this.filesRoot, `${newId}.md`);
    fs.writeFileSync(target, source.content, 'utf8');
    const record = { id: newId, name: `${source.name} 副本`, path: target, version: 1, hash: hash(source.content), readOnly: false, updatedAt: Date.now() };
    this.state.skills.push(record);
    this.state.activeSkillId = newId;
    this.save();
    return this.get(newId);
  }

  update(id, content, name) {
    const record = this.find(id);
    if (!record) throw new Error('Skill 不存在');
    if (record.readOnly) throw new Error('内置 Skill 为只读，请先复制为自定义 Skill');
    const text = validateContent(content);
    const nextVersion = Math.max(1, Number(record.version) || 1) + 1;
    const versionRoot = path.join(this.versionsRoot, record.id);
    ensureDirectory(versionRoot);
    if (fs.existsSync(record.path)) fs.copyFileSync(record.path, path.join(versionRoot, `v${record.version}.md`));
    fs.writeFileSync(record.path, text, 'utf8');
    record.name = String(name || record.name).trim() || record.name;
    record.version = nextVersion;
    record.hash = hash(text);
    record.updatedAt = Date.now();
    this.save();
    return this.get(id);
  }

  exportFile(id, targetPath) {
    const skill = this.get(id);
    if (!skill) throw new Error('Skill 不存在');
    fs.writeFileSync(targetPath, skill.content, 'utf8');
    return targetPath;
  }

  remove(id) {
    const record = this.find(id);
    if (!record) return false;
    if (record.readOnly) throw new Error('内置 Skill 不能删除');
    try { if (fs.existsSync(record.path)) fs.unlinkSync(record.path); } catch (_) {}
    this.state.skills = this.state.skills.filter(skill => skill.id !== id);
    this.state.activeSkillId = this.state.skills.length ? this.state.skills[0].id : '';
    this.save();
    return true;
  }
}

module.exports = { AgentSkillStore, MAX_SKILL_BYTES, validateContent, readUtf8, hash };
