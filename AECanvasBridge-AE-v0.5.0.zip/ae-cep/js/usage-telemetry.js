'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const { buildUsageSnapshot } = require('./usage-analytics.js');

const MAX_OUTBOX_BYTES = 5 * 1024 * 1024;
const MAX_OUTBOX_AGE_MS = 30 * 24 * 60 * 60 * 1000;

function ensureDirectory(directory) {
  if (fs.existsSync(directory)) return;
  const parent = path.dirname(directory);
  if (parent && parent !== directory) ensureDirectory(parent);
  try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
}

function readJson(filePath, fallback) {
  try { return JSON.parse(fs.readFileSync(filePath, 'utf8')); }
  catch (_) { return fallback; }
}

function writeJsonAtomic(filePath, value) {
  ensureDirectory(path.dirname(filePath));
  const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temporary, filePath); }
  catch (error) {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
    fs.renameSync(temporary, filePath);
  }
}

function makeId(prefix) {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(8).toString('hex')}`;
}

function postJson(url, token, payload, timeoutMs) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const client = target.protocol === 'https:' ? https : http;
    const body = Buffer.from(JSON.stringify(payload));
    const request = client.request(target.toString(), {
      method: 'POST',
      timeout: timeoutMs || 15000,
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${String(token || '')}`,
        'Content-Type': 'application/json',
        'Content-Length': body.length,
        'User-Agent': 'AE-Canvas-Bridge-KIVI-Video-Dev'
      }
    }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(Buffer.from(chunk)));
      response.on('end', () => resolve({
        statusCode: response.statusCode || 0,
        body: Buffer.concat(chunks).toString('utf8')
      }));
    });
    request.on('error', reject);
    request.on('timeout', () => request.destroy(new Error('使用数据上报超时')));
    request.write(body);
    request.end();
  });
}

class UsageTelemetry {
  constructor(options) {
    const input = options || {};
    this.root = path.resolve(input.root);
    this.outboxRoot = path.join(this.root, 'outbox');
    this.rejectedRoot = path.join(this.root, 'rejected');
    this.configFile = path.join(this.root, 'config.json');
    this.transport = input.transport || postJson;
    this.endpoint = String(input.endpoint || '');
    this.token = String(input.token || '');
    this.timeoutMs = Number(input.timeoutMs) || 15000;
    this.consentVersion = String(input.consentVersion || '');
    this.defaultConsent = input.defaultConsent === 'unset' ? 'unset' : 'enabled';
    ensureDirectory(this.outboxRoot);
    ensureDirectory(this.rejectedRoot);
    this.config = Object.assign({
      schemaVersion: 1,
      consent: this.defaultConsent,
      installId: makeId('install'),
      updatedAt: Date.now()
    }, readJson(this.configFile, {}));
    if (!['unset', 'enabled', 'disabled'].includes(this.config.consent)) this.config.consent = 'unset';
    if (this.config.consent === 'unset' && this.defaultConsent === 'enabled') this.config.consent = 'enabled';
    if (!this.config.installId) this.config.installId = makeId('install');
    this.saveConfig();
    this.prune();
  }

  saveConfig() {
    this.config.updatedAt = Date.now();
    writeJsonAtomic(this.configFile, this.config);
  }

  setConsent(enabled) {
    this.config.consent = enabled ? 'enabled' : 'disabled';
    this.saveConfig();
    return this.config.consent;
  }

  consentState() {
    return this.config.consent;
  }

  isEnabled() {
    return this.config.consent === 'enabled';
  }

  isConfigured() {
    return /^https:\/\//i.test(this.endpoint) && !!this.token;
  }

  pendingFiles() {
    if (!fs.existsSync(this.outboxRoot)) return [];
    return fs.readdirSync(this.outboxRoot)
      .filter(name => /\.json$/i.test(name))
      .map(name => path.join(this.outboxRoot, name))
      .filter(filePath => fs.existsSync(filePath) && fs.statSync(filePath).isFile())
      .sort((left, right) => fs.statSync(left).mtimeMs - fs.statSync(right).mtimeMs);
  }

  prune(now) {
    const current = Number(now) || Date.now();
    let files = this.pendingFiles();
    files.forEach(filePath => {
      try {
        if (current - fs.statSync(filePath).mtimeMs > MAX_OUTBOX_AGE_MS) fs.unlinkSync(filePath);
      } catch (_) {}
    });
    files = this.pendingFiles();
    let bytes = files.reduce((sum, filePath) => sum + fs.statSync(filePath).size, 0);
    for (const filePath of files) {
      if (bytes <= MAX_OUTBOX_BYTES) break;
      try {
        const size = fs.statSync(filePath).size;
        fs.unlinkSync(filePath);
        bytes -= size;
      } catch (_) {}
    }
  }

  enqueue(snapshot) {
    if (!this.isEnabled()) return { queued: false, reason: 'consent-disabled' };
    const eventId = makeId('usage');
    const envelope = Object.assign({}, snapshot, {
      eventId,
      installId: this.config.installId,
      consentVersion: this.consentVersion
    });
    writeJsonAtomic(path.join(this.outboxRoot, `${eventId}.json`), envelope);
    this.prune();
    return { queued: true, eventId, envelope };
  }

  async capture(options) {
    if (!this.isEnabled()) return { queued: false, reason: 'consent-disabled' };
    const input = options || {};
    if (!input.client) throw new Error('使用统计缺少 KIVI 客户端');
    const results = await Promise.all([input.client.getUserInfo(), input.client.getQuota()]);
    const user = results[0] || {};
    const quota = results[1] || {};
    const snapshot = buildUsageSnapshot({
      jobs: input.jobs || [],
      identity: {
        username: user.username,
        realName: user.realName,
        departmentName: user.departmentName
      },
      quota,
      pluginVersion: input.pluginVersion,
      aeVersion: input.aeVersion,
      generatedAt: input.generatedAt
    });
    return this.enqueue(snapshot);
  }

  async flush() {
    if (!this.isEnabled()) return { sent: 0, pending: this.pendingFiles().length, reason: 'consent-disabled' };
    if (!this.endpoint || !this.token) return { sent: 0, pending: this.pendingFiles().length, reason: 'not-configured' };
    let sent = 0;
    for (const filePath of this.pendingFiles()) {
      const payload = readJson(filePath, null);
      if (!payload) {
        try { fs.renameSync(filePath, path.join(this.rejectedRoot, path.basename(filePath))); } catch (_) {}
        continue;
      }
      const response = await this.transport(this.endpoint, this.token, payload, this.timeoutMs);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        fs.unlinkSync(filePath);
        sent += 1;
        continue;
      }
      if (response.statusCode === 400 || response.statusCode === 422) {
        fs.renameSync(filePath, path.join(this.rejectedRoot, path.basename(filePath)));
        continue;
      }
      if (response.statusCode === 401 || response.statusCode === 403) {
        return { sent, pending: this.pendingFiles().length, reason: 'unauthorized' };
      }
      return { sent, pending: this.pendingFiles().length, reason: `http-${response.statusCode || 0}` };
    }
    return { sent, pending: this.pendingFiles().length };
  }
}

module.exports = {
  UsageTelemetry,
  MAX_OUTBOX_BYTES,
  MAX_OUTBOX_AGE_MS,
  postJson
};
