'use strict';

const fs = require('fs');
const http = require('http');
const crypto = require('crypto');

function ensureDirectory(directory) {
  if (fs.existsSync(directory)) return;
  const path = require('path');
  const parent = path.dirname(directory);
  if (parent && parent !== directory) ensureDirectory(parent);
  try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
}
const WebSocket = require('ws');

const PROTOCOL_VERSION = 1;
// The stable Canvas Bridge owns 17323. Keep this development edition isolated.
const DEFAULT_PORT = 17324;
const CHUNK_SIZE = 192 * 1024;
const RESULT_TIMEOUT_MS = 45000;
const HEARTBEAT_INTERVAL_MS = 10000;

class BridgeServer {
  constructor(options) {
    this.port = options.port || DEFAULT_PORT;
    this.pairingCode = String(options.pairingCode);
    this.onState = options.onState || (() => {});
    this.onProgress = options.onProgress || (() => {});
    this.server = null;
    this.wss = null;
    this.client = null;
    this.pending = new Map();
    this.importTransfers = new Map();
    this.onImportAsset = options.onImportAsset || null;
    this.onImportProgress = options.onImportProgress || (() => {});
    this.tempRoot = options.tempRoot || require('os').tmpdir();
    this.heartbeatTimer = null;
  }

  start() {
    if (this.server) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const server = http.createServer((req, res) => { res.writeHead(404); res.end(); });
      const wss = new WebSocket.Server({ server, maxPayload: 2 * 1024 * 1024 });
      this.server = server;
      this.wss = wss;
      wss.on('connection', (socket, request) => this._onConnection(socket, request));
      wss.on('error', reject);
      server.once('error', reject);
      server.listen(this.port, '127.0.0.1', () => {
        server.removeListener('error', reject);
        this._startHeartbeat();
        this.onState({ connected: false, message: `监听 127.0.0.1:${this.port}` });
        resolve();
      });
    });
  }

  _onConnection(socket, request) {
    const origin = request.headers.origin || '';
    if (origin && !origin.startsWith('chrome-extension://')) {
      socket.close(1008, 'Unsupported origin');
      return;
    }
    socket.authenticated = false;
    socket.isAlive = true;
    socket.on('message', raw => this._onMessage(socket, raw));
    socket.on('pong', () => { socket.isAlive = true; });
    socket.on('close', () => {
      if (this.client === socket) {
        this.client = null;
        this.onState({ connected: false, message: 'Chrome 已断开' });
      }
    });
    socket.on('error', () => {});
  }

  _onMessage(socket, raw) {
    let message;
    try { message = JSON.parse(raw.toString()); } catch (_) { return; }
    if (message.protocolVersion !== PROTOCOL_VERSION) {
      this._send(socket, { type: 'hello', ok: false, error: '协议版本不兼容' });
      return;
    }
    if (message.type === 'hello') {
      if (String(message.pairingCode) !== this.pairingCode) {
        this._send(socket, { type: 'hello', ok: false, error: '配对码错误' });
        socket.close(1008, 'Bad pairing code');
        return;
      }
      if (this.client && this.client !== socket) this.client.close(1000, 'Replaced');
      socket.authenticated = true;
      this.client = socket;
      this._send(socket, { type: 'hello', ok: true, server: 'ae-cep' });
      this.onState({ connected: true, message: 'Chrome 已连接' });
      return;
    }
    if (!socket.authenticated) return;
    socket.isAlive = true;
    if (message.type === 'ping') {
      this._send(socket, { type: 'pong', at: message.at || Date.now() });
      return;
    }
    if (message.type === 'result' && message.transferId) {
      const pending = this.pending.get(message.transferId);
      if (!pending) return;
      clearTimeout(pending.timer);
      this.pending.delete(message.transferId);
      message.ok ? pending.resolve(message) : pending.reject(new Error(message.error || '网页插入失败'));
      return;
    }
    if (message.type === 'importStart') return this._onImportStart(socket, message);
    if (message.type === 'importChunk') return this._onImportChunk(socket, message);
    if (message.type === 'importEnd') return this._onImportEnd(socket, message);
  }

  _safeName(value) {
    return String(value || 'kivi-asset').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').replace(/[. ]+$/g, '').trim() || 'kivi-asset';
  }

  _onImportStart(socket, message) {
    if (!message.transferId) return;
    const fileName = this._safeName(message.fileName);
    const directory = require('path').join(this.tempRoot, 'kivi-import');
    ensureDirectory(directory);
    const tempPath = require('path').join(directory, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${fileName}.part`);
    const stream = fs.createWriteStream(tempPath);
    this.importTransfers.set(message.transferId, {
      socket,
      meta: Object.assign({}, message, { fileName }),
      tempPath,
      stream,
      receivedBytes: 0,
      receivedChunks: 0
    });
    this.onImportProgress({ phase: 'start', transferId: message.transferId, meta: message, received: 0, total: Number(message.byteSize) || 0 });
  }

  _onImportChunk(socket, message) {
    const transfer = this.importTransfers.get(message.transferId);
    if (!transfer || transfer.socket !== socket || transfer.ended) return;
    try {
      const buffer = Buffer.from(String(message.base64 || message.data || ''), 'base64');
      transfer.stream.write(buffer);
      transfer.receivedBytes += buffer.length;
      transfer.receivedChunks += 1;
      this.onImportProgress({ phase: 'chunk', transferId: message.transferId, received: transfer.receivedBytes, total: Number(transfer.meta.byteSize) || 0 });
    } catch (error) {
      this._failImport(message.transferId, error);
    }
  }

  _failImport(transferId, error) {
    const transfer = this.importTransfers.get(transferId);
    if (!transfer) return;
    this.importTransfers.delete(transferId);
    try { transfer.stream.end(); } catch (_) {}
    try { if (transfer.tempPath && fs.existsSync(transfer.tempPath)) fs.unlinkSync(transfer.tempPath); } catch (_) {}
    try { this._send(transfer.socket, { type: 'importResult', transferId, ok: false, error: error.message || String(error) }); } catch (_) {}
  }

  _onImportEnd(socket, message) {
    const transfer = this.importTransfers.get(message.transferId);
    if (!transfer || transfer.socket !== socket || transfer.ended) return;
    transfer.ended = true;
    transfer.stream.end(async () => {
      try {
        const expected = Number(transfer.meta.byteSize) || 0;
        if (expected && transfer.receivedBytes !== expected) throw new Error(`接收大小不完整：${transfer.receivedBytes}/${expected}`);
        if (!this.onImportAsset) throw new Error('AE 面板尚未启用 Kivi 导入模块');
        const result = await this.onImportAsset(transfer.meta, transfer.tempPath);
        this.importTransfers.delete(message.transferId);
        try { if (fs.existsSync(transfer.tempPath)) fs.unlinkSync(transfer.tempPath); } catch (_) {}
        this._send(socket, Object.assign({ type: 'importResult', transferId: message.transferId, ok: true }, result || {}));
        this.onImportProgress({ phase: 'done', transferId: message.transferId, received: transfer.receivedBytes, total: expected });
      } catch (error) {
        this._failImport(message.transferId, error);
      }
    });
  }

  _send(socket, message) {
    if (socket.readyState !== WebSocket.OPEN) throw new Error('Chrome 未连接');
    socket.send(JSON.stringify(Object.assign({ protocolVersion: PROTOCOL_VERSION }, message)));
  }

  _startHeartbeat() {
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => {
      if (!this.wss) return;
      for (const socket of this.wss.clients) {
        if (socket.isAlive === false) {
          socket.terminate();
          continue;
        }
        socket.isAlive = false;
        try { socket.ping(); } catch (_) { socket.terminate(); }
      }
    }, HEARTBEAT_INTERVAL_MS);
  }

  async sendAsset(filePath, metadata) {
    const socket = this.client;
    if (!socket || socket.readyState !== WebSocket.OPEN || !socket.authenticated) throw new Error('Chrome 未连接');
    const stat = fs.statSync(filePath);
    const transferId = metadata.transferId || crypto.randomBytes(12).toString('hex');
    const chunkCount = Math.ceil(stat.size / CHUNK_SIZE);
    let pendingEntry;
    const resultPromise = new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(transferId); reject(new Error('等待网页处理超时')); }, RESULT_TIMEOUT_MS);
      pendingEntry = { resolve, reject, timer };
      this.pending.set(transferId, pendingEntry);
    });
    this._send(socket, Object.assign({}, metadata, { type: 'assetStart', transferId, byteSize: stat.size, chunkCount }));
    const fd = fs.openSync(filePath, 'r');
    try {
      const buffer = Buffer.allocUnsafe(CHUNK_SIZE);
      let index = 0;
      let offset = 0;
      while (offset < stat.size) {
        const length = fs.readSync(fd, buffer, 0, Math.min(CHUNK_SIZE, stat.size - offset), offset);
        this._send(socket, { type: 'assetChunk', transferId, index, data: buffer.subarray(0, length).toString('base64') });
        offset += length;
        index += 1;
        this.onProgress({ transferId, sent: offset, total: stat.size });
        await new Promise(resolve => setTimeout(resolve, 0));
      }
    } catch (error) {
      clearTimeout(pendingEntry.timer);
      this.pending.delete(transferId);
      throw error;
    } finally { fs.closeSync(fd); }
    try { this._send(socket, { type: 'assetEnd', transferId }); }
    catch (error) {
      clearTimeout(pendingEntry.timer);
      this.pending.delete(transferId);
      throw error;
    }
    return resultPromise;
  }

  stop() {
    clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
    for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(new Error('服务已停止')); }
    this.pending.clear();
    for (const id of Array.from(this.importTransfers.keys())) this._failImport(id, new Error('服务已停止'));
    if (this.client) this.client.close();
    if (this.wss) this.wss.close();
    if (this.server) this.server.close();
    this.client = this.wss = this.server = null;
  }
}

module.exports = { BridgeServer, PROTOCOL_VERSION, DEFAULT_PORT, CHUNK_SIZE, HEARTBEAT_INTERVAL_MS };
