'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function ensureDirectory(directory) {
  if (fs.existsSync(directory)) return;
  const parent = path.dirname(directory);
  if (parent && parent !== directory) ensureDirectory(parent);
  try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
}

function writeJsonAtomic(filePath, value) {
  ensureDirectory(path.dirname(filePath));
  const temporary = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temporary, filePath); }
  catch (_) {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
    fs.renameSync(temporary, filePath);
  }
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

class PreviewArchiveStore {
  constructor(root) {
    this.root = path.resolve(String(root || ''));
    this.filesRoot = path.join(this.root, 'files');
    this.indexFile = path.join(this.root, 'index.json');
    ensureDirectory(this.filesRoot);
    this.state = { schemaVersion: 1, entries: [] };
    this.load();
  }

  load() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.indexFile, 'utf8').replace(/^\uFEFF/, ''));
      this.state.entries = Array.isArray(parsed.entries) ? parsed.entries.filter(entry => entry && entry.id && entry.source && entry.source.path) : [];
    } catch (_) { this.state.entries = []; }
    this.state.entries = this.state.entries.filter(entry => fs.existsSync(entry.source.path));
    this.save();
    return this.list();
  }

  save() {
    writeJsonAtomic(this.indexFile, this.state);
  }

  list() {
    return this.state.entries.slice().sort((left, right) => Number(right.archivedAt) - Number(left.archivedAt)).map(clone);
  }

  archive(records) {
    const added = [];
    for (const record of Array.isArray(records) ? records : []) {
      if (!record || !record.source || !record.source.path || !fs.existsSync(record.source.path)) continue;
      const id = `preview-${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
      const extension = path.extname(record.source.path) || '.png';
      const managedPath = path.join(this.filesRoot, `${id}${extension}`);
      fs.copyFileSync(record.source.path, managedPath);
      const entry = {
        id,
        archivedAt: Date.now(),
        item: clone(record.item || {}),
        layout: clone(record.layout || {}),
        option: clone(record.option || {}),
        source: {
          path: managedPath,
          width: Number(record.source.width) || Number(record.item && record.item.width) || 0,
          height: Number(record.source.height) || Number(record.item && record.item.height) || 0
        }
      };
      this.state.entries.push(entry);
      added.push(clone(entry));
    }
    this.save();
    return added;
  }

  remove(ids) {
    const selected = new Set((Array.isArray(ids) ? ids : [ids]).map(String));
    let removed = 0;
    this.state.entries = this.state.entries.filter(entry => {
      if (!selected.has(String(entry.id))) return true;
      this.deleteManagedFile(entry.source && entry.source.path);
      removed += 1;
      return false;
    });
    this.save();
    return removed;
  }

  deleteManagedFile(filePath) {
    if (!filePath) return;
    const resolved = path.resolve(filePath);
    const root = `${this.filesRoot}${path.sep}`;
    if (!resolved.startsWith(root)) return;
    try { if (fs.existsSync(resolved)) fs.unlinkSync(resolved); } catch (_) {}
  }
}

module.exports = { PreviewArchiveStore };
