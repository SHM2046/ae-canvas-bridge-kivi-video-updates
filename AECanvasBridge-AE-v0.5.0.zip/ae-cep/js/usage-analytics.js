'use strict';

const ACTIVE_RUN_STATUSES = new Set(['uploading', 'submitting', 'queued', 'running', 'downloading']);

function finiteNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function rounded(value, digits) {
  const factor = Math.pow(10, digits == null ? 2 : digits);
  return Math.round(finiteNumber(value) * factor) / factor;
}

function median(values) {
  const numbers = (values || []).map(finiteNumber).filter(value => value >= 0).sort((left, right) => left - right);
  if (!numbers.length) return 0;
  const middle = Math.floor(numbers.length / 2);
  return numbers.length % 2 ? numbers[middle] : (numbers[middle - 1] + numbers[middle]) / 2;
}

function runCost(run) {
  const gross = Math.max(0, finiteNumber(run && run.cost));
  return { gross, refunded: run && run.refund === true ? gross : 0, net: run && run.refund === true ? 0 : gross };
}

function isWastedJob(job, candidates, runs) {
  if (candidates.some(candidate => candidate.status === 'accepted' || candidate.acceptedAt || candidate.acceptedPath)) return false;
  if (Number(job && job.archivedAt) > 0) return true;
  if (candidates.length && candidates.every(candidate => candidate.status === 'rejected' || candidate.status === 'failed' || candidate.status === 'missing')) return true;
  return runs.length > 0 && runs.every(run => run.status === 'failed');
}

function jobFact(job) {
  const runs = Array.isArray(job && job.runs) ? job.runs : [];
  const candidates = [];
  const runFacts = [];
  let firstAcceptedRun = 0;
  let firstAcceptedAt = 0;
  let grossCost = 0;
  let refundedCost = 0;
  let netCost = 0;
  let agentRuns = 0;
  let manualRuns = 0;

  runs.forEach((run, runIndex) => {
    const accounting = runCost(run);
    grossCost += accounting.gross;
    refundedCost += accounting.refunded;
    netCost += accounting.net;
    if (run.promptSource === 'agent') agentRuns += 1;
    else manualRuns += 1;
    const runCandidates = Array.isArray(run.candidates) ? run.candidates : [];
    let runAcceptedCandidates = 0;
    let runRejectedCandidates = 0;
    runCandidates.forEach(candidate => {
      candidates.push(candidate);
      const accepted = candidate.status === 'accepted' || Number(candidate.acceptedAt) > 0 || !!candidate.acceptedPath;
      if (accepted) runAcceptedCandidates += 1;
      if (candidate.status === 'rejected') runRejectedCandidates += 1;
      if (!accepted) return;
      if (!firstAcceptedRun || runIndex + 1 < firstAcceptedRun) firstAcceptedRun = runIndex + 1;
      const acceptedAt = Math.max(0, finiteNumber(candidate.acceptedAt));
      if (acceptedAt && (!firstAcceptedAt || acceptedAt < firstAcceptedAt)) firstAcceptedAt = acceptedAt;
    });
    const settings = run.settings || {};
    runFacts.push({
      runId: String(run.id || ''),
      taskId: String(run.taskId || ''),
      sequence: runIndex + 1,
      status: String(run.status || ''),
      stage: String(run.stage || ''),
      createdAt: Math.max(0, finiteNumber(run.createdAt)),
      submittedAt: Math.max(0, finiteNumber(run.submittedAt)),
      completedAt: Math.max(0, finiteNumber(run.completedAt)),
      mode: String(run.mode || ''),
      model: String(settings.model || ''),
      ratio: String(settings.ratio || ''),
      resolution: String(settings.resolution || ''),
      duration: Math.max(0, finiteNumber(settings.duration)),
      requestedCandidates: Math.max(0, finiteNumber(settings.outputCount)),
      candidates: runCandidates.length,
      acceptedCandidates: runAcceptedCandidates,
      rejectedCandidates: runRejectedCandidates,
      promptSource: run.promptSource === 'agent' ? 'agent' : 'manual',
      promptProvider: String(run.promptProvider || ''),
      promptModel: String(run.promptModel || ''),
      promptSkillVersion: Math.max(0, finiteNumber(run.promptSkillVersion)),
      grossCost: rounded(accounting.gross, 4),
      refundedCost: rounded(accounting.refunded, 4),
      netCost: rounded(accounting.net, 4),
      refund: run.refund === true,
      retryTimes: Math.max(0, finiteNumber(run.retryTimes))
    });
  });

  const acceptedCandidates = candidates.filter(candidate => candidate.status === 'accepted' || candidate.acceptedAt || candidate.acceptedPath).length;
  const rejectedCandidates = candidates.filter(candidate => candidate.status === 'rejected').length;
  const active = runs.some(run => ACTIVE_RUN_STATUSES.has(run.status));
  const completedRuns = runs.filter(run => run.status === 'completed').length;
  const failedRuns = runs.filter(run => run.status === 'failed').length;
  const createdAt = Math.max(0, finiteNumber(job && job.createdAt));
  return {
    jobId: String(job && job.id || ''),
    createdAt,
    updatedAt: Math.max(0, finiteNumber(job && job.updatedAt)),
    archivedAt: Math.max(0, finiteNumber(job && job.archivedAt)),
    generationRuns: runs.length,
    submittedRuns: runs.filter(run => run.taskId || run.submittedAt).length,
    completedRuns,
    failedRuns,
    active,
    candidates: candidates.length,
    acceptedCandidates,
    rejectedCandidates,
    adopted: acceptedCandidates > 0,
    firstAcceptedRun,
    firstAcceptedAt,
    minutesToFirstAcceptance: firstAcceptedAt && createdAt ? rounded((firstAcceptedAt - createdAt) / 60000, 2) : 0,
    grossCost: rounded(grossCost, 4),
    refundedCost: rounded(refundedCost, 4),
    netCost: rounded(netCost, 4),
    wasted: isWastedJob(job, candidates, runs),
    agentRuns,
    manualRuns,
    runs: runFacts
  };
}

function buildUsageSnapshot(options) {
  const input = options || {};
  const facts = (Array.isArray(input.jobs) ? input.jobs : []).map(jobFact);
  const maxJobs = Math.max(1, Math.min(200, Math.floor(finiteNumber(input.maxJobs)) || 200));
  const transmittedFacts = facts.slice().sort((left, right) => right.updatedAt - left.updatedAt || right.createdAt - left.createdAt).slice(0, maxJobs);
  const adopted = facts.filter(fact => fact.adopted);
  const identity = input.identity || {};
  const quota = input.quota || {};
  const total = field => facts.reduce((sum, fact) => sum + finiteNumber(fact[field]), 0);
  const grossCost = total('grossCost');
  const refundedCost = total('refundedCost');
  const netCost = total('netCost');
  const acceptedJobNetCost = adopted.reduce((sum, fact) => sum + fact.netCost, 0);
  const unadoptedNetCost = facts.filter(fact => !fact.adopted).reduce((sum, fact) => sum + fact.netCost, 0);
  const wastedNetCost = facts.filter(fact => fact.wasted).reduce((sum, fact) => sum + fact.netCost, 0);
  return {
    schemaVersion: 1,
    generatedAt: Math.max(0, finiteNumber(input.generatedAt)) || Date.now(),
    identity: {
      analyticsUserId: String(identity.analyticsUserId || ''),
      username: String(identity.username || ''),
      realName: String(identity.realName || ''),
      departmentName: String(identity.departmentName || '')
    },
    client: {
      pluginVersion: String(input.pluginVersion || ''),
      aeVersion: String(input.aeVersion || '')
    },
    quota: {
      usage: finiteNumber(quota.usage),
      refund: finiteNumber(quota.refund),
      remaining: finiteNumber(quota.remaining),
      quota: finiteNumber(quota.quota)
    },
    totals: {
      jobs: facts.length,
      adoptedJobs: adopted.length,
      activeJobs: facts.filter(fact => fact.active).length,
      runs: total('generationRuns'),
      submittedRuns: total('submittedRuns'),
      completedRuns: total('completedRuns'),
      failedRuns: total('failedRuns'),
      candidates: total('candidates'),
      acceptedCandidates: total('acceptedCandidates'),
      rejectedCandidates: total('rejectedCandidates'),
      agentRuns: total('agentRuns'),
      manualRuns: total('manualRuns'),
      grossCost: rounded(grossCost, 4),
      refundedCost: rounded(refundedCost, 4),
      netCost: rounded(netCost, 4),
      acceptedJobNetCost: rounded(acceptedJobNetCost, 4),
      unadoptedNetCost: rounded(unadoptedNetCost, 4),
      wastedNetCost: rounded(wastedNetCost, 4),
      adoptionRate: facts.length ? rounded(adopted.length / facts.length, 4) : 0,
      medianRunsToFirstAcceptance: rounded(median(adopted.map(fact => fact.firstAcceptedRun).filter(Boolean)), 2),
      medianMinutesToFirstAcceptance: rounded(median(adopted.map(fact => fact.minutesToFirstAcceptance).filter(Boolean)), 2),
      netCostPerAdoptedJob: adopted.length ? rounded(acceptedJobNetCost / adopted.length, 4) : 0
    },
    jobsTruncated: transmittedFacts.length < facts.length,
    jobs: transmittedFacts
  };
}

module.exports = { buildUsageSnapshot, jobFact, median, runCost };
