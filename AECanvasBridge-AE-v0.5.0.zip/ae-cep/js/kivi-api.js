'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');

const DEFAULT_API_BASE = 'https://api.micoplatform.com/business_ai/kivi/web';
const DEFAULT_PUBLIC_BASE = 'https://kivi-ai.micoplatform.com';
const DEFAULT_OSS_ENDPOINT = 'https://oss-accelerate.aliyuncs.com';
const DEFAULT_OSS_BUCKET = 'micocenter-kivi-ai';
const DEFAULT_OSS_REGION = 'oss-ap-southeast-1';

function asObject(value) { return value && typeof value === 'object' ? value : {}; }

function findValue(value, names) {
  const normalizeKey = key => String(key).replace(/[^a-z0-9]/gi, '').toLowerCase();
  const wanted = new Set(names.map(normalizeKey));
  const queue = [value];
  while (queue.length) {
    const current = queue.shift();
    if (!current || typeof current !== 'object') continue;
    for (const [key, item] of Object.entries(current)) {
      if (wanted.has(normalizeKey(key)) && item != null && item !== '') return item;
      if (item && typeof item === 'object') queue.push(item);
    }
  }
  return null;
}

function requestRaw(url, options = {}, redirectCount = 0) {
  return new Promise((resolve, reject) => {
    const target = new URL(url);
    const client = target.protocol === 'https:' ? https : http;
    // CEP ships an older Node runtime whose request overload misreads a WHATWG
    // URL object as options. Pass a string URL to keep the callback position stable.
    const request = client.request(target.toString(), {
      method: options.method || 'GET',
      headers: options.headers || {},
      timeout: options.timeoutMs || 120000
    }, response => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location && redirectCount < 5) {
        response.resume();
        resolve(requestRaw(new URL(response.headers.location, target).toString(), options, redirectCount + 1));
        return;
      }
      const chunks = [];
      response.on('data', chunk => chunks.push(Buffer.from(chunk)));
      response.on('end', () => resolve({
        statusCode: response.statusCode || 0,
        headers: response.headers,
        body: Buffer.concat(chunks)
      }));
    });
    request.on('error', reject);
    request.on('timeout', () => request.destroy(new Error('KIVI 请求超时')));
    if (options.body) request.write(options.body);
    request.end();
  });
}

function authHeaders(token) {
  return {
    Accept: 'application/json',
    Authorization: `Bearer ${String(token).replace(/^Bearer\s+/i, '')}`,
    'User-Agent': 'AE-Canvas-Bridge-KIVI-Video-Dev'
  };
}

async function jsonRequest(url, token, options = {}) {
  const headers = Object.assign({}, authHeaders(token), options.headers || {});
  if (options.body != null) {
    headers['Content-Type'] = 'application/json';
    options.body = Buffer.from(JSON.stringify(options.body));
  }
  const response = await requestRaw(url, Object.assign({}, options, { headers }));
  const text = response.body.toString('utf8');
  let data = null;
  try { data = text ? JSON.parse(text) : {}; } catch (_) { throw new Error(`KIVI 返回了非 JSON 数据：${text.slice(0, 180)}`); }
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw new Error(`KIVI 请求失败：HTTP ${response.statusCode} ${String(data.msg || data.message || text).slice(0, 240)}`);
  }
  if (data && data.code != null && Number(data.code) !== 200) throw new Error(`KIVI 业务错误：${data.msg || data.message || data.code}`);
  return data;
}

function objectKey(prefix, fileName) {
  const safe = String(fileName || 'frame.png').replace(/[^0-9A-Za-z._-]/g, '_');
  return `${String(prefix || 'data/image').replace(/^\/+|\/+$/g, '')}/${Date.now()}-${crypto.randomBytes(5).toString('hex')}-${safe}`;
}

function uploadSignature({ method, contentType, date, accessKeyId, accessKeySecret, securityToken, bucket, key }) {
  const headers = securityToken ? `x-oss-security-token:${securityToken}\n` : '';
  const resource = `/${bucket}/${key}`;
  const canonical = `${method}\n\n${contentType}\n${date}\n${headers}${resource}`;
  const signature = crypto.createHmac('sha1', accessKeySecret).update(canonical).digest('base64');
  return `OSS ${accessKeyId}:${signature}`;
}

function encodeObjectKey(key) {
  return String(key).split('/').map(part => encodeURIComponent(part)).join('/');
}

function publicUrl(base, key) {
  return `${String(base || DEFAULT_PUBLIC_BASE).replace(/\/+$/, '')}/${encodeObjectKey(key)}`;
}

function normalizeUploadInfo(response) {
  const data = asObject(response.data || response.result || response);
  const signedUrl = findValue(data, ['uploadUrl', 'signedUrl', 'presignedUrl', 'putUrl']);
  if (signedUrl) return { signedUrl: String(signedUrl) };
  // KIVI's STS endpoint currently returns only temporary credentials. The
  // Photoshop implementation confirms these are the web uploader defaults.
  const bucket = findValue(data, ['bucket', 'bucketName', 'ossBucket']) || DEFAULT_OSS_BUCKET;
  const endpoint = findValue(data, ['endpoint', 'ossEndpoint']) || DEFAULT_OSS_ENDPOINT;
  const accessKeyId = findValue(data, ['accessKeyId', 'accessId', 'accessKey']);
  const accessKeySecret = findValue(data, ['accessKeySecret', 'accessSecret', 'secretKey']);
  const securityToken = findValue(data, ['securityToken', 'stsToken', 'sessionToken']);
  if (!bucket || !accessKeyId || !accessKeySecret) throw new Error('KIVI STS 响应缺少上传所需凭证字段');
  return {
    bucket: String(bucket),
    endpoint: String(endpoint),
    accessKeyId: String(accessKeyId),
    accessKeySecret: String(accessKeySecret),
    securityToken: securityToken ? String(securityToken) : '',
    region: String(findValue(data, ['region', 'ossRegion']) || DEFAULT_OSS_REGION),
    prefix: String(findValue(data, ['uploadDir', 'prefix', 'objectPrefix', 'baseDir', 'objectKeyPrefix']) || 'data/image'),
    publicBaseUrl: String(findValue(data, ['cdnUrl', 'publicBaseUrl', 'publicUrl']) || DEFAULT_PUBLIC_BASE)
  };
}

function endpointUrl(endpoint, bucket, key) {
  const raw = String(endpoint || DEFAULT_OSS_ENDPOINT).replace(/\/+$/, '');
  const parsed = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
  if (!parsed.hostname.startsWith(`${bucket}.`)) parsed.hostname = `${bucket}.${parsed.hostname}`;
  parsed.pathname = `/${encodeObjectKey(key)}`;
  return parsed.toString();
}

async function getUploadInfo(apiBase, token) {
  const url = `${apiBase.replace(/\/+$/, '')}/api/oss/sts_token`;
  let response = await requestRaw(url, { headers: authHeaders(token) });
  if (response.statusCode === 404 || response.statusCode === 405) {
    response = await requestRaw(url, { method: 'POST', headers: Object.assign({}, authHeaders(token), { 'Content-Type': 'application/json' }), body: Buffer.from('{}') });
  }
  const text = response.body.toString('utf8');
  let data;
  try { data = JSON.parse(text); } catch (_) { throw new Error(`KIVI 上传凭证接口返回了非 JSON：${text.slice(0, 180)}`); }
  if (response.statusCode < 200 || response.statusCode >= 300) throw new Error(`KIVI 上传凭证失败：HTTP ${response.statusCode} ${text.slice(0, 180)}`);
  if (data.code != null && Number(data.code) !== 200) throw new Error(`KIVI 上传凭证业务错误：${data.msg || data.message || data.code}`);
  return normalizeUploadInfo(data);
}

async function uploadFile(apiBase, token, filePath, fileName, mimeType) {
  const body = fs.readFileSync(filePath);
  if (!body.length) throw new Error('不能上传空的 KIVI 素材');
  const info = await getUploadInfo(apiBase, token);
  if (info.signedUrl) {
    const response = await requestRaw(info.signedUrl, { method: 'PUT', headers: { 'Content-Type': mimeType, 'Content-Length': body.length }, body });
    if (response.statusCode < 200 || response.statusCode >= 300) throw new Error(`KIVI 素材上传失败：HTTP ${response.statusCode}`);
    return { url: info.signedUrl.split('?')[0], bytes: body.length };
  }
  const key = objectKey(info.prefix, fileName);
  const date = new Date().toUTCString();
  const url = endpointUrl(info.endpoint, info.bucket, key);
  const headers = {
    'Content-Type': mimeType,
    'Content-Length': body.length,
    Date: date,
    Authorization: uploadSignature({ method: 'PUT', contentType: mimeType, date, accessKeyId: info.accessKeyId, accessKeySecret: info.accessKeySecret, securityToken: info.securityToken, bucket: info.bucket, key })
  };
  if (info.securityToken) headers['x-oss-security-token'] = info.securityToken;
  const response = await requestRaw(url, { method: 'PUT', headers, body });
  if (response.statusCode < 200 || response.statusCode >= 300) throw new Error(`KIVI OSS 素材上传失败：HTTP ${response.statusCode}`);
  return { url: publicUrl(info.publicBaseUrl, key), bytes: body.length, key };
}

function outputUrls(value, hint, result = []) {
  if (typeof value === 'string') {
    if (/^https?:\/\//i.test(value) && /video|output|result|download|asset|content/i.test(String(hint || ''))) result.push(value);
    return result;
  }
  if (!value || typeof value !== 'object') return result;
  for (const [key, item] of Object.entries(value)) outputUrls(item, `${hint || ''}.${key}`, result);
  return result;
}

function extractVideoUrl(task) {
  return extractVideoUrls(task)[0] || '';
}

function extractVideoUrls(task) {
  const data = asObject(task.data || task.result || task);
  const candidates = [
    ...outputUrls(data.outputs, 'outputs'),
    ...outputUrls(data.assets, 'assets'),
    ...outputUrls(data.requests, 'requests'),
    ...outputUrls(data.output, 'output'),
    ...outputUrls(data.result, 'result')
  ];
  const urls = [...new Set(candidates)].filter(url => !/\.(png|jpg|jpeg|webp)(\?|$)/i.test(url));
  return urls.length ? urls : [...new Set(candidates)];
}

async function downloadFile(url, token, destination) {
  const headers = /^https?:\/\/[^/]*micoplatform\.com/i.test(url) ? authHeaders(token) : {};
  const response = await requestRaw(url, { headers, timeoutMs: 180000 });
  if (response.statusCode < 200 || response.statusCode >= 300) throw new Error(`KIVI 视频下载失败：HTTP ${response.statusCode}`);
  if (!response.body.length) throw new Error('KIVI 视频下载结果为空');
  fs.writeFileSync(destination, response.body);
  return { bytes: response.body.length, contentType: String(response.headers['content-type'] || '') };
}

function taskStatus(task) {
  return String(findValue(task, ['status', 'state']) || '').toLowerCase();
}

function taskError(task) {
  const explicit = findValue(task, ['showErrorMsg', 'errorMsg', 'errorMessage', 'failureReason', 'error']);
  if (explicit) return String(explicit);
  return FAILURE_STATUS_HINTS.has(taskStatus(task))
    ? String(findValue(task, ['message', 'msg', 'detail']) || '')
    : '';
}

function taskAccounting(record) {
  const task = asObject(record && record.task ? record.task : record);
  const cost = Number(task.cost);
  const retryTimes = Number(task.retry_times != null ? task.retry_times : task.retryTimes);
  return {
    cost: Number.isFinite(cost) && cost > 0 ? cost : 0,
    refund: task.refund === true,
    userId: task.user_id == null ? '' : String(task.user_id),
    retryTimes: Number.isFinite(retryTimes) && retryTimes > 0 ? Math.floor(retryTimes) : 0
  };
}

function normalizeUserInfo(response) {
  const data = asObject(response && response.data);
  return {
    username: String(data.username || ''),
    realName: String(data.real_name || data.realName || ''),
    email: String(data.email || ''),
    avatar: String(data.avatar || ''),
    departmentName: String(data.dept_name || data.departmentName || ''),
    departmentTag: String(data.dept_tag || data.departmentTag || ''),
    subDepartmentName: String(data.sub_dept_name || data.subDepartmentName || ''),
    roles: Array.isArray(data.roles) ? data.roles.map(String) : [],
    permissions: Array.isArray(data.permissions) ? data.permissions.map(String) : []
  };
}

function normalizeQuota(response) {
  const data = asObject(response && response.data);
  const number = value => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  return {
    basicCoin: number(data.basic_coin),
    temporaryCoin: number(data.tmp_coin),
    usage: number(data.usage),
    refund: number(data.refund),
    remaining: number(data.remaining),
    quota: number(data.quota),
    basicQuota: number(data.basic_quota),
    temporaryQuota: number(data.temp_quota)
  };
}

const FAILURE_STATUS_HINTS = new Set(['failed', 'failure', 'error', 'cancelled', 'canceled', 'cancel', 'deleted']);

function normalizeVideoModels(response) {
  const data = response && Array.isArray(response.data) ? response.data : [];
  return data
    .filter(item => item && String(item.media_type || '').toLowerCase() === 'video' && !item.is_del && item.model_name)
    .map(item => ({
      name: String(item.model_name),
      label: String(item.display_name || item.model_name),
      tags: String(item.tags || ''),
      description: String(item.description || ''),
      priority: Number(item.priority) || 0,
      workflow: item.workflow !== false
    }))
    .sort((left, right) => left.priority - right.priority || left.label.localeCompare(right.label));
}

function createClient({ token, apiBase = DEFAULT_API_BASE, wait = setTimeout }) {
  if (!token) throw new Error('尚未配置 KIVI Key');
  const base = String(apiBase).replace(/\/+$/, '');
  return {
    uploadFile: (filePath, fileName, mimeType) => uploadFile(base, token, filePath, fileName, mimeType),
    async createVideo({ mode, imageUrl, firstUrl, lastUrl, prompt, model, ratio, resolution, duration, outputCount }) {
      const referenceMode = mode === 'general_reference' ? 'general_reference' : 'flf2v';
      const sourceUrl = imageUrl || firstUrl || lastUrl;
      const references = referenceMode === 'general_reference'
        ? [{ id: 'image_0', content: sourceUrl, media_type: 'image', reference_type: 'reference' }]
        : [
          { id: 'image_0', content: firstUrl || sourceUrl, media_type: 'image', reference_type: 'first_frame' },
          { id: 'image_1', content: lastUrl || sourceUrl, media_type: 'image', reference_type: 'last_frame' }
        ];
      if (!sourceUrl) throw new Error('KIVI 视频任务缺少参考图片地址');
      const bizInput = {
        base_model: { model_name: model },
        prompt: prompt || '',
        general_reference: { reference_type: referenceMode, items: references },
        resolution,
        duration: Number(duration),
        num_outputs: Math.max(1, Math.min(2, Number(outputCount) || 1)),
        enable_audio: false
      };
      if (referenceMode === 'general_reference') bizInput.aspect_ratio = ratio;
      return jsonRequest(`${base}/api/ai/general/tasks`, token, { method: 'POST', body: {
        biz_action: 'video_generation',
        biz_category: 'canvas',
        biz_input: bizInput
      } });
    },
    getTask(taskId) {
      return jsonRequest(`${base}/api/ai/general/tasks/${encodeURIComponent(taskId)}`, token);
    },
    async getUserInfo() {
      return normalizeUserInfo(await jsonRequest(`${base}/api/auth/user/info`, token));
    },
    async getQuota() {
      return normalizeQuota(await jsonRequest(`${base}/api/ai/prediction/quota`, token));
    },
    batchGetTasks(taskIds) {
      const ids = (taskIds || []).map(id => Number(id) || id).filter(id => id !== '');
      if (!ids.length) return Promise.resolve({ code: 200, msg: 'Success', data: [] });
      return jsonRequest(`${base}/api/ai/general/tasks/batch_get`, token, { method: 'POST', body: { ids } });
    },
    async listVideoModels() {
      return normalizeVideoModels(await jsonRequest(`${base}/api/model/base_models`, token));
    },
    async waitForVideo(taskId, maxAttempts = 120) {
      let delayMs = 1000;
      for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
        await new Promise(resolve => wait(resolve, delayMs));
        const task = await jsonRequest(`${base}/api/ai/general/tasks/${encodeURIComponent(taskId)}`, token);
        const status = taskStatus(task);
        if (['success', 'succeed', 'completed', 'complete', 'finished', 'done'].includes(status)) return task;
        if (['failed', 'failure', 'error', 'cancelled', 'canceled', 'cancel'].includes(status)) {
          const detail = taskError(task);
          throw new Error(`KIVI 视频任务失败：${detail || status}`);
        }
        delayMs = Math.min(15000, Math.round(delayMs * 1.35));
      }
      throw new Error('KIVI 视频任务轮询超时，任务可能仍在云端运行');
    },
    extractVideoUrl,
    extractVideoUrls,
    taskStatus,
    taskError,
    taskAccounting,
    downloadFile: (url, destination) => downloadFile(url, token, destination)
  };
}

module.exports = {
  createClient,
  extractVideoUrl,
  extractVideoUrls,
  taskStatus,
  taskError,
  taskAccounting,
  normalizeUserInfo,
  normalizeQuota,
  normalizeVideoModels
};
