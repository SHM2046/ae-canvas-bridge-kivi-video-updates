'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const path = require('path');

const DEFAULT_BASE_URL = 'https://api.deepseek.com';
const DEFAULT_MODEL = 'deepseek-flash';
const MAX_IMAGE_BYTES = 32 * 1024 * 1024;

function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function safeMessage(error) {
  return String(error && error.message ? error.message : error || '未知错误')
    .replace(/Bearer\s+[A-Za-z0-9._~+\/-]+/gi, 'Bearer [REDACTED]')
    .replace(/sk-[A-Za-z0-9_-]{8,}/gi, '[REDACTED]')
    .slice(0, 500);
}
function retryable(error) { return /HTTP (408|425|429|5\d\d)|timeout|超时|ECONN|ENOTFOUND|EAI_AGAIN|socket/i.test(safeMessage(error)); }

function sniffImage(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) return null;
  if (buffer[0] === 0x89 && buffer.slice(1, 4).toString('ascii') === 'PNG') return { mimeType: 'image/png', extension: '.png' };
  if (buffer[0] === 0xff && buffer[1] === 0xd8) return { mimeType: 'image/jpeg', extension: '.jpg' };
  if (buffer.slice(0, 6).toString('ascii').match(/^GIF8[79]a$/)) return { mimeType: 'image/gif', extension: '.gif' };
  if (buffer.slice(0, 4).toString('ascii') === 'RIFF' && buffer.slice(8, 12).toString('ascii') === 'WEBP') return { mimeType: 'image/webp', extension: '.webp' };
  return null;
}

function imageDataUrl(filePath) {
  const resolved = path.resolve(String(filePath || ''));
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile()) throw new Error('任务源图片不存在');
  const stat = fs.statSync(resolved);
  if (stat.size > MAX_IMAGE_BYTES) throw new Error('任务源图片超过 DeepSeek 32 MiB 限制');
  const buffer = fs.readFileSync(resolved);
  const image = sniffImage(buffer);
  if (!image) throw new Error('DeepSeek 仅支持 JPEG、PNG、GIF 或 WebP 图片');
  return { dataUrl: `data:${image.mimeType};base64,${buffer.toString('base64')}`, mimeType: image.mimeType, byteSize: buffer.length };
}

function requestJson(options) {
  const target = new URL(options.url);
  const transport = target.protocol === 'http:' ? http : https;
  const body = options.body == null ? null : Buffer.from(JSON.stringify(options.body), 'utf8');
  return new Promise((resolve, reject) => {
    const request = transport.request({
      protocol: target.protocol,
      hostname: target.hostname,
      port: target.port || undefined,
      path: `${target.pathname}${target.search}`,
      method: options.method || (body ? 'POST' : 'GET'),
      headers: Object.assign({ Accept: 'application/json' }, body ? { 'Content-Type': 'application/json', 'Content-Length': body.length } : {}, options.headers || {})
    }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        let parsed = null;
        try { parsed = raw ? JSON.parse(raw) : {}; } catch (_) {}
        if (response.statusCode < 200 || response.statusCode >= 300) {
          const detail = parsed && parsed.error && parsed.error.message ? parsed.error.message : raw || response.statusMessage;
          reject(new Error(`HTTP ${response.statusCode}: ${safeMessage(detail)}`));
          return;
        }
        if (!parsed) return reject(new Error('DeepSeek 返回了无效 JSON'));
        resolve(parsed);
      });
    });
    request.setTimeout(Number(options.timeoutMs) || 90000, () => request.destroy(new Error('DeepSeek 请求超时')));
    request.on('error', reject);
    if (body) request.write(body);
    request.end();
  });
}

function outputText(response) {
  const parts = [];
  for (const item of response && Array.isArray(response.output) ? response.output : []) {
    if (item.type !== 'message') continue;
    for (const content of Array.isArray(item.content) ? item.content : []) {
      if (content.type === 'output_text' && content.text) parts.push(String(content.text));
    }
  }
  return parts.join('\n').trim();
}

function validateResult(value) {
  if (!value || typeof value !== 'object') throw new Error('Agent 结果结构无效');
  const prompt = String(value.prompt || '').trim();
  if (!prompt) throw new Error('Agent 返回了空 Prompt');
  return {
    prompt,
    summary: String(value.summary || '').trim().slice(0, 1000),
    warnings: Array.isArray(value.warnings) ? value.warnings.map(item => String(item).slice(0, 300)).slice(0, 10) : []
  };
}

class DeepSeekProvider {
  constructor(options) {
    options = options || {};
    this.apiKey = String(options.apiKey || '').trim();
    this.apiBase = String(options.apiBase || DEFAULT_BASE_URL).replace(/\/+$/, '');
    this.model = String(options.model || DEFAULT_MODEL);
    this.timeoutMs = Number(options.timeoutMs) || 90000;
    this.maxAttempts = Math.max(1, Number(options.maxAttempts) || 3);
  }

  headers() {
    if (!this.apiKey) throw new Error('尚未配置 DeepSeek API Key');
    return { Authorization: `Bearer ${this.apiKey}` };
  }

  async withRetry(operation) {
    let lastError;
    for (let attempt = 0; attempt < this.maxAttempts; attempt += 1) {
      try { return await operation(); }
      catch (error) {
        lastError = error;
        if (!retryable(error) || attempt === this.maxAttempts - 1) throw new Error(safeMessage(error));
        await wait(Math.min(8000, 750 * Math.pow(2, attempt)));
      }
    }
    throw lastError;
  }

  async listModels() {
    const response = await this.withRetry(() => requestJson({ url: `${this.apiBase}/models`, headers: this.headers(), timeoutMs: this.timeoutMs }));
    return (Array.isArray(response.data) ? response.data : []).map(item => String(item.id || '')).filter(id => id === 'deepseek-flash');
  }

  async testConnection() {
    const models = await this.listModels();
    if (!models.includes('deepseek-flash')) throw new Error('当前账号未返回可用的 deepseek-flash 视觉模型');
    return { ok: true, models };
  }

  async requestPrompt(context, refinement) {
    const image = imageDataUrl(context.imagePath);
    const skill = context.skill || {};
    const job = context.job || {};
    const settings = job.settings || {};
    const schema = {
      type: 'object',
      properties: {
        prompt: { type: 'string' },
        summary: { type: 'string' },
        warnings: { type: 'array', items: { type: 'string' } }
      },
      required: ['prompt', 'summary', 'warnings'],
      additionalProperties: false
    };
    const instructions = [
      'You are a constrained image-to-video prompt writer. Do not call tools and do not reveal chain-of-thought.',
      'Follow the active Skill below as writing instructions. Return only the JSON object required by the schema.',
      'The prompt must be directly usable by the selected video model and must preserve the pictured subject unless the Skill explicitly says otherwise.',
      '',
      `ACTIVE SKILL (${skill.name || 'unnamed'} v${skill.version || 1}):`,
      String(skill.content || '')
    ].join('\n');
    const conversation = Array.isArray(context.history) ? context.history.slice(-12).map(item => `${item.role === 'assistant' ? 'AGENT' : 'USER'}: ${String(item.text || '').slice(0, 6000)}`).join('\n\n') : '';
    const taskText = [
      refinement ? 'Revise the current image-to-video prompt using the latest user feedback.' : 'Generate one image-to-video prompt for this task.',
      `Reference mode: ${job.mode === 'general_reference' ? 'general reference' : 'same image as first and last frame'}.`,
      `Video model: ${settings.model || 'unspecified'}.`,
      `Aspect ratio: ${settings.ratio || 'unspecified'}. Resolution: ${settings.resolution || 'unspecified'}. Duration: ${settings.duration || 4} seconds.`,
      refinement ? `Current prompt:\n${String(context.currentPrompt || '').slice(0, 12000)}` : '',
      refinement && conversation ? `Conversation so far:\n${conversation}` : '',
      refinement ? `Latest user feedback:\n${String(context.feedback || '').trim().slice(0, 6000)}` : '',
      refinement ? 'Preserve every requirement the user did not ask to change. Return the complete revised prompt, not a patch or commentary.' : '',
      'The summary must be a short user-facing explanation, not hidden reasoning. Warnings must only contain practical visual risks.'
    ].filter(Boolean).join('\n\n');
    const body = {
      model: this.model,
      instructions,
      input: [{ role: 'user', content: [
        { type: 'input_text', text: taskText },
        { type: 'input_image', image_url: image.dataUrl, detail: 'auto' }
      ] }],
      reasoning: { effort: 'none' },
      max_output_tokens: 1600,
      stream: false,
      text: { format: { type: 'json_schema', name: 'kivi_video_prompt', schema } },
      user: String(job.id || 'kivi-task').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 128)
    };
    const startedAt = Date.now();
    const response = await this.withRetry(() => requestJson({ url: `${this.apiBase}/responses`, method: 'POST', headers: this.headers(), body, timeoutMs: this.timeoutMs }));
    if (response.status && response.status !== 'completed') throw new Error(response.error && response.error.message ? response.error.message : `DeepSeek 响应状态：${response.status}`);
    let parsed;
    try { parsed = JSON.parse(outputText(response)); }
    catch (_) { throw new Error('DeepSeek 没有返回符合约定的结构化 Prompt'); }
    return Object.assign(validateResult(parsed), {
      provider: 'deepseek',
      model: response.model || this.model,
      requestId: String(response.id || ''),
      usage: response.usage || null,
      latencyMs: Date.now() - startedAt
    });
  }

  async generatePrompt(context) {
    return this.requestPrompt(context || {}, false);
  }

  async refinePrompt(context) {
    const input = context || {};
    if (!String(input.currentPrompt || '').trim()) throw new Error('请先运行一次测试，再继续对话调整');
    if (!String(input.feedback || '').trim()) throw new Error('请输入希望 Agent 调整的内容');
    return this.requestPrompt(input, true);
  }
}

module.exports = { DeepSeekProvider, DEFAULT_BASE_URL, DEFAULT_MODEL, MAX_IMAGE_BYTES, imageDataUrl, sniffImage, outputText, safeMessage, validateResult };
