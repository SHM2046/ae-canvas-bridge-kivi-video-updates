'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ACTIVE_RUN_STATUSES = new Set(['uploading', 'submitting', 'queued', 'running', 'downloading']);
const SUCCESS_STATUSES = new Set(['success', 'succeed', 'completed', 'complete', 'finished', 'done']);
const FAILURE_STATUSES = new Set(['failed', 'failure', 'error', 'cancelled', 'canceled', 'cancel', 'deleted']);

function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function settleAll(promises) {
  return Promise.all((promises || []).map(promise => Promise.resolve(promise).then(
    value => ({ status: 'fulfilled', value }),
    reason => ({ status: 'rejected', reason })
  )));
}
function makeCandidateId() { return `candidate-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`; }
function safeFileName(value, fallback) {
  const clean = String(value || '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').replace(/[. ]+$/g, '').trim();
  return clean || fallback;
}
function safeMessage(error) { return String(error && error.message ? error.message : error || '未知错误').slice(0, 500); }
function isRetryable(error) { return /HTTP (408|425|429|5\d\d)|超时|ECONN|ENOTFOUND|EAI_AGAIN|socket/i.test(safeMessage(error)); }

function taskRecordId(record) {
  const task = record && record.task ? record.task : record;
  return String(task && task.id != null ? task.id : '');
}

function taskRecordStatus(record, client) {
  return client.taskStatus(record && record.task ? record.task : record);
}

function applyAccounting(run, record, client) {
  const accounting = client.taskAccounting
    ? client.taskAccounting(record)
    : (() => {
      const task = record && record.task ? record.task : record || {};
      return {
        cost: Number(task.cost) || 0,
        refund: task.refund === true,
        userId: task.user_id == null ? '' : String(task.user_id),
        retryTimes: Number(task.retry_times) || 0
      };
    })();
  run.cost = Math.max(0, Number(accounting.cost) || 0);
  run.refund = accounting.refund === true;
  run.kiviUserId = String(accounting.userId || '');
  run.retryTimes = Math.max(0, Math.floor(Number(accounting.retryTimes) || 0));
}

class KiviJobRunner {
  constructor(options) {
    this.store = options.store;
    this.createClient = options.createClient;
    this.readToken = options.readToken;
    this.onChange = options.onChange || function () {};
    this.pollIntervalMs = Number(options.pollIntervalMs) || 4000;
    this.clientPromise = null;
    this.pollTimer = null;
    this.polling = false;
    this.stopped = false;
    this.submitting = new Set();
    this.downloading = new Set();
  }

  async client() {
    if (!this.clientPromise) this.clientPromise = Promise.resolve(this.readToken()).then(token => this.createClient({ token }));
    try { return await this.clientPromise; }
    catch (error) { this.clientPromise = null; throw error; }
  }

  changed() {
    this.store.save();
    this.onChange(this.store.state);
  }

  async withRetry(operation, attempts) {
    let lastError;
    const limit = Number(attempts) || 3;
    for (let attempt = 0; attempt < limit; attempt += 1) {
      try { return await operation(); }
      catch (error) {
        lastError = error;
        if (!isRetryable(error) || attempt === limit - 1) throw error;
        await wait(Math.min(8000, 750 * Math.pow(2, attempt)));
      }
    }
    throw lastError;
  }

  async startJob(jobId) {
    if (this.submitting.has(jobId)) return;
    const job = this.store.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    if (!job.source || !job.source.path || !fs.existsSync(job.source.path)) throw new Error(`任务“${job.name}”的源图片不存在`);
    const run = this.store.createRun(jobId);
    this.submitting.add(jobId);
    this.onChange(this.store.state);
    try {
      const client = await this.client();
      run.stage = 'uploading';
      run.status = 'uploading';
      this.changed();
      const upload = await this.withRetry(() => client.uploadFile(job.source.path, job.source.fileName, 'image/png'), 3);
      run.stage = 'submitting';
      run.status = 'submitting';
      this.changed();
      const created = await this.withRetry(() => client.createVideo({
        mode: run.mode,
        imageUrl: upload.url,
        firstUrl: upload.url,
        lastUrl: upload.url,
        prompt: run.prompt,
        model: run.settings.model,
        ratio: run.settings.ratio,
        resolution: run.settings.resolution,
        duration: run.settings.duration,
        outputCount: run.settings.outputCount
      }), 3);
      const taskId = created && created.data && created.data.id;
      if (!taskId) throw new Error('KIVI 创建任务响应缺少 data.id');
      run.taskId = String(taskId);
      run.submittedAt = Date.now();
      run.status = 'queued';
      run.stage = 'queued';
      run.updatedAt = Date.now();
      run.error = '';
      this.changed();
      this.schedulePoll(250);
      return run;
    } catch (error) {
      run.status = 'failed';
      run.stage = 'failed';
      run.error = safeMessage(error);
      run.updatedAt = Date.now();
      run.completedAt = run.updatedAt;
      this.changed();
      throw error;
    } finally {
      this.submitting.delete(jobId);
    }
  }

  startJobs(jobIds) {
    const unique = [...new Set(jobIds || [])];
    return settleAll(unique.map(jobId => this.startJob(jobId)));
  }

  activeRuns() {
    const result = [];
    for (const job of this.store.state.jobs) {
      for (const run of job.runs || []) {
        if (run.taskId && ACTIVE_RUN_STATUSES.has(run.status) && !['uploading', 'submitting'].includes(run.status)) result.push({ job, run });
      }
    }
    return result;
  }

  schedulePoll(delayMs) {
    if (this.stopped || this.pollTimer) return;
    this.pollTimer = setTimeout(() => {
      this.pollTimer = null;
      this.pollNow().catch(() => {});
    }, delayMs == null ? this.pollIntervalMs : delayMs);
  }

  async pollNow() {
    if (this.stopped || this.polling) return;
    const active = this.activeRuns();
    if (!active.length) return;
    this.polling = true;
    try {
      const client = await this.client();
      const response = await client.batchGetTasks(active.map(item => item.run.taskId));
      const records = Array.isArray(response && response.data) ? response.data : [];
      const byId = new Map(records.map(record => [taskRecordId(record), record]));
      const downloads = [];
      for (const item of active) {
        const record = byId.get(String(item.run.taskId));
        if (!record) continue;
        const status = taskRecordStatus(record, client);
        applyAccounting(item.run, record, client);
        item.run.updatedAt = Date.now();
        if (SUCCESS_STATUSES.has(status)) downloads.push(this.downloadRun(item.job, item.run, record, client));
        else if (FAILURE_STATUSES.has(status)) {
          item.run.status = 'failed';
          item.run.stage = 'failed';
          item.run.error = client.taskError(record) || status;
          item.run.completedAt = item.run.updatedAt;
        } else {
          item.run.status = status === 'queued' || status === 'requested' ? 'queued' : 'running';
          item.run.stage = item.run.status;
        }
      }
      this.changed();
      await settleAll(downloads);
    } catch (error) {
      for (const item of active) {
        item.run.pollFailures = (Number(item.run.pollFailures) || 0) + 1;
        item.run.lastPollError = safeMessage(error);
      }
      this.changed();
    } finally {
      this.polling = false;
      if (this.activeRuns().length) this.schedulePoll(this.pollIntervalMs);
    }
  }

  async downloadRun(job, run, record, client) {
    if (this.downloading.has(run.id)) return;
    this.downloading.add(run.id);
    run.status = 'downloading';
    run.stage = 'downloading';
    this.changed();
    try {
      const urls = client.extractVideoUrls(record).slice(0, Math.max(1, Math.min(2, Number(run.settings.outputCount) || 1)));
      if (!urls.length) throw new Error('KIVI 任务完成，但响应中没有找到视频地址');
      const directory = this.store.outputDirectory(job.id, run.id);
      const candidates = [];
      for (let index = 0; index < urls.length; index += 1) {
        const sequence = this.store.allocateCandidateSequence(job.id);
        const candidateName = `${safeFileName(job.name, 'KIVI')}-C${String(sequence).padStart(3, '0')}.mp4`;
        const destination = path.join(directory, candidateName);
        try {
          if (!fs.existsSync(destination)) await this.withRetry(() => client.downloadFile(urls[index], destination), 3);
          const header = fs.readFileSync(destination).subarray(0, 12).toString('latin1');
          if (!/ftyp/.test(header)) throw new Error('下载内容不是有效 MP4');
          candidates.push({ id: makeCandidateId(), sequence, remoteUrl: urls[index], localPath: destination, acceptedPath: '', status: 'ready', error: '', createdAt: Date.now() });
        } catch (error) {
          try { if (fs.existsSync(destination)) fs.unlinkSync(destination); } catch (_) {}
          candidates.push({ id: makeCandidateId(), sequence, remoteUrl: urls[index], localPath: '', acceptedPath: '', status: 'failed', error: safeMessage(error), createdAt: Date.now() });
        }
      }
      run.candidates = candidates;
      run.status = candidates.some(candidate => candidate.status === 'ready') ? 'completed' : 'failed';
      run.stage = run.status === 'completed' ? 'review' : 'failed';
      run.error = run.status === 'failed' ? candidates.map(candidate => candidate.error).filter(Boolean).join('；') : '';
      run.updatedAt = Date.now();
      run.completedAt = run.updatedAt;
      this.changed();
    } catch (error) {
      run.status = 'failed';
      run.stage = 'failed';
      run.error = safeMessage(error);
      run.updatedAt = Date.now();
      run.completedAt = run.updatedAt;
      this.changed();
    } finally {
      this.downloading.delete(run.id);
    }
  }

  resume() {
    if (this.activeRuns().length) this.schedulePoll(100);
  }

  resetClient() {
    this.clientPromise = null;
  }

  stop() {
    this.stopped = true;
    if (this.pollTimer) clearTimeout(this.pollTimer);
    this.pollTimer = null;
  }
}

module.exports = { KiviJobRunner, ACTIVE_RUN_STATUSES, taskRecordId };
