'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SCHEMA_VERSION = 5;
const PROMPT_HISTORY_LIMIT = 20;
const DEFAULT_SETTINGS = Object.freeze({
  model: 'seedance-2.0',
  ratio: '1:1',
  resolution: '720P',
  duration: 4,
  outputCount: 1
});

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function makeId(prefix) { return `${prefix}-${Date.now()}-${crypto.randomBytes(5).toString('hex')}`; }
function ensureDirectory(directory) {
  if (fs.existsSync(directory)) return;
  const parent = path.dirname(directory);
  if (parent && parent !== directory) ensureDirectory(parent);
  try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
}
function safeName(value, fallback) {
  const clean = String(value || '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').replace(/[. ]+$/g, '').trim();
  return clean || fallback;
}

function firstFile(directory, predicate) {
  if (!fs.existsSync(directory)) return '';
  const names = fs.readdirSync(directory);
  const name = names.find(candidate => {
    const target = path.join(directory, candidate);
    return fs.existsSync(target) && fs.statSync(target).isFile() && (!predicate || predicate(candidate));
  });
  return name ? path.join(directory, name) : '';
}

function normalizePromptState(state, reconcileInterrupted) {
  const item = Object.assign({
    status: 'idle',
    provider: '',
    model: '',
    skillId: '',
    skillVersion: 0,
    skillHash: '',
    generatedAt: 0,
    usage: null,
    requestId: '',
    summary: '',
    warnings: [],
    error: ''
  }, state || {});
  if (!['idle', 'queued', 'analyzing', 'ready', 'failed', 'interrupted'].includes(item.status)) item.status = 'idle';
  item.skillVersion = Math.max(0, Math.floor(Number(item.skillVersion) || 0));
  item.generatedAt = Math.max(0, Number(item.generatedAt) || 0);
  item.warnings = Array.isArray(item.warnings) ? item.warnings.map(value => String(value).slice(0, 300)).slice(0, 10) : [];
  item.error = String(item.error || '').slice(0, 500);
  if (reconcileInterrupted && ['queued', 'analyzing'].includes(item.status)) {
    item.status = 'interrupted';
    item.error = 'AE 在 Prompt 生成完成前关闭，可重新生成 Prompt';
  }
  return item;
}

function normalizePromptHistory(history) {
  return (Array.isArray(history) ? history : []).map(entry => Object.assign({
    id: makeId('prompt'),
    text: '',
    source: 'manual',
    provider: '',
    model: '',
    skillId: '',
    skillVersion: 0,
    skillHash: '',
    createdAt: Date.now()
  }, entry || {})).filter(entry => String(entry.text || '').trim()).slice(-PROMPT_HISTORY_LIMIT);
}

function normalizeCandidate(candidate) {
  const item = Object.assign({
    id: makeId('candidate'),
    sequence: 0,
    remoteUrl: '',
    localPath: '',
    acceptedPath: '',
    status: 'ready',
    rejectedFromStatus: '',
    error: '',
    createdAt: 0,
    acceptedAt: 0,
    rejectedAt: 0,
    addedToOriginAt: 0
  }, candidate || {});
  item.sequence = Math.max(0, Math.floor(Number(item.sequence) || 0));
  item.createdAt = Math.max(0, Number(item.createdAt) || 0);
  item.acceptedAt = Math.max(0, Number(item.acceptedAt) || 0);
  item.rejectedAt = Math.max(0, Number(item.rejectedAt) || 0);
  item.addedToOriginAt = Math.max(0, Number(item.addedToOriginAt) || 0);
  if (item.status !== 'rejected') item.rejectedFromStatus = '';
  if (item.status === 'accepted' && item.acceptedPath && !fs.existsSync(item.acceptedPath)) item.status = 'ready';
  const acceptedCopyExists = item.acceptedPath && fs.existsSync(item.acceptedPath);
  if (item.localPath && !fs.existsSync(item.localPath) && item.status !== 'failed' && !acceptedCopyExists) {
    item.status = 'missing';
    item.error = '本地候选视频不存在';
  }
  return item;
}

function normalizeRun(run, reconcileInterrupted) {
  const item = Object.assign({
    id: makeId('run'),
    taskId: '',
    status: 'failed',
    stage: 'failed',
    error: '',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    submittedAt: 0,
    completedAt: 0,
    mode: 'flf2v',
    prompt: '',
    promptSource: 'manual',
    promptProvider: '',
    promptModel: '',
    promptSkillVersion: 0,
    cost: 0,
    refund: false,
    kiviUserId: '',
    retryTimes: 0,
    settings: clone(DEFAULT_SETTINGS),
    candidates: []
  }, run || {});
  item.createdAt = Math.max(0, Number(item.createdAt) || Date.now());
  item.updatedAt = Math.max(0, Number(item.updatedAt) || item.createdAt);
  item.submittedAt = Math.max(0, Number(item.submittedAt) || 0);
  item.completedAt = Math.max(0, Number(item.completedAt) || 0);
  item.promptSource = item.promptSource === 'agent' ? 'agent' : 'manual';
  item.promptSkillVersion = Math.max(0, Math.floor(Number(item.promptSkillVersion) || 0));
  item.cost = Math.max(0, Number(item.cost) || 0);
  item.refund = item.refund === true;
  item.kiviUserId = String(item.kiviUserId || '');
  item.retryTimes = Math.max(0, Math.floor(Number(item.retryTimes) || 0));
  item.settings = Object.assign({}, DEFAULT_SETTINGS, item.settings || {});
  item.settings.outputCount = Math.max(1, Math.min(2, Number(item.settings.outputCount) || 1));
  item.candidates = Array.isArray(item.candidates) ? item.candidates.map(normalizeCandidate) : [];
  if (reconcileInterrupted && !item.taskId && ['uploading', 'submitting', 'queued', 'running', 'downloading'].includes(item.status)) {
    item.status = 'failed';
    item.stage = 'failed';
    item.error = 'AE 在云端任务创建前关闭，可重新生成此任务';
  }
  if (reconcileInterrupted && item.taskId && item.status === 'downloading') {
    item.status = 'running';
    item.stage = 'running';
  }
  return item;
}

function promptSnapshot(job, source) {
  const state = normalizePromptState(job && job.promptState, false);
  return {
    id: makeId('prompt'),
    text: String(job && job.prompt || ''),
    source: source || (state.status === 'ready' ? 'agent' : 'manual'),
    provider: state.provider,
    model: state.model,
    skillId: state.skillId,
    skillVersion: state.skillVersion,
    skillHash: state.skillHash,
    createdAt: Date.now()
  };
}

function normalizeJob(job, reconcileInterrupted) {
  const item = Object.assign({
    id: makeId('job'),
    name: '未命名任务',
    source: {},
    origin: null,
    nextCandidateSequence: 1,
    selected: false,
    archivedAt: 0,
    mode: 'flf2v',
    prompt: '',
    promptState: null,
    promptHistory: [],
    settings: clone(DEFAULT_SETTINGS),
    createdAt: Date.now(),
    updatedAt: Date.now(),
    runs: []
  }, job || {});
  item.source = Object.assign({}, item.source || {});
  item.archivedAt = Math.max(0, Number(item.archivedAt) || 0);
  if (item.archivedAt) item.selected = false;
  const originLayerName = String(item.origin && item.origin.layer && item.origin.layer.name || '').trim();
  const originSourceName = String(item.origin && item.origin.source && item.origin.source.name || '').trim();
  const sourceFileStem = path.basename(String(item.source.fileName || ''), path.extname(String(item.source.fileName || '')));
  if (!item.source.layerName && originLayerName) item.source.layerName = originLayerName;
  if (!item.source.sourceName && originSourceName) item.source.sourceName = originSourceName;
  if (originLayerName && (!String(item.name || '').trim() || item.name === '未命名任务' || item.name === originSourceName || item.name === sourceFileStem)) item.name = originLayerName;
  item.mode = item.mode === 'general_reference' ? 'general_reference' : 'flf2v';
  item.settings = Object.assign({}, DEFAULT_SETTINGS, item.settings || {});
  item.settings.duration = Number(item.settings.duration) || 4;
  item.settings.outputCount = Math.max(1, Math.min(2, Number(item.settings.outputCount) || 1));
  item.promptState = normalizePromptState(item.promptState, reconcileInterrupted);
  item.promptHistory = normalizePromptHistory(item.promptHistory);
  item.runs = Array.isArray(item.runs) ? item.runs.map(run => normalizeRun(run, reconcileInterrupted)) : [];
  const entries = [];
  item.runs.forEach((run, runIndex) => run.candidates.forEach((candidate, candidateIndex) => {
    entries.push({ run, runIndex, candidate, candidateIndex });
  }));
  const usedSequences = new Set();
  for (const entry of entries) {
    const sequence = Math.max(0, Math.floor(Number(entry.candidate.sequence) || 0));
    if (sequence && !usedSequences.has(sequence)) usedSequences.add(sequence);
    else entry.candidate.sequence = 0;
  }
  entries.filter(entry => !entry.candidate.sequence).sort((left, right) => {
    const leftTime = Number(left.candidate.createdAt) || Number(left.run.createdAt) || 0;
    const rightTime = Number(right.candidate.createdAt) || Number(right.run.createdAt) || 0;
    return leftTime - rightTime || left.runIndex - right.runIndex || left.candidateIndex - right.candidateIndex;
  }).forEach(entry => {
    let sequence = 1;
    while (usedSequences.has(sequence)) sequence += 1;
    entry.candidate.sequence = sequence;
    usedSequences.add(sequence);
  });
  const nextSequence = usedSequences.size ? Math.max.apply(null, Array.from(usedSequences)) + 1 : 1;
  item.nextCandidateSequence = Math.max(nextSequence, Math.floor(Number(item.nextCandidateSequence) || 1));
  return item;
}

function deriveJobStatus(job) {
  const runs = Array.isArray(job && job.runs) ? job.runs : [];
  if (runs.some(run => ['uploading', 'submitting', 'queued', 'running', 'downloading'].includes(run.status))) return 'generating';
  const candidates = runs.reduce((all, run) => all.concat(run.candidates || []), []);
  if (candidates.some(candidate => candidate.status === 'ready')) return 'review';
  if (candidates.some(candidate => candidate.status === 'accepted')) return 'accepted';
  if (candidates.some(candidate => candidate.status === 'rejected')) return 'review';
  if (runs.length && runs[runs.length - 1].status === 'failed') return 'failed';
  return 'draft';
}

function sortJobs(jobs, mode) {
  const list = (jobs || []).slice();
  const byRecent = (left, right) => Number(right.createdAt || 0) - Number(left.createdAt || 0) || String(left.id || '').localeCompare(String(right.id || ''));
  if (mode === 'oldest') return list.sort((left, right) => -byRecent(left, right));
  if (mode === 'name') return list.sort((left, right) => String(left.name || '').localeCompare(String(right.name || ''), 'zh-Hans-CN') || byRecent(left, right));
  if (mode === 'status') {
    const rank = { review: 0, generating: 1, accepted: 2, draft: 3, failed: 4 };
    return list.sort((left, right) => (rank[deriveJobStatus(left)] - rank[deriveJobStatus(right)]) || byRecent(left, right));
  }
  if (mode === 'generating') {
    const rank = { generating: 0, review: 1, draft: 2, accepted: 3, failed: 4 };
    return list.sort((left, right) => (rank[deriveJobStatus(left)] - rank[deriveJobStatus(right)]) || byRecent(left, right));
  }
  return list.sort(byRecent);
}

class KiviJobStore {
  constructor(root) {
    this.root = path.resolve(root);
    this.jobsFile = path.join(this.root, 'jobs.json');
    this.backupFile = path.join(this.root, 'jobs.json.bak');
    this.sourcesRoot = path.join(this.root, 'sources');
    this.outputsRoot = path.join(this.root, 'outputs');
    this.state = { schemaVersion: SCHEMA_VERSION, updatedAt: Date.now(), jobs: [] };
  }

  ensure() {
    ensureDirectory(this.root);
    ensureDirectory(this.sourcesRoot);
    ensureDirectory(this.outputsRoot);
  }

  parseState(filePath) {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, ''));
    if (!parsed || !Array.isArray(parsed.jobs)) throw new Error('任务文件结构无效');
    return {
      schemaVersion: SCHEMA_VERSION,
      updatedAt: Number(parsed.updatedAt) || Date.now(),
      jobs: parsed.jobs.map(job => normalizeJob(job, true))
    };
  }

  load() {
    this.ensure();
    if (!fs.existsSync(this.jobsFile)) {
      if (!fs.existsSync(this.backupFile)) return this.state;
      this.state = this.parseState(this.backupFile);
      this.save();
      return this.state;
    }
    try {
      this.state = this.parseState(this.jobsFile);
    } catch (error) {
      if (!fs.existsSync(this.backupFile)) throw new Error(`KIVI 任务库损坏：${error.message}`);
      this.state = this.parseState(this.backupFile);
      this.save();
    }
    return this.state;
  }

  save() {
    this.ensure();
    this.state.schemaVersion = SCHEMA_VERSION;
    this.state.updatedAt = Date.now();
    const temporary = `${this.jobsFile}.tmp-${process.pid}-${Date.now()}`;
    fs.writeFileSync(temporary, `${JSON.stringify(this.state, null, 2)}\n`, 'utf8');
    try {
      if (fs.existsSync(this.jobsFile)) fs.copyFileSync(this.jobsFile, this.backupFile);
      fs.renameSync(temporary, this.jobsFile);
    } catch (error) {
      try {
        if (fs.existsSync(this.jobsFile)) fs.unlinkSync(this.jobsFile);
        fs.renameSync(temporary, this.jobsFile);
      } catch (_) {
        try { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); } catch (_) {}
        throw error;
      }
    }
    return this.state;
  }

  addRenderedAssets(assets) {
    this.ensure();
    const created = [];
    for (const asset of assets || []) {
      const id = makeId('job');
      const sourceDirectory = path.join(this.sourcesRoot, id);
      ensureDirectory(sourceDirectory);
      const fileName = safeName(asset.fileName || path.basename(asset.path || ''), 'source.png');
      const sourcePath = path.join(sourceDirectory, fileName);
      fs.copyFileSync(asset.path, sourcePath);
      const job = normalizeJob({
        id,
        name: path.basename(fileName, path.extname(fileName)),
        source: {
          path: sourcePath,
          fileName,
          width: Number(asset.width) || 0,
          height: Number(asset.height) || 0
        },
        origin: asset.origin ? clone(asset.origin) : null,
        selected: false
      });
      this.state.jobs.unshift(job);
      created.push(job);
    }
    this.save();
    return created;
  }

  duplicateJob(jobId) {
    this.ensure();
    const sourceJob = this.findJob(jobId);
    if (!sourceJob) throw new Error('KIVI 任务不存在');
    const id = makeId('job');
    const sourceDirectory = path.join(this.sourcesRoot, id);
    ensureDirectory(sourceDirectory);
    const fileName = safeName(sourceJob.source && sourceJob.source.fileName, 'source.png');
    const sourcePath = path.join(sourceDirectory, fileName);
    if (!sourceJob.source || !sourceJob.source.path || !fs.existsSync(sourceJob.source.path)) throw new Error('任务源图片不存在，无法复制');
    fs.copyFileSync(sourceJob.source.path, sourcePath);
    const duplicate = normalizeJob({
      id,
      name: `${sourceJob.name} 方案`,
      source: Object.assign({}, clone(sourceJob.source), { path: sourcePath, fileName }),
      origin: sourceJob.origin ? clone(sourceJob.origin) : null,
      selected: false,
      archivedAt: 0,
      mode: sourceJob.mode,
      prompt: sourceJob.prompt,
      settings: clone(sourceJob.settings),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      nextCandidateSequence: 1,
      runs: []
    });
    const sourceIndex = this.state.jobs.findIndex(job => job.id === jobId);
    this.state.jobs.splice(sourceIndex < 0 ? 0 : sourceIndex + 1, 0, duplicate);
    this.save();
    return duplicate;
  }

  findJob(jobId) { return this.state.jobs.find(job => job.id === jobId) || null; }

  archiveJobs(jobIds) {
    const ids = new Set((jobIds || []).map(String));
    const archivedAt = Date.now();
    let count = 0;
    for (const job of this.state.jobs) {
      if (!ids.has(String(job.id)) || job.archivedAt) continue;
      job.archivedAt = archivedAt;
      job.selected = false;
      job.updatedAt = archivedAt;
      count += 1;
    }
    if (count) this.save();
    return count;
  }

  archiveJob(jobId) { return this.archiveJobs([jobId]) > 0; }

  restoreJobs(jobIds) {
    const ids = new Set((jobIds || []).map(String));
    const restoredAt = Date.now();
    let count = 0;
    for (const job of this.state.jobs) {
      if (!ids.has(String(job.id)) || !job.archivedAt) continue;
      job.archivedAt = 0;
      job.selected = false;
      job.updatedAt = restoredAt;
      count += 1;
    }
    if (count) this.save();
    return count;
  }

  restoreJob(jobId) { return this.restoreJobs([jobId]) > 0; }

  allocateCandidateSequence(jobId) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    const sequence = Math.max(1, Math.floor(Number(job.nextCandidateSequence) || 1));
    job.nextCandidateSequence = sequence + 1;
    job.updatedAt = Date.now();
    return sequence;
  }

  createRun(jobId) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    if (deriveJobStatus(job) === 'generating') throw new Error('该任务正在生成中');
    const promptState = normalizePromptState(job.promptState, false);
    const generatedByAgent = promptState.status === 'ready' && String(job.prompt || '').trim();
    const run = normalizeRun({
      id: makeId('run'),
      status: 'uploading',
      stage: 'uploading',
      mode: job.mode,
      prompt: job.prompt,
      promptSource: generatedByAgent ? 'agent' : 'manual',
      promptProvider: generatedByAgent ? promptState.provider : '',
      promptModel: generatedByAgent ? promptState.model : '',
      promptSkillVersion: generatedByAgent ? promptState.skillVersion : 0,
      settings: clone(job.settings),
      error: ''
    });
    job.runs.push(run);
    job.updatedAt = Date.now();
    this.save();
    return run;
  }

  setPromptState(jobId, patch) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    job.promptState = normalizePromptState(Object.assign({}, job.promptState || {}, patch || {}), false);
    job.updatedAt = Date.now();
    this.save();
    return job.promptState;
  }

  applyGeneratedPrompt(jobId, prompt, metadata) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    const nextPrompt = String(prompt || '').trim();
    if (!nextPrompt) throw new Error('Agent 返回了空 Prompt');
    if (String(job.prompt || '').trim() && String(job.prompt).trim() !== nextPrompt) {
      job.promptHistory.push(promptSnapshot(job));
      job.promptHistory = normalizePromptHistory(job.promptHistory);
    }
    const meta = metadata || {};
    job.prompt = nextPrompt;
    job.promptState = normalizePromptState({
      status: 'ready',
      provider: meta.provider || '',
      model: meta.model || '',
      skillId: meta.skillId || '',
      skillVersion: meta.skillVersion || 0,
      skillHash: meta.skillHash || '',
      generatedAt: Date.now(),
      usage: meta.usage || null,
      requestId: meta.requestId || '',
      summary: meta.summary || '',
      warnings: meta.warnings || [],
      error: ''
    }, false);
    job.updatedAt = Date.now();
    this.save();
    return job;
  }

  markPromptManual(jobId, prompt) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    const nextPrompt = String(prompt == null ? '' : prompt);
    if (job.promptState && job.promptState.status === 'ready' && String(job.prompt || '') !== nextPrompt) {
      if (String(job.prompt || '').trim()) job.promptHistory.push(promptSnapshot(job, 'agent'));
      job.promptHistory = normalizePromptHistory(job.promptHistory);
      job.promptState = normalizePromptState({ status: 'idle' }, false);
    }
    job.prompt = nextPrompt;
    job.updatedAt = Date.now();
    this.save();
    return job;
  }

  restorePrompt(jobId, historyId) {
    const job = this.findJob(jobId);
    if (!job) throw new Error('KIVI 任务不存在');
    const entry = (job.promptHistory || []).find(item => item.id === historyId);
    if (!entry) throw new Error('Prompt 历史版本不存在');
    if (String(job.prompt || '').trim() && String(job.prompt) !== String(entry.text)) {
      job.promptHistory.push(promptSnapshot(job, 'restore-backup'));
    }
    job.prompt = String(entry.text || '');
    job.promptState = normalizePromptState({
      status: entry.source === 'agent' ? 'ready' : 'idle',
      provider: entry.provider,
      model: entry.model,
      skillId: entry.skillId,
      skillVersion: entry.skillVersion,
      skillHash: entry.skillHash,
      generatedAt: entry.createdAt
    }, false);
    job.promptHistory = normalizePromptHistory(job.promptHistory.filter(item => item.id !== historyId));
    job.updatedAt = Date.now();
    this.save();
    return job;
  }

  outputDirectory(jobId, runId) {
    const directory = path.resolve(this.outputsRoot, jobId, runId);
    if (directory !== this.outputsRoot && !directory.startsWith(`${this.outputsRoot}${path.sep}`)) throw new Error('KIVI 输出目录越界');
    ensureDirectory(directory);
    return directory;
  }

  relinkPaths(importRoot) {
    this.ensure();
    const acceptedRoot = path.join(importRoot, 'Kivi Videos');
    let repairedSources = 0;
    let repairedCandidates = 0;
    let repairedAccepted = 0;
    let changed = false;
    for (const job of this.state.jobs) {
      const sourceDirectory = path.join(this.sourcesRoot, job.id);
      if (!job.source) job.source = {};
      if (!job.source.path || !fs.existsSync(job.source.path)) {
        const exactSource = job.source.fileName ? path.join(sourceDirectory, job.source.fileName) : '';
        const sourcePath = exactSource && fs.existsSync(exactSource) ? exactSource : firstFile(sourceDirectory);
        if (sourcePath) {
          job.source.path = sourcePath;
          job.source.fileName = path.basename(sourcePath);
          repairedSources += 1;
          changed = true;
        }
      }
      for (const run of job.runs || []) {
        const outputDirectory = path.join(this.outputsRoot, job.id, run.id);
        for (const candidate of run.candidates || []) {
          if (!candidate.localPath || !fs.existsSync(candidate.localPath)) {
            const oldName = path.basename(candidate.localPath || '');
            const numbered = candidate.sequence ? `-C${String(candidate.sequence).padStart(3, '0')}.mp4` : '';
            const localPath = oldName && fs.existsSync(path.join(outputDirectory, oldName))
              ? path.join(outputDirectory, oldName)
              : firstFile(outputDirectory, name => !numbered || name.toLowerCase().endsWith(numbered.toLowerCase()));
            if (localPath) {
              candidate.localPath = localPath;
              repairedCandidates += 1;
              changed = true;
            }
          }
          if (candidate.acceptedPath && !fs.existsSync(candidate.acceptedPath)) {
            const acceptedName = path.basename(candidate.acceptedPath);
            const acceptedPath = acceptedName && fs.existsSync(path.join(acceptedRoot, acceptedName))
              ? path.join(acceptedRoot, acceptedName)
              : '';
            if (acceptedPath) {
              candidate.acceptedPath = acceptedPath;
              repairedAccepted += 1;
              changed = true;
            }
          }
          const localExists = candidate.localPath && fs.existsSync(candidate.localPath);
          const acceptedExists = candidate.acceptedPath && fs.existsSync(candidate.acceptedPath);
          if (candidate.status === 'missing' && (localExists || acceptedExists)) {
            candidate.status = acceptedExists ? 'accepted' : 'ready';
            candidate.error = '';
            changed = true;
          }
        }
      }
    }
    if (changed) this.save();
    return { repairedSources, repairedCandidates, repairedAccepted, changed };
  }

  removeJobs(jobIds) {
    const ids = new Set((jobIds || []).map(String));
    const removed = this.state.jobs.filter(job => ids.has(String(job.id)));
    if (!removed.length) return 0;
    this.state.jobs = this.state.jobs.filter(job => !ids.has(String(job.id)));
    for (const job of removed) {
      for (const root of [this.sourcesRoot, this.outputsRoot]) {
        const target = path.resolve(root, job.id);
        if (target.startsWith(`${root}${path.sep}`)) this.removeDirectory(target);
      }
    }
    this.save();
    return removed.length;
  }

  removeJob(jobId) { return this.removeJobs([jobId]) > 0; }

  removeDirectory(directory) {
    if (!fs.existsSync(directory)) return;
    for (const name of fs.readdirSync(directory)) {
      const target = path.join(directory, name);
      const stat = fs.lstatSync(target);
      if (stat.isDirectory()) this.removeDirectory(target);
      else fs.unlinkSync(target);
    }
    fs.rmdirSync(directory);
  }
}

module.exports = { KiviJobStore, DEFAULT_SETTINGS, SCHEMA_VERSION, PROMPT_HISTORY_LIMIT, deriveJobStatus, sortJobs, normalizeJob, normalizeRun, normalizePromptState };
