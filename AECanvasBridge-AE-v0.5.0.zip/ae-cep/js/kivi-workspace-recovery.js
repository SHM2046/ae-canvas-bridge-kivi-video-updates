'use strict';

const fs = require('fs');
const path = require('path');

const IMPORT_DIRECTORY = 'Canvas Bridge 导入';
const WORKSPACE_DIRECTORY = '_KIVI任务工作区';

function samePath(left, right) {
  if (!left || !right) return false;
  return path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase();
}

function isAutoSaveDirectory(directory) {
  return /after effects auto-save/i.test(path.basename(String(directory || '')));
}

function projectFamilyRoot(projectDirectory) {
  const resolved = path.resolve(projectDirectory);
  return isAutoSaveDirectory(resolved) ? path.dirname(resolved) : resolved;
}

function workspacePath(projectRoot) {
  return path.join(projectRoot, IMPORT_DIRECTORY, WORKSPACE_DIRECTORY);
}

function hasWorkspace(projectRoot) {
  return fs.existsSync(path.join(workspacePath(projectRoot), 'jobs.json'))
    || fs.existsSync(path.join(workspacePath(projectRoot), 'jobs.json.bak'));
}

function projectRootFromSelection(selectedPath) {
  let selected = path.resolve(selectedPath);
  if (path.basename(selected).toLowerCase() === WORKSPACE_DIRECTORY.toLowerCase()) selected = path.dirname(selected);
  if (path.basename(selected).toLowerCase() === IMPORT_DIRECTORY.toLowerCase()) selected = path.dirname(selected);
  return selected;
}

function resolveProjectRoot(options) {
  const projectDirectory = path.resolve(options.projectDirectory);
  const familyRoot = projectFamilyRoot(projectDirectory);
  const selectedRoot = options.selectedPath ? projectRootFromSelection(options.selectedPath) : '';
  const savedRoot = options.savedRoot ? path.resolve(options.savedRoot) : '';

  if (selectedRoot) {
    return { projectRoot: selectedRoot, workspaceRoot: workspacePath(selectedRoot), recovered: !samePath(selectedRoot, projectDirectory), source: 'manual' };
  }

  const candidates = [];
  const add = (root, source, score) => {
    if (!root || candidates.some(candidate => samePath(candidate.root, root))) return;
    candidates.push({ root: path.resolve(root), source, score });
  };
  if (savedRoot && hasWorkspace(savedRoot)) add(savedRoot, 'saved', 70);
  add(projectDirectory, 'current', isAutoSaveDirectory(projectDirectory) ? 20 : 50);
  if (isAutoSaveDirectory(projectDirectory)) add(familyRoot, 'auto-save-parent', 60);

  const existing = candidates.filter(candidate => hasWorkspace(candidate.root)).sort((a, b) => b.score - a.score);
  const selected = existing[0] || candidates.find(candidate => candidate.source === 'current') || { root: projectDirectory, source: 'current' };
  return {
    projectRoot: selected.root,
    workspaceRoot: workspacePath(selected.root),
    recovered: !samePath(selected.root, projectDirectory),
    source: selected.source
  };
}

module.exports = {
  IMPORT_DIRECTORY,
  WORKSPACE_DIRECTORY,
  hasWorkspace,
  isAutoSaveDirectory,
  projectFamilyRoot,
  projectRootFromSelection,
  resolveProjectRoot,
  samePath,
  workspacePath
};
