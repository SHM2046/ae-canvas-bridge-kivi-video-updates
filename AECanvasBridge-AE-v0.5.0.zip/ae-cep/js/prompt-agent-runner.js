'use strict';

const path = require('path');
const ACTIVE_PROMPT_STATUSES = new Set(['queued', 'analyzing']);

function safeError(error) { return String(error && error.message ? error.message : error || 'Prompt 生成失败').slice(0, 500); }

class PromptAgentRunner {
  constructor(options) {
    this.store = options.store;
    this.createProvider = options.createProvider;
    this.readSkill = options.readSkill;
    this.onChange = options.onChange || function () {};
    this.concurrency = Math.max(1, Number(options.concurrency) || 3);
    this.batch = null;
  }

  changed() {
    this.store.save();
    this.onChange(this.store.state);
  }

  isRunning() { return !!(this.batch && !this.batch.finished); }

  cancelPending() {
    if (!this.batch || this.batch.finished) return 0;
    this.batch.cancelled = true;
    let cancelled = 0;
    for (const jobId of this.batch.queue.slice(this.batch.cursor)) {
      const job = this.store.findJob(jobId);
      if (job && job.promptState && job.promptState.status === 'queued') {
        job.promptState.status = 'interrupted';
        job.promptState.error = '已取消排队';
        job.updatedAt = Date.now();
        cancelled += 1;
      }
    }
    this.batch.cursor = this.batch.queue.length;
    this.changed();
    return cancelled;
  }

  async runOne(jobId, batch) {
    const job = this.store.findJob(jobId);
    if (!job || batch.cancelled) return { status: 'cancelled', jobId };
    job.promptState.status = 'analyzing';
    job.promptState.error = '';
    job.updatedAt = Date.now();
    this.changed();
    try {
      const sourcePath = path.resolve(String(job.source && job.source.path || ''));
      const sourcesRoot = path.resolve(this.store.sourcesRoot);
      if (sourcePath !== sourcesRoot && !sourcePath.startsWith(`${sourcesRoot}${path.sep}`)) throw new Error('Agent 拒绝读取任务工作区以外的图片');
      const skill = await Promise.resolve(this.readSkill());
      if (!skill || !String(skill.content || '').trim()) throw new Error('请先在 Agent 调试中导入并启用 Markdown Skill');
      const provider = await Promise.resolve(this.createProvider());
      const result = await provider.generatePrompt({ imagePath: job.source && job.source.path, job, skill });
      this.store.applyGeneratedPrompt(jobId, result.prompt, Object.assign({}, result, {
        skillId: skill.id,
        skillVersion: skill.version,
        skillHash: skill.hash
      }));
      this.onChange(this.store.state);
      return { status: 'fulfilled', jobId, value: result };
    } catch (error) {
      const current = this.store.findJob(jobId);
      if (current) {
        current.promptState.status = 'failed';
        current.promptState.error = safeError(error);
        current.updatedAt = Date.now();
        this.changed();
      }
      return { status: 'rejected', jobId, reason: error };
    }
  }

  async startJobs(jobIds, options) {
    if (this.isRunning()) throw new Error('已有一批 Prompt 正在生成');
    options = options || {};
    const onlyBlank = !!options.onlyBlank;
    const queue = [];
    for (const id of [...new Set(jobIds || [])]) {
      const job = this.store.findJob(id);
      if (!job || ACTIVE_PROMPT_STATUSES.has(job.promptState && job.promptState.status)) continue;
      if (onlyBlank && String(job.prompt || '').trim()) continue;
      queue.push(id);
      job.promptState.status = 'queued';
      job.promptState.error = '';
      job.updatedAt = Date.now();
    }
    if (!queue.length) throw new Error('没有符合条件的 Prompt 任务');
    this.changed();
    const batch = { queue, cursor: 0, cancelled: false, finished: false, results: [] };
    this.batch = batch;
    const worker = async () => {
      while (!batch.cancelled) {
        const index = batch.cursor++;
        if (index >= batch.queue.length) return;
        batch.results[index] = await this.runOne(batch.queue[index], batch);
      }
    };
    try {
      await Promise.all(Array.from({ length: Math.min(this.concurrency, queue.length) }, worker));
      return batch.results.filter(Boolean);
    } finally {
      batch.finished = true;
      this.onChange(this.store.state);
    }
  }
}

module.exports = { PromptAgentRunner, ACTIVE_PROMPT_STATUSES };
