param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('set', 'exists', 'read', 'clear')]
  [string]$Action,
  [Parameter(Mandatory = $true)]
  [string]$Path
)

$ErrorActionPreference = 'Stop'
function Write-Result([string]$Value) { [Console]::Out.Write($Value) }

if ($Action -eq 'exists') {
  Write-Result ($(if (Test-Path -LiteralPath $Path) { '1' } else { '0' }))
  exit 0
}
if ($Action -eq 'clear') {
  if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force }
  Write-Result 'cleared'
  exit 0
}

$securityModule = Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1'
if (Test-Path -LiteralPath $securityModule) { Import-Module $securityModule -Force }

if ($Action -eq 'read') {
  if (-not (Test-Path -LiteralPath $Path)) { throw 'Credential is not configured.' }
  $secure = ConvertTo-SecureString -String (Get-Content -LiteralPath $Path -Raw)
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { Write-Result ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  exit 0
}

$value = [Console]::In.ReadToEnd().Trim()
if ([string]::IsNullOrWhiteSpace($value)) { throw 'Credential value is required.' }
$directory = Split-Path -Parent $Path
if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
$secure = ConvertTo-SecureString -String $value -AsPlainText -Force
[System.IO.File]::WriteAllText($Path, (ConvertFrom-SecureString -SecureString $secure), [System.Text.Encoding]::ASCII)
Write-Result 'saved'
