var CanvasBridge = CanvasBridge || {};

CanvasBridge._json = function (value) {
  function esc(text) {
    return String(text).replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
  }
  function encode(item) {
    var i, parts = [];
    if (item === null || item === undefined) return "null";
    if (typeof item === "number" || typeof item === "boolean") return String(item);
    if (typeof item === "string") return "\"" + esc(item) + "\"";
    if (item instanceof Array) {
      for (i = 0; i < item.length; i += 1) parts.push(encode(item[i]));
      return "[" + parts.join(",") + "]";
    }
    if (typeof item === "object") {
      for (i in item) if (item.hasOwnProperty(i)) parts.push("\"" + esc(i) + "\":" + encode(item[i]));
      return "{" + parts.join(",") + "}";
    }
    return "null";
  }
  return encode(value);
};

CanvasBridge._error = function (error) {
  return CanvasBridge._json({ ok: false, error: error.toString().replace(/^Error:\s*/, "") });
};

CanvasBridge._itemById = function (id) {
  if (!app.project) throw new Error("当前没有打开项目");
  for (var i = 1; i <= app.project.numItems; i += 1) if (app.project.item(i).id === Number(id)) return app.project.item(i);
  throw new Error("找不到项目素材，可能已被删除");
};

CanvasBridge._itemInfo = function (item) {
  if (item instanceof CompItem) {
    return { id: item.id, kind: "comp", name: item.name, width: item.width, height: item.height, time: item.time };
  }
  if (item instanceof FootageItem && item.mainSource instanceof FileSource && item.file && item.mainSource.isStill) {
    var name = item.file.name, dot = name.lastIndexOf("."), extension = dot >= 0 ? name.substring(dot + 1).toLowerCase() : "";
    return { id: item.id, kind: "image", name: item.name, width: item.width, height: item.height, extension: extension };
  }
  throw new Error("“" + item.name + "”不是合成或静态图片");
};

CanvasBridge._propertyValue = function (group, matchName, fallback) {
  try {
    var property = group && group.property(matchName);
    return property ? property.value : fallback;
  } catch (ignored) { return fallback; }
};

CanvasBridge._layerInfo = function (comp, layer) {
  var transform = layer.property("ADBE Transform Group");
  var layerId = 0, parentId = 0;
  try { layerId = Number(layer.id) || 0; } catch (ignoredLayerId) {}
  try { parentId = layer.parent ? (Number(layer.parent.id) || 0) : 0; } catch (ignoredParentId) {}
  return {
    id: layerId,
    index: layer.index,
    name: layer.name,
    sourceItemId: layer.source ? layer.source.id : 0,
    sourceName: layer.source ? layer.source.name : "",
    sourceWidth: layer.source ? layer.source.width : 0,
    sourceHeight: layer.source ? layer.source.height : 0,
    compId: comp.id,
    compName: comp.name,
    compTime: comp.time,
    inPoint: layer.inPoint,
    outPoint: layer.outPoint,
    startTime: layer.startTime,
    stretch: layer.stretch,
    parentLayerId: parentId,
    threeDLayer: !!layer.threeDLayer,
    transform: {
      anchorPoint: CanvasBridge._propertyValue(transform, "ADBE Anchor Point", [0, 0]),
      position: CanvasBridge._propertyValue(transform, "ADBE Position", [0, 0]),
      scale: CanvasBridge._propertyValue(transform, "ADBE Scale", [100, 100]),
      rotation: CanvasBridge._propertyValue(transform, "ADBE Rotate Z", 0),
      opacity: CanvasBridge._propertyValue(transform, "ADBE Opacity", 100)
    }
  };
};

CanvasBridge.getSelectionInfo = function () {
  try {
    if (!app.project) throw new Error("\u5f53\u524d\u6ca1\u6709\u6253\u5f00\u9879\u76ee");
    var active = app.project.activeItem;
    if (!(active instanceof CompItem)) throw new Error("\u8bf7\u5148\u6fc0\u6d3b\u9700\u8981\u8f7d\u5165\u7684\u5408\u6210\uff0c\u5e76\u5728\u65f6\u95f4\u7ebf\u56fe\u5c42\u7a97\u53e3\u4e2d\u9009\u4e2d\u56fe\u7247\u6216\u5408\u6210\u56fe\u5c42");
    var layerCandidates = [], i, source, layer, info, layerInfo, stableLayerId;
    for (i = 0; i < active.selectedLayers.length; i += 1) {
      layer = active.selectedLayers[i];
      source = layer.source;
      if (source) {
        try {
          info = CanvasBridge._itemInfo(source);
          layerInfo = CanvasBridge._layerInfo(active, layer);
          stableLayerId = layerInfo.id || layerInfo.index;
          info.sourceName = info.name;
          info.layerName = layerInfo.name;
          info.name = layerInfo.name;
          info.id = "layer-" + active.id + "-" + stableLayerId + "-" + layerInfo.index;
          info.sourceItemId = source.id;
          info.projectPath = app.project.file ? app.project.file.fsName : "";
          info.comp = { id: active.id, name: active.name, width: active.width, height: active.height, time: active.time };
          info.layer = layerInfo;
          layerCandidates.push(info);
        } catch (ignoredLayer) {}
      }
    }
    if (!layerCandidates.length) throw new Error("\u8bf7\u5728\u5f53\u524d\u5408\u6210\u7684\u65f6\u95f4\u7ebf\u56fe\u5c42\u7a97\u53e3\u4e2d\u9009\u4e2d\u56fe\u7247\u6216\u5408\u6210\u56fe\u5c42\u3002Project \u9762\u677f\u7684\u9009\u62e9\u4f1a\u88ab\u5ffd\u7565\u3002");
    return CanvasBridge._json({ ok: true, items: layerCandidates, selectionSource: "timeline", projectPath: app.project.file ? app.project.file.fsName : "" });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge.getProjectDirectory = function () {
  try {
    if (!app.project) throw new Error("当前没有打开工程");
    if (!app.project.file) throw new Error("AE 工程尚未保存，请先保存工程或选择自定义目录");
    return CanvasBridge._json({ ok: true, path: app.project.file.parent.fsName });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge._findOrCreateFolder = function (name, parentFolder) {
  var i, item;
  for (i = 1; i <= app.project.numItems; i += 1) {
    item = app.project.item(i);
    if (item instanceof FolderItem && item.name === name && (!parentFolder || item.parentFolder === parentFolder)) return item;
  }
  item = app.project.items.addFolder(name);
  if (parentFolder) item.parentFolder = parentFolder;
  return item;
};

CanvasBridge.importBridgeAsset = function (filePath, nodeType, folderName) {
  try {
    if (!app.project) throw new Error("当前没有打开工程");
    if (!app.project.file) throw new Error("请先保存 AE 工程，再导入素材");
    var file = new File(filePath);
    if (!file.exists) throw new Error("待导入文件不存在：" + filePath);
    var rootFolder = CanvasBridge._findOrCreateFolder("Canvas Bridge 导入", null);
    var childName = folderName || (nodeType === "video" ? "Kivi Videos" : "Kivi Images");
    var childFolder = CanvasBridge._findOrCreateFolder(childName, rootFolder);
    var options = new ImportOptions(file);
    var item = app.project.importFile(options);
    item.parentFolder = childFolder;
    return CanvasBridge._json({ ok: true, itemId: item.id, itemName: item.name, folderName: childFolder.name, path: file.fsName });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge.importKiviAsset = function (filePath, nodeType, displayName) {
  var resultText = CanvasBridge.importBridgeAsset(filePath, nodeType, nodeType === "video" ? "Kivi Videos" : "Kivi Images");
  try {
    var result = eval("(" + resultText + ")");
    if (!result.ok || !displayName) return resultText;
    var item = CanvasBridge._itemById(result.itemId);
    item.name = String(displayName).replace(/[\\\/:*?\"<>|]/g, "_");
    result.itemName = item.name;
    return CanvasBridge._json(result);
  } catch (error) { return resultText; }
};

CanvasBridge.relinkKiviAssets = function (payloadText) {
  app.beginUndoGroup("Canvas Bridge 恢复 KIVI 素材");
  try {
    if (!app.project) throw new Error("当前没有打开工程");
    var payload = CanvasBridge._parsePayload(payloadText), paths = payload.paths || [];
    var rootFolder = CanvasBridge._findOrCreateFolder("Canvas Bridge 导入", null);
    var videoFolder = CanvasBridge._findOrCreateFolder("Kivi Videos", rootFolder);
    var linked = 0, relinked = 0, imported = 0, skipped = 0, i, j, file, item, found;
    for (i = 0; i < paths.length; i += 1) {
      file = new File(paths[i]);
      if (!file.exists) { skipped += 1; continue; }
      found = null;
      for (j = 1; j <= app.project.numItems; j += 1) {
        item = app.project.item(j);
        if (!(item instanceof FootageItem) || !(item.mainSource instanceof FileSource)) continue;
        if (item.file && CanvasBridge._samePath(item.file.fsName, file.fsName)) { found = item; linked += 1; break; }
      }
      if (found) continue;
      for (j = 1; j <= app.project.numItems; j += 1) {
        item = app.project.item(j);
        if (!(item instanceof FootageItem) || !(item.mainSource instanceof FileSource) || item.name !== file.name) continue;
        var currentExists = false;
        try { currentExists = !!(item.file && item.file.exists); } catch (ignoredMissingFile) {}
        if (!currentExists) {
          item.replace(file);
          item.parentFolder = videoFolder;
          found = item;
          relinked += 1;
          break;
        }
      }
      if (found) continue;
      var options = new ImportOptions(file);
      item = app.project.importFile(options);
      item.parentFolder = videoFolder;
      imported += 1;
    }
    return CanvasBridge._json({ ok: true, linked: linked, relinked: relinked, imported: imported, skipped: skipped });
  } catch (error) { return CanvasBridge._error(error); }
  finally { app.endUndoGroup(); }
};

CanvasBridge.renameProjectItem = function (itemId, nextName) {
  try {
    var item = CanvasBridge._itemById(itemId);
    var name = String(nextName || item.name);
    item.name = name;
    return CanvasBridge._json({ ok: true, itemId: item.id, itemName: item.name });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge.addAssetToActiveComp = function (filePath, nodeType, folderName) {
  try {
    if (!app.project) throw new Error("当前没有打开工程");
    var active = app.project.activeItem;
    if (!(active instanceof CompItem)) throw new Error("请先打开一个合成，再把素材加入时间线");
    var file = new File(filePath);
    if (!file.exists) throw new Error("素材文件不存在：" + filePath);
    var imported = CanvasBridge.importBridgeAsset(filePath, nodeType, folderName || (nodeType === "video" ? "Kivi Videos" : "Kivi Images"));
    var result = eval("(" + imported + ")");
    if (!result.ok) throw new Error(result.error);
    var item = CanvasBridge._itemById(result.itemId);
    var layer = active.layers.add(item);
    layer.startTime = active.time;
    return CanvasBridge._json({ ok: true, itemId: item.id, itemName: item.name, layerName: layer.name, compName: active.name });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge.preparePreviewSource = function (itemId, targetPath) {
  var tempComp = null;
  try {
    var item = CanvasBridge._itemById(itemId);
    var info = CanvasBridge._itemInfo(item);
    var output = new File(targetPath);
    if (item instanceof CompItem) {
      item.saveFrameToPng(item.time, output);
    } else {
      tempComp = app.project.items.addComp("__CanvasBridgePreview__", item.width, item.height, 1, 1, 1);
      tempComp.layers.add(item);
      tempComp.saveFrameToPng(0, output);
    }
    return CanvasBridge._json({ ok: true, id: item.id, path: output.fsName, width: info.width, height: info.height, temporary: true });
  } catch (error) { return CanvasBridge._error(error); }
  finally { if (tempComp) tempComp.remove(); }
};

CanvasBridge._hexColor = function (hex) {
  var clean = String(hex || "").replace("#", "");
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) throw new Error("自定义背景颜色无效");
  return [parseInt(clean.substring(0, 2), 16) / 255, parseInt(clean.substring(2, 4), 16) / 255, parseInt(clean.substring(4, 6), 16) / 255];
};

CanvasBridge.renderBatchAsset = function (itemId, targetPath, width, height, backgroundHex, x, y, scaleMultiplier, rotationDegrees, fitRatio) {
  var tempComp = null;
  try {
    width = Math.round(Number(width));
    height = Math.round(Number(height));
    x = Number(x); y = Number(y); scaleMultiplier = Number(scaleMultiplier); rotationDegrees = Number(rotationDegrees) || 0;
    fitRatio = Number(fitRatio);
    if (!(fitRatio > 0 && fitRatio <= 1)) fitRatio = 0.8;
    if (!(width >= 64 && width <= 8192 && height >= 64 && height <= 8192)) throw new Error("输出尺寸必须在 64–8192 像素之间");
    var item = CanvasBridge._itemById(itemId);
    var info = CanvasBridge._itemInfo(item);
    tempComp = app.project.items.addComp("__CanvasBridgeRender__", width, height, 1, 1, 1);
    if (backgroundHex) tempComp.layers.addSolid(CanvasBridge._hexColor(backgroundHex), "Canvas Bridge Background", width, height, 1, 1);
    var layer = tempComp.layers.add(item);
    if (item instanceof CompItem) layer.startTime = -item.time;
    var fit = Math.min(width / info.width, height / info.height) * 100 * fitRatio * scaleMultiplier;
    layer.property("ADBE Transform Group").property("ADBE Scale").setValue([fit, fit]);
    layer.property("ADBE Transform Group").property("ADBE Position").setValue([x * width, y * height]);
    layer.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(rotationDegrees);
    var output = new File(targetPath);
    tempComp.saveFrameToPng(0, output);
    return CanvasBridge._json({ ok: true, id: item.id, path: output.fsName, fileName: item.name + ".png", mimeType: "image/png", width: width, height: height, sourceType: info.kind, temporary: true });
  } catch (error) { return CanvasBridge._error(error); }
  finally { if (tempComp) tempComp.remove(); }
};

CanvasBridge.getProjectContext = function () {
  try {
    if (!app.project) throw new Error("当前没有打开工程");
    if (!app.project.file) throw new Error("AE 工程尚未保存，请先保存工程");
    return CanvasBridge._json({
      ok: true,
      path: app.project.file.parent.fsName,
      projectPath: app.project.file.fsName,
      projectName: app.project.file.name
    });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge._parsePayload = function (payloadText) {
  if (!payloadText) throw new Error("缺少操作参数");
  return eval("(" + payloadText + ")");
};

CanvasBridge._samePath = function (left, right) {
  try { return new File(left).fsName.toLowerCase() === new File(right).fsName.toLowerCase(); }
  catch (ignored) { return String(left || "").toLowerCase() === String(right || "").toLowerCase(); }
};

CanvasBridge._sameProjectFamily = function (currentPath, originPath) {
  if (CanvasBridge._samePath(currentPath, originPath)) return true;
  var currentFile = new File(currentPath), originFile = new File(originPath);
  if (!currentFile.parent || !currentFile.parent.parent || !originFile.parent) return false;
  var autoSaveFolder = String(currentFile.parent.name || "");
  if (!/after effects auto-save/i.test(autoSaveFolder)) return false;
  if (!CanvasBridge._samePath(currentFile.parent.parent.fsName, originFile.parent.fsName)) return false;
  var normalizeName = function (name) {
    return String(name || "").replace(/\.aep$/i, "").replace(/[\s_-]*auto[- ]?save[\s_-]*\d*$/i, "").toLowerCase();
  };
  var currentName = normalizeName(currentFile.name), originName = normalizeName(originFile.name);
  return !!currentName && !!originName && (currentName.indexOf(originName) === 0 || originName.indexOf(currentName) === 0);
};

CanvasBridge._compById = function (id) {
  var item = CanvasBridge._itemById(id);
  if (!(item instanceof CompItem)) throw new Error("记录中的原始合成已不存在");
  return item;
};

CanvasBridge._normalizeIdentityName = function (value) {
  return String(value || "")
    .replace(/\.[a-z0-9]{2,5}$/i, "")
    .replace(/^(KIVI_|CB_KIVI_|原始对照_|原始素材_)/i, "")
    .replace(/[\s_\-\u2013\u2014\[\]()（）【】]+/g, "")
    .replace(/(副本|方案|comp\d*)$/i, "")
    .toLowerCase();
};

CanvasBridge._namesSimilar = function (left, right) {
  var a = CanvasBridge._normalizeIdentityName(left), b = CanvasBridge._normalizeIdentityName(right);
  if (!a || !b) return false;
  if (a === b) return true;
  return Math.min(a.length, b.length) >= 4 && (a.indexOf(b) >= 0 || b.indexOf(a) >= 0);
};

CanvasBridge._compByOrigin = function (originComp) {
  var id = Number(originComp && originComp.id) || 0, i, item, matches = [];
  if (id) {
    try {
      item = CanvasBridge._itemById(id);
      if (item instanceof CompItem) return item;
    } catch (ignoredId) {}
  }
  var name = String(originComp && originComp.name || ""), similar = [];
  if (!name) throw new Error("任务没有保存原始合成信息，请使用“手动替换原始”");
  for (i = 1; i <= app.project.numItems; i += 1) {
    item = app.project.item(i);
    if (!(item instanceof CompItem)) continue;
    if (item.name === name) matches.push(item);
    else if (CanvasBridge._namesSimilar(item.name, name)
      && (!Number(originComp.width) || Number(item.width) === Number(originComp.width))
      && (!Number(originComp.height) || Number(item.height) === Number(originComp.height))) similar.push(item);
  }
  if (matches.length === 1) return matches[0];
  if (matches.length > 1) throw new Error("存在多个同名原始合成，无法安全恢复，请使用“手动替换原始”");
  if (similar.length === 1) return similar[0];
  if (similar.length > 1) throw new Error("存在多个相似名称的原始合成，无法安全恢复，请使用“手动替换原始”");
  throw new Error("记录中的原始合成已不存在，请使用“手动替换原始”");
};

CanvasBridge._numberNear = function (left, right, tolerance) {
  return Math.abs(Number(left) - Number(right)) <= (tolerance || 0.01);
};

CanvasBridge._layerTransformMatches = function (layer, originLayer) {
  var saved = originLayer && originLayer.transform;
  if (!saved) return false;
  var current = CanvasBridge._layerInfo(layer.containingComp, layer).transform;
  var pairs = [[current.position, saved.position], [current.scale, saved.scale], [current.anchorPoint, saved.anchorPoint]], i;
  for (i = 0; i < pairs.length; i += 1) {
    if (!pairs[i][0] || !pairs[i][1] || !CanvasBridge._numberNear(pairs[i][0][0], pairs[i][1][0], 0.5) || !CanvasBridge._numberNear(pairs[i][0][1], pairs[i][1][1], 0.5)) return false;
  }
  return CanvasBridge._numberNear(current.rotation, saved.rotation, 0.1);
};

CanvasBridge._layerByOrigin = function (comp, originLayer, jobId) {
  var i, layer, matches = [], transformMatches = [], nameMatches = [], sourceNameMatches = [], legacyWrapperMatches = [];
  var layerId = Number(originLayer && originLayer.id) || 0;
  if (layerId) {
    for (i = 1; i <= comp.numLayers; i += 1) {
      layer = comp.layer(i);
      try { if (Number(layer.id) === layerId) return layer; } catch (ignoredId) {}
    }
  }
  i = Number(originLayer && originLayer.index) || 0;
  if (i >= 1 && i <= comp.numLayers) {
    layer = comp.layer(i);
    var sourceMatches = layer.source && Number(layer.source.id) === Number(originLayer.sourceItemId);
    if (layer.name === originLayer.name && sourceMatches) return layer;
  }
  for (i = 1; i <= comp.numLayers; i += 1) {
    layer = comp.layer(i);
    if (String(layer.comment || "").indexOf("CBKIVI_REPLACEMENT:") === 0) continue;
    if (layer.source && Number(layer.source.id) === Number(originLayer && originLayer.sourceItemId)) matches.push(layer);
  }
  if (matches.length === 1) return matches[0];
  for (i = 0; i < matches.length; i += 1) if (CanvasBridge._layerTransformMatches(matches[i], originLayer)) transformMatches.push(matches[i]);
  if (transformMatches.length === 1) return transformMatches[0];
  for (i = 1; i <= comp.numLayers; i += 1) {
    layer = comp.layer(i);
    if (String(layer.comment || "").indexOf("CBKIVI_REPLACEMENT:") === 0) continue;
    if (!CanvasBridge._namesSimilar(layer.name, originLayer && originLayer.name)) continue;
    nameMatches.push(layer);
    if (layer.source
      && CanvasBridge._namesSimilar(layer.source.name, originLayer && originLayer.sourceName)
      && (!Number(originLayer.sourceWidth) || Number(layer.source.width) === Number(originLayer.sourceWidth))
      && (!Number(originLayer.sourceHeight) || Number(layer.source.height) === Number(originLayer.sourceHeight))) sourceNameMatches.push(layer);
  }
  if (sourceNameMatches.length === 1) return sourceNameMatches[0];
  transformMatches = [];
  for (i = 0; i < nameMatches.length; i += 1) if (CanvasBridge._layerTransformMatches(nameMatches[i], originLayer)) transformMatches.push(nameMatches[i]);
  if (transformMatches.length === 1) return transformMatches[0];
  if (nameMatches.length === 1) return nameMatches[0];
  for (i = 1; i <= comp.numLayers; i += 1) {
    layer = comp.layer(i);
    if (layer.source instanceof CompItem && String(layer.source.comment || "").indexOf("CBKIVI_JOB:" + jobId) === 0) legacyWrapperMatches.push(layer);
  }
  if (legacyWrapperMatches.length === 1) return legacyWrapperMatches[0];
  throw new Error("原始图层无法唯一匹配，请在时间线上选中目标图层后使用“手动替换原始”");
};

CanvasBridge._selectedOriginTarget = function () {
  if (!app.project) throw new Error("当前没有打开 AE 工程");
  var comp = app.project.activeItem;
  if (!(comp instanceof CompItem)) throw new Error("请先打开原始合成，并在时间线上选中一个目标图层");
  if (!comp.selectedLayers || comp.selectedLayers.length !== 1) throw new Error("请在原始合成的时间线上只选中一个目标图层");
  var layer = comp.selectedLayers[0];
  if (!layer.source) throw new Error("所选图层没有可替换的素材源");
  return { comp: comp, layer: layer };
};

CanvasBridge._originalSourceFromWrapper = function (wrapper) {
  if (!(wrapper instanceof CompItem)) return null;
  for (var i = 1; i <= wrapper.numLayers; i += 1) if (String(wrapper.layer(i).comment || "") === "CBKIVI_ORIGINAL") return wrapper.layer(i).source;
  return null;
};

CanvasBridge._originSnapshot = function (comp, layer, source, exportInfo) {
  return {
    projectPath: app.project && app.project.file ? app.project.file.fsName : "",
    comp: { id: comp.id, name: comp.name, width: comp.width, height: comp.height, time: comp.time },
    layer: CanvasBridge._layerInfo(comp, layer),
    source: {
      itemId: source ? source.id : 0,
      kind: source instanceof CompItem ? "comp" : "image",
      name: source ? source.name : "",
      width: source ? source.width : 0,
      height: source ? source.height : 0
    },
    "export": exportInfo || {}
  };
};

CanvasBridge._findFootageByPath = function (filePath) {
  var i, item;
  for (i = 1; i <= app.project.numItems; i += 1) {
    item = app.project.item(i);
    if (item instanceof FootageItem && item.mainSource instanceof FileSource && item.file && CanvasBridge._samePath(item.file.fsName, filePath)) return item;
  }
  return null;
};

CanvasBridge._importKiviFootage = function (filePath) {
  var existing = CanvasBridge._findFootageByPath(filePath);
  if (existing) return { item: existing, created: false };
  var file = new File(filePath);
  if (!file.exists) throw new Error("视频文件不存在：" + filePath);
  var rootFolder = CanvasBridge._findOrCreateFolder("Canvas Bridge 导入", null);
  var childFolder = CanvasBridge._findOrCreateFolder("Kivi Videos", rootFolder);
  var item = app.project.importFile(new ImportOptions(file));
  item.parentFolder = childFolder;
  return { item: item, created: true };
};

CanvasBridge._hexColor4 = function (hex) {
  var rgb = CanvasBridge._hexColor(hex);
  return [rgb[0], rgb[1], rgb[2], 1];
};

CanvasBridge._propertyByDisplayName = function (group, expectedName) {
  if (!group) return null;
  var target = String(expectedName || "").replace(/\s+/g, "").toLowerCase(), i, property, found;
  for (i = 1; i <= Number(group.numProperties || 0); i += 1) {
    property = group.property(i);
    if (!property) continue;
    if (String(property.name || "").replace(/\s+/g, "").toLowerCase() === target) return property;
    if (Number(property.numProperties || 0) > 0) {
      found = CanvasBridge._propertyByDisplayName(property, expectedName);
      if (found) return found;
    }
  }
  return null;
};

CanvasBridge._addKeyingChain = function (layer, backgroundHex) {
  var effects = layer.property("ADBE Effect Parade");
  if (!effects) throw new Error("无法访问视频图层的效果列表");
  var keylight = effects.addProperty("Keylight 906");
  if (!keylight) throw new Error("当前 AE 没有安装 Keylight");
  var screenColour = keylight.property("Keylight 906-0004");
  if (!screenColour) throw new Error("Keylight 缺少 Screen Colour 属性");
  try { screenColour.setValue(CanvasBridge._hexColor4(backgroundHex)); }
  catch (fourChannelError) { screenColour.setValue(CanvasBridge._hexColor(backgroundHex)); }
  var clipBlack = CanvasBridge._propertyByDisplayName(keylight, "Clip Black");
  if (!clipBlack) throw new Error("Keylight 缺少 Screen Matte > Clip Black 属性");
  try { clipBlack.setValue(40); }
  catch (clipBlackError) { throw new Error("无法将 Keylight Clip Black 设置为 40：" + clipBlackError.toString()); }
  return { keylight: keylight };
};

CanvasBridge._candidateLayer = function (comp, candidateId) {
  var marker = "CBKIVI_CANDIDATE:" + candidateId;
  for (var i = 1; i <= comp.numLayers; i += 1) if (String(comp.layer(i).comment || "") === marker) return comp.layer(i);
  return null;
};

CanvasBridge._disableOtherCandidateLayers = function (comp, candidateId) {
  var marker = "CBKIVI_CANDIDATE:" + candidateId;
  for (var i = 1; i <= comp.numLayers; i += 1) {
    var layer = comp.layer(i), comment = String(layer.comment || "");
    if (comment.indexOf("CBKIVI_CANDIDATE:") === 0) layer.enabled = comment === marker;
  }
};

CanvasBridge._kiviPlacement = function (sourceWidth, sourceHeight) {
  sourceWidth = Number(sourceWidth) || 0;
  sourceHeight = Number(sourceHeight) || 0;
  return {
    wrapperWidth: sourceWidth * 2,
    wrapperHeight: sourceHeight * 2,
    center: [sourceWidth, sourceHeight],
    anchorDelta: [sourceWidth / 2, sourceHeight / 2]
  };
};

CanvasBridge._pointSnapshot = function (property, fallback) {
  var snapshot = { value: fallback || [0, 0], keys: [] }, i;
  if (!property) return snapshot;
  try { snapshot.value = property.value; } catch (ignoredValue) {}
  try {
    for (i = 1; i <= property.numKeys; i += 1) snapshot.keys.push(property.keyValue(i));
  } catch (ignoredKeys) { snapshot.keys = []; }
  return snapshot;
};

CanvasBridge._shiftPoint = function (value, deltaX, deltaY) {
  var shifted = [Number(value && value[0]) + deltaX, Number(value && value[1]) + deltaY];
  if (value && value.length > 2) shifted.push(value[2]);
  return shifted;
};

CanvasBridge._applyShiftedPointSnapshot = function (property, snapshot, deltaX, deltaY) {
  if (!property || !snapshot) return;
  var i;
  if (snapshot.keys && snapshot.keys.length && property.numKeys === snapshot.keys.length) {
    for (i = 1; i <= snapshot.keys.length; i += 1) property.setValueAtKey(i, CanvasBridge._shiftPoint(snapshot.keys[i - 1], deltaX, deltaY));
  } else property.setValue(CanvasBridge._shiftPoint(snapshot.value, deltaX, deltaY));
};

CanvasBridge._alignReplacementAnchor = function (replacementLayer, parentLayer, fallback, deltaX, deltaY) {
  if (!replacementLayer || !parentLayer) return;
  var parentTransform = parentLayer.property("ADBE Transform Group");
  var replacementTransform = replacementLayer.property("ADBE Transform Group");
  if (!parentTransform || !replacementTransform) return;
  var parentAnchor = parentTransform.property("ADBE Anchor Point");
  var replacementAnchor = replacementTransform.property("ADBE Anchor Point");
  CanvasBridge._applyShiftedPointSnapshot(replacementAnchor, CanvasBridge._pointSnapshot(parentAnchor, fallback), deltaX, deltaY);
};

CanvasBridge._translateKiviWrapper = function (wrapper, deltaX, deltaY, skipLayer) {
  var i, layer, marker, position, value;
  for (i = 1; i <= wrapper.numLayers; i += 1) {
    layer = wrapper.layer(i);
    if (layer === skipLayer) continue;
    marker = String(layer.comment || "");
    if (marker !== "CBKIVI_ORIGINAL" && marker.indexOf("CBKIVI_CANDIDATE:") !== 0) continue;
    position = layer.property("ADBE Transform Group").property("ADBE Position");
    if (!position || position.numKeys) throw new Error("旧 KIVI 预合成包含位置关键帧，无法自动迁移，请先手动确认");
    value = position.value;
    position.setValue(CanvasBridge._shiftPoint(value, deltaX, deltaY));
  }
};

CanvasBridge._referenceLayer = function (comp, jobId) {
  var marker = "CBKIVI_REFERENCE:" + jobId, i;
  for (i = 1; i <= comp.numLayers; i += 1) if (String(comp.layer(i).comment || "") === marker) return comp.layer(i);
  return null;
};

CanvasBridge._replacementLayer = function (comp, jobId) {
  var marker = "CBKIVI_REPLACEMENT:" + jobId, i;
  for (i = 1; i <= comp.numLayers; i += 1) if (String(comp.layer(i).comment || "") === marker) return comp.layer(i);
  return null;
};

CanvasBridge._removeLegacyOriginalLayers = function (wrapper) {
  if (!wrapper) return 0;
  var removed = 0, i, layer;
  for (i = wrapper.numLayers; i >= 1; i -= 1) {
    layer = wrapper.layer(i);
    if (String(layer.comment || "") !== "CBKIVI_ORIGINAL") continue;
    try { layer.remove(); removed += 1; } catch (ignoredRemoveOriginal) {}
  }
  return removed;
};

CanvasBridge._removeLegacyReferenceLayers = function (comp, jobId) {
  if (!comp) return 0;
  var marker = "CBKIVI_REFERENCE:" + jobId, removed = 0, i, layer;
  for (i = comp.numLayers; i >= 1; i -= 1) {
    layer = comp.layer(i);
    if (String(layer.comment || "") !== marker) continue;
    try { layer.remove(); removed += 1; } catch (ignoredRemoveReference) {}
  }
  return removed;
};

CanvasBridge._addKiviCandidate = function (payloadText, manualSelection) {
  var createdComp = null, createdLayer = null, createdReplacementLayer = null, imported = null, parentLayer = null, originalSource = null;
  var migratedLegacy = false, restoredLegacyParent = false, previousWrapperComment = "", previousWrapperName = "", previousWrapperLabel = 0;
  var previousParentName = "", previousParentLabel = 0, previousParentEnabled = true, legacyParentAnchor = null, resolvedOrigin = null;
  var replacementLayer = null, previousReplacementEnabled = true, previousReplacementName = "", previousReplacementLabel = 0, previousReplacementComment = "", previousReplacementAnchor = null;
  app.beginUndoGroup("Canvas Bridge 加入原始合成");
  try {
    var payload = CanvasBridge._parsePayload(payloadText);
    var loopDuration = Number(payload.loopDuration) === 3 ? 3 : 2;
    manualSelection = !!manualSelection || !!payload.manualSelection;
    var origin = payload.origin || {}, sourceInfo = origin.source || {}, exportInfo = origin.export || {};
    if (!app.project || !app.project.file) throw new Error("请先保存并打开原 AE 工程");
    if (!manualSelection && !CanvasBridge._sameProjectFamily(app.project.file.fsName, origin.projectPath)) throw new Error("当前 AE 工程与该 KIVI 任务的来源工程不一致");
    var parentComp;
    if (manualSelection) {
      var selectedTarget = CanvasBridge._selectedOriginTarget();
      parentComp = selectedTarget.comp;
      parentLayer = selectedTarget.layer;
    } else {
      parentComp = CanvasBridge._compByOrigin(origin.comp);
      parentLayer = CanvasBridge._layerByOrigin(parentComp, origin.layer, payload.jobId);
    }
    var wrapperMarker = "CBKIVI_JOB:" + payload.jobId;
    replacementLayer = CanvasBridge._replacementLayer(parentComp, payload.jobId);
    if (replacementLayer) {
      previousReplacementEnabled = replacementLayer.enabled;
      previousReplacementName = replacementLayer.name;
      previousReplacementLabel = replacementLayer.label;
      previousReplacementComment = String(replacementLayer.comment || "");
      previousReplacementAnchor = CanvasBridge._pointSnapshot(replacementLayer.property("ADBE Transform Group").property("ADBE Anchor Point"), null);
    }
    var parentSourceComment = parentLayer.source instanceof CompItem ? String(parentLayer.source.comment || "") : "";
    var replacementSourceComment = replacementLayer && replacementLayer.source instanceof CompItem ? String(replacementLayer.source.comment || "") : "";
    var wrapper = replacementLayer && replacementSourceComment.indexOf(wrapperMarker) === 0 ? replacementLayer.source : (parentLayer.source instanceof CompItem && parentSourceComment.indexOf("CBKIVI_JOB:") === 0 ? parentLayer.source : null);
    var parentUsesWrapper = !!(wrapper && parentLayer.source === wrapper && !replacementLayer);
    var wrapperOwnedByJob = wrapper && String(wrapper.comment || "").indexOf(wrapperMarker) === 0;
    originalSource = CanvasBridge._originalSourceFromWrapper(wrapper);
    if (!originalSource && !manualSelection) {
      try { originalSource = CanvasBridge._itemById(sourceInfo.itemId); } catch (ignoredSourceId) {}
    }
    if (!originalSource && parentLayer.source && !(parentLayer.source instanceof CompItem && parentSourceComment.indexOf("CBKIVI_JOB:") === 0)) {
      var selectedSource = parentLayer.source;
      var savedSourceMatches = selectedSource.name === String(sourceInfo.name || "") && Math.round(Number(selectedSource.width) || 0) === Math.round(Number(sourceInfo.width) || 0) && Math.round(Number(selectedSource.height) || 0) === Math.round(Number(sourceInfo.height) || 0);
      if (manualSelection || savedSourceMatches) originalSource = selectedSource;
    }
    if (!originalSource) throw new Error("无法恢复原始素材，请选中原始图层后使用“手动替换原始”");
    var sourceWidth = Math.round(manualSelection ? originalSource.width : (Number(sourceInfo.width) || originalSource.width));
    var sourceHeight = Math.round(manualSelection ? originalSource.height : (Number(sourceInfo.height) || originalSource.height));
    var placement = CanvasBridge._kiviPlacement(sourceWidth, sourceHeight);
    var wrapperWidth = placement.wrapperWidth, wrapperHeight = placement.wrapperHeight;
    var selectedTransform = parentLayer.property("ADBE Transform Group");
    var originAnchor = manualSelection ? CanvasBridge._propertyValue(selectedTransform, "ADBE Anchor Point", [sourceWidth / 2, sourceHeight / 2]) : (origin.layer && origin.layer.transform && origin.layer.transform.anchorPoint ? origin.layer.transform.anchorPoint : [sourceWidth / 2, sourceHeight / 2]);
    previousParentName = parentLayer.name;
    previousParentLabel = parentLayer.label;
    previousParentEnabled = parentLayer.enabled;
    resolvedOrigin = CanvasBridge._originSnapshot(parentComp, parentLayer, originalSource, exportInfo);
    var targetParentName = String(manualSelection ? previousParentName : (origin.layer && origin.layer.name || previousParentName));
    if (!(sourceWidth > 0 && sourceHeight > 0) || wrapperWidth > 30000 || wrapperHeight > 30000) throw new Error("原始素材的 2 倍尺寸超出 AE 合成限制");
    if (!wrapper) {
      if (!parentLayer.source || Number(parentLayer.source.id) !== Number(originalSource.id)) throw new Error("原始图层素材已改变，已停止回填");
      wrapper = app.project.items.addComp("KIVI_" + String(payload.jobName || originalSource.name).replace(/[\\\/:*?\"<>|]/g, "_"), wrapperWidth, wrapperHeight, originalSource.pixelAspect || 1, loopDuration, parentComp.frameRate || 25);
      createdComp = wrapper;
      wrapper.comment = wrapperMarker + "|LAYOUT:2";
      wrapper.label = 13;
    } else {
      previousWrapperComment = String(wrapper.comment || "");
      previousWrapperName = wrapper.name;
      previousWrapperLabel = wrapper.label;
      if (previousWrapperComment.indexOf("|LAYOUT:2") < 0) {
        CanvasBridge._translateKiviWrapper(wrapper, placement.anchorDelta[0], placement.anchorDelta[1], null);
        migratedLegacy = true;
      }
      if (wrapperOwnedByJob) wrapper.name = "KIVI_" + String(payload.jobName || originalSource.name).replace(/[\\\/:*?\"<>|]/g, "_");
      wrapper.comment = previousWrapperComment.indexOf("|LAYOUT:2") >= 0 ? previousWrapperComment : previousWrapperComment + "|LAYOUT:2";
      wrapper.label = 13;
    }
    wrapper.duration = loopDuration;
    var canvasBridgeRoot = CanvasBridge._findOrCreateFolder("Canvas Bridge 导入", null);
    var acceptedCompFolder = CanvasBridge._findOrCreateFolder("Canvas Bridge 采纳合成", canvasBridgeRoot);
    wrapper.parentFolder = acceptedCompFolder;
    var existingLayer = CanvasBridge._candidateLayer(wrapper, payload.candidateId);
    var videoItem = existingLayer && existingLayer.source ? existingLayer.source : null;
    if (!existingLayer) {
      imported = CanvasBridge._importKiviFootage(payload.filePath);
      videoItem = imported.item;
      if (!(Number(videoItem.duration) > 0)) throw new Error("无法读取候选视频时长");
      createdLayer = wrapper.layers.add(videoItem);
      createdLayer.name = String(payload.candidateLabel || "KIVI 候选");
      createdLayer.comment = "CBKIVI_CANDIDATE:" + payload.candidateId;
      createdLayer.label = 13;
      var exportWidth = Number(exportInfo.width) || videoItem.width;
      var exportHeight = Number(exportInfo.height) || videoItem.height;
      var layoutScale = Number(exportInfo.scaleMultiplier) || 1;
      var fitRatio = Number(exportInfo.fitRatio);
      if (!(fitRatio > 0 && fitRatio <= 1)) fitRatio = 0.8;
      var fitPercent = Math.min(exportWidth / sourceWidth, exportHeight / sourceHeight) * 100 * fitRatio * layoutScale;
      if (!(fitPercent > 0)) throw new Error("任务缺少有效的导出缩放信息");
      var scaleX = 10000 / (fitPercent * (videoItem.width / exportWidth));
      var scaleY = 10000 / (fitPercent * (videoItem.height / exportHeight));
      var rotation = -(Number(exportInfo.rotation) || 0);
      var offsetX = ((Number(exportInfo.x) || 0.5) * videoItem.width - videoItem.width / 2) * scaleX / 100;
      var offsetY = ((Number(exportInfo.y) || 0.5) * videoItem.height - videoItem.height / 2) * scaleY / 100;
      var radians = rotation * Math.PI / 180;
      var rotatedX = offsetX * Math.cos(radians) - offsetY * Math.sin(radians);
      var rotatedY = offsetX * Math.sin(radians) + offsetY * Math.cos(radians);
      var transform = createdLayer.property("ADBE Transform Group");
      transform.property("ADBE Scale").setValue([scaleX, scaleY]);
      transform.property("ADBE Rotate Z").setValue(rotation);
      transform.property("ADBE Position").setValue([placement.center[0] - rotatedX, placement.center[1] - rotatedY]);
      CanvasBridge._addKeyingChain(createdLayer, exportInfo.backgroundHex || "#000000");
      existingLayer = createdLayer;
    }
    if (!(Number(videoItem.duration) > 0)) throw new Error("无法读取候选视频时长");
    existingLayer.startTime = 0;
    existingLayer.stretch = loopDuration * 100 / Number(videoItem.duration);
    existingLayer.inPoint = 0;
    existingLayer.outPoint = loopDuration;
    CanvasBridge._disableOtherCandidateLayers(wrapper, payload.candidateId);

    if (!replacementLayer) {
      if (parentUsesWrapper) {
        legacyParentAnchor = CanvasBridge._pointSnapshot(parentLayer.property("ADBE Transform Group").property("ADBE Anchor Point"), originAnchor);
        replacementLayer = parentLayer.duplicate();
        createdReplacementLayer = replacementLayer;
        parentLayer.replaceSource(originalSource, false);
        CanvasBridge._applyShiftedPointSnapshot(parentLayer.property("ADBE Transform Group").property("ADBE Anchor Point"), legacyParentAnchor, -placement.anchorDelta[0], -placement.anchorDelta[1]);
        restoredLegacyParent = true;
      } else {
        replacementLayer = parentLayer.duplicate();
        createdReplacementLayer = replacementLayer;
        replacementLayer.replaceSource(wrapper, false);
      }
    } else if (replacementLayer.source !== wrapper) {
      replacementLayer.replaceSource(wrapper, false);
    }
    CanvasBridge._alignReplacementAnchor(replacementLayer, parentLayer, originAnchor, placement.anchorDelta[0], placement.anchorDelta[1]);
    replacementLayer.comment = "CBKIVI_REPLACEMENT:" + payload.jobId;
    replacementLayer.name = targetParentName;
    replacementLayer.label = 13;
    replacementLayer.enabled = true;
    try { replacementLayer.moveBefore(parentLayer); } catch (ignoredMoveReplacement) {}
    parentLayer.name = targetParentName;
    parentLayer.enabled = false;
    CanvasBridge._removeLegacyOriginalLayers(wrapper);
    CanvasBridge._removeLegacyReferenceLayers(parentComp, payload.jobId);
    return CanvasBridge._json({
      ok: true,
      reused: !createdLayer,
      compId: wrapper.id,
      compName: wrapper.name,
      layerName: existingLayer.name,
      referenceLayerName: replacementLayer.name,
      footageItemId: videoItem.id,
      stretch: existingLayer.stretch,
      loopDuration: loopDuration,
      keyColor: exportInfo.backgroundHex || "#000000",
      origin: resolvedOrigin
    });
  } catch (error) {
    try { if (createdLayer) createdLayer.remove(); } catch (ignoredLayer) {}
    try { if (createdReplacementLayer) createdReplacementLayer.remove(); } catch (ignoredReplacementLayer) {}
    try {
      if (restoredLegacyParent && parentLayer && wrapper) {
        parentLayer.replaceSource(wrapper, false);
        if (legacyParentAnchor) CanvasBridge._applyShiftedPointSnapshot(parentLayer.property("ADBE Transform Group").property("ADBE Anchor Point"), legacyParentAnchor, 0, 0);
        parentLayer.name = previousParentName;
        parentLayer.label = previousParentLabel;
      }
      if (parentLayer) parentLayer.enabled = previousParentEnabled;
    } catch (ignoredRestoreParent) {}
    try {
      if (replacementLayer && !createdReplacementLayer) {
        replacementLayer.name = previousReplacementName;
        replacementLayer.label = previousReplacementLabel;
        replacementLayer.comment = previousReplacementComment;
        replacementLayer.enabled = previousReplacementEnabled;
        if (previousReplacementAnchor) CanvasBridge._applyShiftedPointSnapshot(replacementLayer.property("ADBE Transform Group").property("ADBE Anchor Point"), previousReplacementAnchor, 0, 0);
      }
    } catch (ignoredRestoreReplacement) {}
    try {
      if (migratedLegacy && createdComp === null && wrapper) {
        CanvasBridge._translateKiviWrapper(wrapper, -placement.anchorDelta[0], -placement.anchorDelta[1], null);
        wrapper.comment = previousWrapperComment;
        wrapper.name = previousWrapperName;
        wrapper.label = previousWrapperLabel;
      }
    } catch (ignoredMigrationRestore) {}
    try { if (createdComp) createdComp.remove(); } catch (ignoredComp) {}
    try { if (imported && imported.created && imported.item) imported.item.remove(); } catch (ignoredItem) {}
    return CanvasBridge._error(error);
  } finally { app.endUndoGroup(); }
};

CanvasBridge.addKiviCandidateToOrigin = function (payloadText) {
  return CanvasBridge._addKiviCandidate(payloadText, false);
};

CanvasBridge.addKiviCandidateToSelectedLayer = function (payloadText) {
  return CanvasBridge._addKiviCandidate(payloadText, true);
};

CanvasBridge.inspectKiviCandidateReferences = function (payloadText) {
  try {
    if (!app.project) throw new Error("当前没有打开 AE 工程");
    var payload = CanvasBridge._parsePayload(payloadText), requested = payload.candidates || [];
    var wanted = {}, paths = {}, referenced = {}, i, j, item, layer, marker, id, candidate, sourcePath;
    for (i = 0; i < requested.length; i += 1) {
      candidate = requested[i] || {};
      id = String(candidate.id || "");
      if (!id) continue;
      wanted[id] = true;
      for (j = 0; j < (candidate.paths || []).length; j += 1) {
        try { paths[new File(candidate.paths[j]).fsName.toLowerCase()] = id; } catch (ignoredPath) {}
      }
    }
    for (i = 1; i <= app.project.numItems; i += 1) {
      item = app.project.item(i);
      if (!(item instanceof CompItem)) continue;
      for (j = 1; j <= item.numLayers; j += 1) {
        layer = item.layer(j);
        marker = String(layer.comment || "");
        id = marker.indexOf("CBKIVI_CANDIDATE:") === 0 ? marker.substring("CBKIVI_CANDIDATE:".length) : "";
        if (wanted[id]) referenced[id] = true;
        sourcePath = "";
        try { if (layer.source instanceof FootageItem && layer.source.file) sourcePath = layer.source.file.fsName.toLowerCase(); } catch (ignoredSource) {}
        if (sourcePath && paths[sourcePath]) referenced[paths[sourcePath]] = true;
      }
    }
    var referencedIds = [];
    for (id in referenced) if (referenced.hasOwnProperty(id)) referencedIds.push(id);
    return CanvasBridge._json({ ok: true, referencedIds: referencedIds });
  } catch (error) { return CanvasBridge._error(error); }
};

CanvasBridge.removeKiviCandidateEverywhere = function (payloadText) {
  app.beginUndoGroup("Canvas Bridge 清理淘汰视频");
  try {
    if (!app.project) throw new Error("当前没有打开 AE 工程");
    var payload = CanvasBridge._parsePayload(payloadText), candidates = payload.candidates || [];
    var ids = {}, paths = {}, i, j, item, layer, candidate, normalized;
    for (i = 0; i < candidates.length; i += 1) {
      candidate = candidates[i];
      ids[String(candidate.id)] = true;
      for (j = 0; j < (candidate.paths || []).length; j += 1) {
        normalized = new File(candidate.paths[j]).fsName.toLowerCase();
        paths[normalized] = true;
      }
    }
    var removedLayers = 0, removedItems = 0;
    for (i = 1; i <= app.project.numItems; i += 1) {
      item = app.project.item(i);
      if (!(item instanceof CompItem)) continue;
      for (j = item.numLayers; j >= 1; j -= 1) {
        layer = item.layer(j);
        var marker = String(layer.comment || "");
        var candidatePrefix = "CBKIVI_CANDIDATE:";
        var markerId = marker.indexOf(candidatePrefix) === 0 ? marker.substring(candidatePrefix.length) : "";
        var sourcePath = "";
        try { if (layer.source instanceof FootageItem && layer.source.file) sourcePath = layer.source.file.fsName.toLowerCase(); } catch (ignoredSource) {}
        if ((markerId && ids[markerId]) || (sourcePath && paths[sourcePath])) { layer.remove(); removedLayers += 1; }
      }
    }
    for (i = app.project.numItems; i >= 1; i -= 1) {
      item = app.project.item(i);
      if (!(item instanceof FootageItem) || !item.file) continue;
      normalized = item.file.fsName.toLowerCase();
      if (paths[normalized]) { item.remove(); removedItems += 1; }
    }
    return CanvasBridge._json({ ok: true, removedLayers: removedLayers, removedItems: removedItems });
  } catch (error) { return CanvasBridge._error(error); }
  finally { app.endUndoGroup(); }
};
