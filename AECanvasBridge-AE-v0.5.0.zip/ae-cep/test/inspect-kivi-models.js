'use strict';

const os = require('os');
const path = require('path');
const https = require('https');
const { spawnSync } = require('child_process');

const credentialPath = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'AE Canvas Bridge', 'kivi-access-token.dpapi');
const credentialScript = path.resolve(__dirname, '..', 'js', 'kivi-credentials.ps1');
const base = 'https://api.micoplatform.com/business_ai/kivi/web';

function readCredential() {
  const result = spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', credentialScript, '-Action', 'read', '-Path', credentialPath], { encoding: 'utf8', windowsHide: true });
  if (result.status !== 0) throw new Error(String(result.stderr || 'Cannot read credential').trim());
  return String(result.stdout || '').trim();
}

function requestJson(url, token) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, { headers: { Accept: 'application/json', Authorization: `Bearer ${token}`, 'User-Agent': 'AE-Canvas-Bridge-Model-Inspector' } }, response => {
      const chunks = [];
      response.on('data', chunk => chunks.push(Buffer.from(chunk)));
      response.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let body;
        try { body = JSON.parse(text || '{}'); } catch (_) { body = { text: text.slice(0, 160) }; }
        resolve({ statusCode: response.statusCode || 0, body });
      });
    });
    request.on('error', reject);
    request.setTimeout(30000, () => request.destroy(new Error('request timeout')));
  });
}

function modelSummary(value, result, trail) {
  if (!value || typeof value !== 'object') return result;
  if (Array.isArray(value)) {
    value.forEach((item, index) => modelSummary(item, result, `${trail}[${index}]`));
    return result;
  }
  const keys = Object.keys(value);
  const modelKeys = keys.filter(key => /^(model_?name|name|display_?name|label|title|biz_?action|category|type)$/i.test(key));
  if (modelKeys.length) {
    const summary = { path: trail };
    modelKeys.forEach(key => { if (['string', 'number', 'boolean'].includes(typeof value[key])) summary[key] = value[key]; });
    if (Object.keys(summary).length > 1) result.push(summary);
  }
  keys.forEach(key => modelSummary(value[key], result, trail ? `${trail}.${key}` : key));
  return result;
}

(async () => {
  const token = readCredential();
  if (!token) throw new Error('Empty credential');
  for (const endpoint of ['/api/model/base_models/config', '/api/model/base_models']) {
    const response = await requestJson(base + endpoint, token);
    const summary = modelSummary(response.body, [], '').slice(0, 100);
    const data = response.body && response.body.data;
    const scalarModels = Array.isArray(data) ? data.map(item => Object.fromEntries(Object.entries(item || {}).filter(([, value]) => ['string', 'number', 'boolean'].includes(typeof value)))) : [];
    process.stdout.write(`${endpoint} HTTP ${response.statusCode}\n`);
    process.stdout.write(`${JSON.stringify({ topLevelKeys: Object.keys(response.body || {}), summary, scalarModels }, null, 2)}\n`);
  }
})().catch(error => {
  process.stderr.write(`${error.message || error}\n`);
  process.exitCode = 1;
});
