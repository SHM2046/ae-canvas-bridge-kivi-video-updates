'use strict';

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

(async () => {
  const outputRoot = path.resolve(__dirname, 'artifacts');
  fs.mkdirSync(outputRoot, { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.CHROME_PATH || 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  });
  try {
    for (const viewport of [
      { width: 1265, height: 900, name: 'wide' },
      { width: 680, height: 1000, name: 'medium' },
      { width: 360, height: 1000, name: 'narrow' }
    ]) {
      const page = await browser.newPage({ viewport });
      await page.goto('http://127.0.0.1:17421/test/ui-fixture.html', { waitUntil: 'networkidle' });
      const metrics = await page.evaluate(() => {
        const cards = Array.from(document.querySelectorAll('.preview-card'));
        const firstRowTop = cards.length ? cards[0].getBoundingClientRect().top : 0;
        const strips = Array.from(document.querySelectorAll('.kivi-candidate-strip'));
        const rejected = document.querySelector('.kivi-candidate.rejected');
        const accepted = document.querySelector('.kivi-candidate.accepted');
        const importCards = Array.from(document.querySelectorAll('.import-item'));
        const importFirstTop = importCards.length ? importCards[0].getBoundingClientRect().top : 0;
        return {
          viewport: window.innerWidth,
          scrollWidth: document.documentElement.scrollWidth,
          previewColumns: cards.filter(card => Math.abs(card.getBoundingClientRect().top - firstRowTop) < 2).length,
          visibleTabLabels: Array.from(document.querySelectorAll('.module-tabs button')).map(button => button.textContent.trim()),
          sizeLabels: Array.from(document.querySelectorAll('#sizePresets button')).map(button => button.textContent.trim()),
          originalSizeOptions: Array.from(document.querySelectorAll('.preview-card select option')).filter(option => option.textContent.trim() === '原始尺寸').length,
          originalSizeButtons: Array.from(document.querySelectorAll('.size-control-row button')).filter(button => button.textContent.trim() === '原始尺寸').length,
          perCardKiviButtons: Array.from(document.querySelectorAll('.preview-card-actions button')).map(button => button.textContent.trim()),
          resultLanes: strips.length,
          firstLaneScrollable: strips.length ? strips[0].scrollWidth > strips[0].clientWidth : false,
          rejectedFilter: rejected ? getComputedStyle(rejected).filter : 'none',
          acceptedBadge: accepted ? getComputedStyle(accepted, '::after').content : 'none',
          deleteButtons: document.querySelectorAll('.kivi-job-delete').length,
          importColumns: importCards.filter(card => Math.abs(card.getBoundingClientRect().top - importFirstTop) < 2).length,
          taskNamesVisible: document.querySelectorAll('.kivi-job-row-title').length,
          sortControls: document.querySelectorAll('.kivi-job-sort').length,
          taskQueueWidth: document.querySelector('.kivi-job-pane').getBoundingClientRect().width,
          workbenchWidth: document.querySelector('.kivi-workbench').getBoundingClientRect().width,
          searchInputs: document.querySelectorAll('.kivi-workbench-toolbar input[type="search"]').length,
          statusInQueue: !!document.querySelector('.kivi-pane-heading .kivi-video-status'),
          keyInCredentialRow: !!document.querySelector('.kivi-key-card summary .badge.online'),
          deepseekCredential: !!document.querySelector('.agent-provider-card .badge.online'),
          skillEditor: !!document.querySelector('.agent-skill-editor'),
          skillCollapsed: !document.querySelector('.agent-skill-card').open,
          agentDebugPreview: !!document.querySelector('.agent-debug-task-picker img'),
          promptStatusCount: document.querySelectorAll('.kivi-agent-status').length,
          recoveryButtons: Array.from(document.querySelectorAll('.kivi-recovery-actions button')).map(button => button.textContent.trim()),
          placeholderCount: document.querySelectorAll('.kivi-candidate.placeholder').length,
          countdowns: Array.from(document.querySelectorAll('.kivi-countdown')).map(item => item.textContent.trim()),
          placeholderBlur: getComputedStyle(document.querySelector('.kivi-placeholder-media img')).filter,
          parameterTops: Array.from(document.querySelectorAll('.kivi-parameter-grid > label')).map(element => Math.round(element.getBoundingClientRect().top)),
          sourceActions: Array.from(document.querySelectorAll('.kivi-source-actions button')).map(button => button.textContent.trim()),
          loopOverlays: document.querySelectorAll('.kivi-loop-overlay').length,
          importLoopOverlays: document.querySelectorAll('.import-loop-overlay').length,
          manualOriginButtons: Array.from(document.querySelectorAll('.import-origin-actions button')).map(button => button.textContent.trim()),
          taskZoomReadout: document.querySelector('.kivi-pane-heading .zoom-readout')?.textContent.trim(),
          xyInputs: document.querySelectorAll('[data-x],[data-y]').length,
          toolbarCenters: Array.from(document.querySelector('.kivi-workbench-toolbar').children).map(element => { const rect = element.getBoundingClientRect(); return Math.round(rect.top + rect.height / 2); }),
          candidateActions: Array.from(document.querySelector('.kivi-candidate-actions').querySelectorAll('button')).map(button => button.textContent.trim()),
          queueTabs: Array.from(document.querySelectorAll('.kivi-queue-tabs button')).map(button => button.textContent.trim()),
          queueActions: Array.from(document.querySelectorAll('.kivi-queue-actions button')).map(button => button.textContent.trim()),
          resizers: document.querySelectorAll('.vertical-resizer').length,
          promptHeight: Math.round(document.querySelector('.kivi-editor textarea').getBoundingClientRect().height),
          scaleNumberInputs: document.querySelectorAll('.scale-control input[type="number"]').length,
          materialBatchActions: Array.from(document.querySelectorAll('.import-history-card .asset-toolbar button.text-button')).map(button => button.textContent.trim()),
          loopDurationButtons: Array.from(document.querySelectorAll('.import-history-card .loop-duration-switch button')).map(button => button.textContent.trim())
        };
      });
      if (metrics.scrollWidth > metrics.viewport + 1) throw new Error(`${viewport.name}: horizontal overflow ${metrics.scrollWidth}/${metrics.viewport}`);
      if (metrics.visibleTabLabels[1] !== '② KIVI视频' || metrics.visibleTabLabels[2] !== '③ 素材库' || metrics.visibleTabLabels[3] !== '④ Agent调试') throw new Error(`${viewport.name}: navigation order is incorrect`);
      if (metrics.sizeLabels.includes('匹配原始大小') || metrics.sizeLabels.includes('原始尺寸')) throw new Error(`${viewport.name}: original-size control incorrectly remains global`);
      if (metrics.originalSizeOptions) throw new Error(`${viewport.name}: original size still appears in a dropdown`);
      if (metrics.originalSizeButtons < 4) throw new Error(`${viewport.name}: per-card original-size buttons are missing`);
      if (!metrics.perCardKiviButtons.includes('添加KIVI队列') || !metrics.perCardKiviButtons.includes('发送KIVI画板')) throw new Error(`${viewport.name}: per-card KIVI actions are missing`);
      if (metrics.resultLanes !== 2) throw new Error(`${viewport.name}: expected two candidate lanes, got ${metrics.resultLanes}`);
      if (!metrics.firstLaneScrollable) throw new Error(`${viewport.name}: candidate lane is not horizontally scrollable`);
      if (metrics.rejectedFilter === 'none') throw new Error(`${viewport.name}: rejected candidates are not grayscale`);
      if (!metrics.acceptedBadge.includes('已采用')) throw new Error(`${viewport.name}: accepted candidate badge is missing`);
      if (metrics.deleteButtons < 20) throw new Error(`${viewport.name}: dense task queue does not expose enough tasks`);
      if (metrics.taskNamesVisible < 20) throw new Error(`${viewport.name}: original AE layer names are missing from the queue`);
      if (metrics.sortControls !== 1) throw new Error(`${viewport.name}: task sort control is missing`);
      if (Math.abs(metrics.taskQueueWidth - metrics.workbenchWidth) > 2) throw new Error(`${viewport.name}: task queue is not full-width`);
      if (metrics.searchInputs) throw new Error(`${viewport.name}: unused task search is still visible`);
      if (!metrics.statusInQueue) throw new Error(`${viewport.name}: runtime status is not embedded in the task queue header`);
      if (!metrics.keyInCredentialRow) throw new Error(`${viewport.name}: credential badge is not on the KIVI credential row`);
      if (!metrics.deepseekCredential || !metrics.skillEditor || !metrics.skillCollapsed || !metrics.agentDebugPreview) throw new Error(`${viewport.name}: Agent debug controls are incomplete`);
      if (metrics.promptStatusCount < 20) throw new Error(`${viewport.name}: task Prompt states are missing`);
      if (metrics.recoveryButtons.join('|') !== '自动恢复|选择目录') throw new Error(`${viewport.name}: recovery controls are incomplete`);
      if (metrics.placeholderCount !== 2 || metrics.countdowns.some(value => value !== '165s')) throw new Error(`${viewport.name}: generating placeholders are incomplete`);
      if (metrics.placeholderBlur === 'none') throw new Error(`${viewport.name}: generating placeholders are not blurred`);
      if (Math.max(...metrics.parameterTops) - Math.min(...metrics.parameterTops) > 2) throw new Error(`${viewport.name}: generation parameters do not stay on one row`);
      if (metrics.sourceActions.join('|') !== '生成视频|生成 Prompt|移入草稿箱') throw new Error(`${viewport.name}: task actions are not under the source thumbnail`);
      if (metrics.loopOverlays < 2) throw new Error(`${viewport.name}: 2S loop controls are not overlaid on videos`);
      if (metrics.importLoopOverlays < 4) throw new Error(`${viewport.name}: material library 2S loop controls are missing`);
      if (!metrics.manualOriginButtons.includes('手动替换原始')) throw new Error(`${viewport.name}: manual origin replacement is missing`);
      if (metrics.taskZoomReadout !== '80%') throw new Error(`${viewport.name}: task queue zoom readout is missing`);
      if (metrics.xyInputs) throw new Error(`${viewport.name}: X/Y numeric controls still consume preview space`);
      if (viewport.width >= 680 && Math.max(...metrics.toolbarCenters) - Math.min(...metrics.toolbarCenters) > 2) throw new Error(`${viewport.name}: KIVI toolbar is not a single row`);
      if (metrics.candidateActions.join('|') !== '加入原始|手动替换|加入素材|淘汰|再生成') throw new Error(`${viewport.name}: candidate action order is incorrect`);
      if (metrics.queueTabs.join('|') !== '任务队列|草稿箱 3') throw new Error(`${viewport.name}: queue/archive tabs are incomplete`);
      if (metrics.queueActions.join('|') !== '清除任务面板|清除未用素材') throw new Error(`${viewport.name}: queue cleanup actions are incomplete`);
      if (metrics.resizers < 2 || metrics.promptHeight < 180) throw new Error(`${viewport.name}: queue/prompt resize affordances are incomplete`);
      if (metrics.scaleNumberInputs < 1) throw new Error(`${viewport.name}: editable scale percentage is missing`);
      if (metrics.materialBatchActions.join('|') !== '一键导入 Eagle|一键导出至本地') throw new Error(`${viewport.name}: material batch actions are missing`);
      if (metrics.loopDurationButtons.join('|') !== '2S|3S') throw new Error(`${viewport.name}: material loop duration switch is missing`);
      if (metrics.importColumns < 2) throw new Error(`${viewport.name}: material library zoom does not expose multiple columns`);
      if (viewport.name === 'wide' && metrics.previewColumns < 4) throw new Error(`wide: expected at least 4 preview columns, got ${metrics.previewColumns}`);
      await page.screenshot({ path: path.join(outputRoot, `v0.5.0-${viewport.name}.png`), fullPage: true });
      console.log(`${viewport.name}: ${JSON.stringify(metrics)}`);
      await page.close();
    }

    const modalPage = await browser.newPage({ viewport: { width: 680, height: 620 } });
    await modalPage.goto('http://127.0.0.1:17421/test/ui-fixture.html', { waitUntil: 'networkidle' });
    const modalMetrics = await modalPage.evaluate(() => {
      const overlay = document.createElement('div');
      overlay.className = 'panel-confirm-overlay';
      overlay.innerHTML = `
        <div class="panel-confirm" role="dialog" aria-modal="true">
          <div class="panel-confirm-title">永久清理淘汰视频</div>
          <div class="panel-confirm-message">将删除 2 个淘汰视频的本地原始文件，并同步移除 AE 项目素材和素材库记录。</div>
          <div class="panel-confirm-warning">此操作不可恢复。</div>
          <label class="panel-confirm-suppress"><input type="checkbox">本次启动不再提醒</label>
          <div class="panel-confirm-actions"><button>取消</button><button class="panel-confirm-danger">永久删除</button></div>
        </div>`;
      document.body.appendChild(overlay);
      const dialog = overlay.querySelector('.panel-confirm');
      const style = getComputedStyle(dialog);
      return {
        overlayPosition: getComputedStyle(overlay).position,
        dialogBackground: style.backgroundColor,
        dialogWidth: dialog.getBoundingClientRect().width,
        warningText: overlay.querySelector('.panel-confirm-warning').textContent.trim(),
        fileNamesShown: /TOPTOP|\.mp4/i.test(dialog.textContent),
        suppressLabel: overlay.querySelector('.panel-confirm-suppress')?.textContent.trim()
      };
    });
    if (modalMetrics.overlayPosition !== 'fixed') throw new Error('confirm modal overlay is not fixed');
    if (modalMetrics.dialogBackground === 'rgb(255, 255, 255)') throw new Error('confirm modal still uses a white dialog');
    if (modalMetrics.dialogWidth > 440) throw new Error(`confirm modal is too wide: ${modalMetrics.dialogWidth}`);
    if (modalMetrics.warningText !== '此操作不可恢复。') throw new Error('confirm modal warning is missing');
    if (modalMetrics.fileNamesShown) throw new Error('confirm modal exposes task or file names');
    if (modalMetrics.suppressLabel !== '本次启动不再提醒') throw new Error('session-only suppression control is missing');
    await modalPage.screenshot({ path: path.join(outputRoot, 'v0.4.3-confirm.png'), fullPage: false });
    console.log(`confirm: ${JSON.stringify(modalMetrics)}`);
    await modalPage.close();
  } finally {
    await browser.close();
  }
})().catch(error => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});

