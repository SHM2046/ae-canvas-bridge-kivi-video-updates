'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const childProcess = require('child_process');
const vm = require('vm');
const { createClient, extractVideoUrls, taskError, taskAccounting, normalizeUserInfo, normalizeQuota, normalizeVideoModels } = require('../js/kivi-api.js');
const { KiviJobStore, SCHEMA_VERSION, deriveJobStatus, sortJobs, normalizeJob, normalizeRun } = require('../js/kivi-job-store.js');
const { KiviJobRunner } = require('../js/kivi-job-runner.js');
const { resolveProjectRoot, projectRootFromSelection, workspacePath } = require('../js/kivi-workspace-recovery.js');
const { DeepSeekProvider, imageDataUrl, outputText } = require('../js/deepseek-provider.js');
const { PromptAgentRunner } = require('../js/prompt-agent-runner.js');
const { AgentSkillStore, MAX_SKILL_BYTES } = require('../js/agent-skill-store.js');
const { buildUsageSnapshot } = require('../js/usage-analytics.js');
const { UsageTelemetry } = require('../js/usage-telemetry.js');
const { PreviewArchiveStore } = require('../js/preview-archive-store.js');

const tests = [];
function test(name, run) { tests.push({ name, run }); }
function tempDirectory(name) { return fs.mkdtempSync(path.join(os.tmpdir(), `${name}-`)); }
function removeDirectory(directory) {
  if (!fs.existsSync(directory)) return;
  for (const name of fs.readdirSync(directory)) {
    const target = path.join(directory, name);
    if (fs.lstatSync(target).isDirectory()) removeDirectory(target);
    else fs.unlinkSync(target);
  }
  fs.rmdirSync(directory);
}

test('development package version and static element ids stay consistent', () => {
  const packageInfo = require('../package.json');
  const html = fs.readFileSync(path.resolve(__dirname, '..', 'index.html'), 'utf8');
  const manifest = fs.readFileSync(path.resolve(__dirname, '..', 'CSXS', 'manifest.xml'), 'utf8');
  const ids = Array.from(html.matchAll(/\bid="([^"]+)"/g), match => match[1]);
  assert.strictEqual(new Set(ids).size, ids.length, 'index.html contains duplicate ids');
  assert.ok(html.includes(`v${packageInfo.version}`));
  assert.ok(manifest.includes(`ExtensionBundleVersion="${packageInfo.version}"`));
  assert.ok(manifest.includes('com.local.aecanvasbridge.kivivideo.dev.panel'));
  assert.ok(html.includes('<h1>KIVI brige AE</h1>'));
  assert.ok(manifest.includes('ExtensionBundleName="KIVI brige AE"'));
  assert.ok(manifest.includes('<Host Name="AEFT" Version="[16.0,27.0)"'), 'manifest must cover AE 2019 through AE 2026');
  const tabOrder = Array.from(html.matchAll(/<button(?: class="active")? data-module="([^"]+)">/g), match => match[1]);
  assert.deepStrictEqual(tabOrder, ['export', 'kivi-video', 'import', 'render', 'version', 'other']);
  assert.ok(/data-size="1000" class="active"/.test(html), '1000 x 1000 should be the default canvas size');
  assert.ok(!html.includes('data-size="original"'), 'original source size must not be a batch preset');
  const panelSource = fs.readFileSync(path.resolve(__dirname, '..', 'js', 'panel.js'), 'utf8');
  const hostSource = fs.readFileSync(path.resolve(__dirname, '..', 'jsx', 'host.jsx'), 'utf8');
  const cssSource = fs.readFileSync(path.resolve(__dirname, '..', 'css', 'panel.css'), 'utf8');
  const chromeBackgroundSource = fs.readFileSync(path.resolve(__dirname, '..', '..', 'chrome-extension', 'background.js'), 'utf8');
  const chromeContentSource = fs.readFileSync(path.resolve(__dirname, '..', '..', 'chrome-extension', 'content.js'), 'utf8');
  const bridgeServerSource = fs.readFileSync(path.resolve(__dirname, '..', 'js', 'bridge-server.js'), 'utf8');
  const updaterConfig = JSON.parse(fs.readFileSync(path.resolve(__dirname, '..', 'updater-config.json'), 'utf8'));
  const bundledSkill = path.resolve(__dirname, '..', 'skills', '直播礼物4秒循环动画-Prompt-Agent-v1.0.md');
  assert.ok(fs.existsSync(bundledSkill), 'default Prompt Skill must be bundled with the extension');
  assert.ok(fs.readFileSync(bundledSkill, 'utf8').includes('每次只生成一条完整 Prompt'));
  const serverPort = bridgeServerSource.match(/const DEFAULT_PORT = (\d+);/);
  const chromePort = chromeBackgroundSource.match(/const SERVER_URL = 'ws:\/\/127\.0\.0\.1:(\d+)'/);
  assert.ok(serverPort && chromePort, 'bridge ports must be declared explicitly');
  assert.strictEqual(chromePort[1], serverPort[1], 'Chrome and the development AE panel must use the same isolated bridge port');
  assert.ok(panelSource.includes("let selectedSize = '1000'"));
  assert.ok(panelSource.includes("addEventListener('wheel', zoomPreviewWithWheel, { passive: false })"));
  assert.ok(hostSource.includes('info.sourceItemId = source.id'));
  assert.ok(hostSource.includes('CanvasBridge._layerInfo(active, layer)'));
  assert.ok(hostSource.includes('"export": exportInfo || {}'), 'ExtendScript reserved object keys must be quoted');
  assert.ok(!/^\s*export\s*:/m.test(hostSource), 'host.jsx must not use export as an unquoted property key');
  assert.ok(!/seen\[source\.id\]/.test(hostSource), 'timeline selection must not collapse layers sharing one source');
  assert.ok(panelSource.includes('ensureHostScriptLoaded(true)'), 'selection loading should force-refresh the AE host script');
  assert.ok(/loadSelection\s*=\s*async function loadSelection[\s\S]{0,300}ensureHostScriptLoaded\(true\)/.test(panelSource), 'the effective cumulative loader must refresh host.jsx');
  assert.ok(panelSource.includes("$.evalFile(new File(${quote(hostScriptPath)}))"), 'the panel should explicitly load host.jsx');
  assert.ok(!panelSource.includes("(function(){try{$.evalFile(new File(${quote(hostScriptPath)}))"), 'host.jsx must load at the global ExtendScript scope');
  assert.ok(panelSource.includes('backgroundHex: background || \'#000000\''));
  assert.ok(panelSource.includes('data-kivi-loop'));
  assert.ok(panelSource.includes('data-original-size'));
  assert.ok(!panelSource.includes("['original', '原始尺寸']"));
  assert.ok(panelSource.includes('data-send-kivi-board'));
  assert.ok(panelSource.includes('data-queue-kivi'));
  assert.ok(panelSource.includes('fitRatio,'));
  assert.ok(panelSource.includes('复制任务方案'));
  assert.ok(panelSource.includes("addEventListener('contextmenu'"));
  assert.ok(panelSource.includes('data-kivi-purge-rejected'));
  assert.ok(panelSource.includes("rejectedFromStatus === 'accepted'"));
  assert.ok(panelSource.includes('zoomImportAssetsWithWheel'));
  assert.ok(panelSource.includes('zoomKiviResultsWithWheel'));
  assert.ok(panelSource.includes('zoomKiviTasksWithWheel'));
  assert.ok(panelSource.includes('data-import-loop'));
  assert.ok(panelSource.includes('data-add-origin-manual'));
  assert.ok(panelSource.includes('data-kivi-origin-manual'));
  assert.ok(panelSource.includes('selectedOriginForRecovery'));
  assert.ok(panelSource.includes("localStorage.setItem('canvasBridgeKiviJobSort'"));
  assert.ok(panelSource.includes('本次启动不再提醒'));
  assert.ok(panelSource.includes("suppressionKey: 'destructive-delete'"));
  assert.ok(!panelSource.includes('data-x="${item.id}"'));
  assert.ok(!panelSource.includes('data-y="${item.id}"'));
  assert.ok(panelSource.includes('confirmPanelAction'));
  assert.ok(panelSource.includes('data-kivi-delete-job'));
  assert.ok(panelSource.includes('data-kivi-countdown-start'));
  assert.ok(panelSource.includes('kivi-placeholder-media'));
  assert.ok(panelSource.includes('CanvasBridge.relinkKiviAssets'));
  assert.ok(panelSource.includes('recoverKiviWorkspace'));
  assert.ok(html.includes('id="autoRecoverKiviWorkspace"'));
  assert.ok(html.includes('id="chooseKiviWorkspace"'));
  assert.ok(html.includes('id="generateDraftPrompts"'));
  assert.ok(html.includes('id="deepseekKeyInput"'));
  assert.ok(html.includes('id="agentSkillEditor"'));
  assert.ok(html.includes('<details id="agentSkillCard" class="card agent-skill-card">'));
  assert.ok(html.includes('添加KIVI队列'));
  assert.ok(html.includes('发送KIVI画板'));
  assert.ok(html.includes('id="runAgentDebug"'));
  assert.ok(html.includes('id="agentDebugPreview"'));
  assert.ok(html.includes('id="agentDebugConversation"'));
  assert.ok(html.includes('id="agentDebugFeedback"'));
  assert.ok(html.includes('id="applyAgentDebugPrompt"'));
  assert.ok(html.includes('id="previewArchiveTab"'));
  assert.ok(html.includes('id="restoreAllPreviewArchive"'));
  assert.ok(html.includes('id="deleteAllPreviewArchive"'));
  assert.ok(!html.includes('&#21516;&#24847;&#21518;'));
  assert.ok(html.includes('id="kiviJobSort"'));
  assert.ok(html.includes('id="kiviArchiveTab"'));
  assert.ok(html.includes('id="archiveAllKiviJobs"'));
  assert.ok(html.includes('id="purgeUnusedKiviMedia"'));
  assert.ok(html.includes('id="batchImportEagle"'));
  assert.ok(html.includes('id="batchExportLocal"'));
  assert.ok(html.includes('id="kiviLoopDuration"'));
  assert.ok(html.includes('data-loop-duration="2"'));
  assert.ok(html.includes('data-loop-duration="3"'));
  const versionModuleHtml = html.slice(html.indexOf('id="versionModule"'), html.indexOf('id="kiviVideoModule"'));
  const otherModuleHtml = html.slice(html.indexOf('id="otherModule"'));
  assert.ok(versionModuleHtml.includes('id="usageReportingToggle"'), 'usage reporting belongs in version checking');
  assert.ok(!otherModuleHtml.includes('id="usageReportingToggle"'), 'other module must not duplicate usage reporting');
  assert.ok(cssSource.includes('.usage-reporting-compact'));
  assert.ok(html.includes('Agent&#35843;&#35797;'));
  assert.ok(!html.includes('kivi-video-intro compact'));
  assert.ok(!panelSource.includes('window.prompt('));
  assert.ok(panelSource.includes('data-scale-number'));
  assert.ok(panelSource.includes('bindVerticalResizer'));
  assert.ok(panelSource.includes('inspectKiviCandidateReferences'));
  assert.ok(!panelSource.includes('单击编辑，右键复制，Ctrl + 滚轮缩放'));
  assert.ok(cssSource.includes('.kivi-candidate.accepted::after'));
  assert.ok(cssSource.includes('.panel-confirm-overlay'));
  assert.ok(panelSource.includes('generateAgentPrompts'));
  assert.ok(panelSource.includes('PromptAgentRunner'));
  assert.ok(panelSource.includes('DeepSeekProvider'));
  assert.ok(panelSource.includes('AgentSkillStore'));
  assert.ok(panelSource.includes('PreviewArchiveStore'));
  assert.ok(panelSource.includes('loopDuration: kiviAdoptionDuration'));
  assert.ok(panelSource.includes('video.duration / kiviAdoptionDuration'));
  assert.ok(!panelSource.includes("textContent = '2S 循环'"));
  assert.strictEqual(updaterConfig.repo, 'ae-canvas-bridge-kivi-video-updates');
  assert.ok(updaterConfig.manifestUrl.includes('/ae-canvas-bridge-kivi-video-updates/'));
  assert.ok(!updaterConfig.manifestUrl.includes('/ae-canvas-bridge-public-updates/'));
  assert.ok(!panelSource.includes('稳定版自动更新不会影响此开发版'));
  assert.ok(!/async function checkForUpdates\(manual\)[\s\S]{0,300}setUpdateUi\('current'[\s\S]{0,200}\n\s*return;/.test(panelSource), 'development updater must not return before requesting its manifest');
  const effectivePreviewBinding = panelSource.slice(panelSource.lastIndexOf('bindPreviewCard = function bindPreviewCard'), panelSource.lastIndexOf('createPreviewCards = function createPreviewCards'));
  assert.ok(effectivePreviewBinding.includes('archiveActivePreviews([item])'), 'the effective preview delete handler must archive the preview');
  assert.ok(!effectivePreviewBinding.includes('safeUnlink(source.path)'), 'the effective preview delete handler must not directly delete the source');
  assert.ok(panelSource.includes('continueAgentDebugConversation'));
  assert.ok(!panelSource.includes('promptUsageReportingConsent'));
  assert.ok(panelSource.includes('origin: normalizeBridgeOrigin(asset.origin)'));
  assert.ok(panelSource.includes('origin: normalizeBridgeOrigin(meta.origin || meta.bridgeOrigin)'));
  assert.ok(panelSource.includes('pollProjectSaveForTelemetry'));
  assert.ok(panelSource.includes("scheduleUsageTelemetry(3000)"));
  assert.ok(!panelSource.includes('15 * 60 * 1000'));
  assert.ok(!panelSource.includes('scheduleUsageTelemetry(5000)'));
  assert.ok(panelSource.includes('Prompt 为空'));
  assert.ok(panelSource.includes('CanvasBridge.${method}'));
  assert.ok(hostSource.includes('CanvasBridge.addKiviCandidateToOrigin = function'));
  assert.ok(hostSource.includes('CanvasBridge.inspectKiviCandidateReferences = function'));
  assert.ok(hostSource.includes('Canvas Bridge 采纳合成'));
  assert.ok(hostSource.includes('wrapper.parentFolder = acceptedCompFolder'));
  for (const runtimeFile of ['panel.js', 'bridge-server.js', 'agent-skill-store.js', 'kivi-job-store.js', 'kivi-job-runner.js', 'usage-analytics.js', 'usage-telemetry.js', 'preview-archive-store.js']) {
    const runtimeSource = fs.readFileSync(path.resolve(__dirname, '..', 'js', runtimeFile), 'utf8');
    assert.ok(!runtimeSource.includes('recursive: true'), `${runtimeFile} uses unsupported recursive mkdir`);
    assert.ok(!runtimeSource.includes('withFileTypes'), `${runtimeFile} uses unsupported Dirent reads`);
    assert.ok(!runtimeSource.includes('Promise.allSettled'), `${runtimeFile} uses Promise.allSettled unavailable in AE 2019 CEP`);
  }
  assert.ok(hostSource.includes('CanvasBridge.addKiviCandidateToSelectedLayer = function'));
  assert.ok(hostSource.includes('CanvasBridge._compByOrigin = function'));
  assert.ok(hostSource.includes('CanvasBridge._selectedOriginTarget = function'));
  assert.ok(hostSource.includes('无法唯一匹配'));
  assert.ok(hostSource.includes('CanvasBridge.removeKiviCandidateEverywhere = function'));
  assert.ok(hostSource.includes('CanvasBridge.relinkKiviAssets = function'));
  assert.ok(hostSource.includes('CanvasBridge._sameProjectFamily'));
  assert.ok(hostSource.includes('Keylight 906-0004'));
  assert.ok(hostSource.includes('clipBlack.setValue(40)'));
  assert.ok(!hostSource.includes('ADBE KeyCleaner'));
  assert.ok(!hostSource.includes('ADBE Spill2'));
  assert.ok(hostSource.includes('info.name = layerInfo.name'));
  assert.ok(hostSource.includes('CanvasBridge._namesSimilar'));
  assert.ok(!hostSource.includes('parentLayer.name = wrapper.name'));
  assert.ok(hostSource.includes('* 100 * fitRatio * scaleMultiplier'));
  assert.ok(hostSource.includes('var loopDuration = Number(payload.loopDuration) === 3 ? 3 : 2'));
  assert.ok(hostSource.includes('wrapper.duration = loopDuration'));
  assert.ok(hostSource.includes('existingLayer.stretch = loopDuration * 100 / Number(videoItem.duration)'));
  assert.ok(hostSource.includes('existingLayer.outPoint = loopDuration'));
  assert.ok(hostSource.includes('wrapper.label = 13'));
  assert.ok(hostSource.includes('CBKIVI_REFERENCE:'));
  assert.ok(hostSource.includes('CBKIVI_REPLACEMENT:'));
  assert.ok(hostSource.includes('CanvasBridge._removeLegacyOriginalLayers'));
  assert.ok(hostSource.includes('CanvasBridge._removeLegacyReferenceLayers'));
  assert.ok(!hostSource.includes('wrapper.layers.add(originalSource)'));
  assert.ok(hostSource.includes('replacementLayer = parentLayer.duplicate()'));
  assert.ok(hostSource.includes('parentLayer.enabled = false'));
  assert.ok(hostSource.includes('replacementLayer.replaceSource(wrapper, false)'));
  assert.strictEqual((hostSource.match(/parentLayer\.replaceSource\(wrapper, false\)/g) || []).length, 1, 'restoring the legacy source is only allowed in rollback');
  assert.ok(/catch \(error\)[\s\S]*parentLayer\.replaceSource\(wrapper, false\)/.test(hostSource));
  assert.ok(hostSource.includes('"KIVI_" + String(payload.jobName'));
  assert.ok(hostSource.includes('parentSourceComment.indexOf("CBKIVI_JOB:") === 0'));
  assert.ok(hostSource.includes('if (wrapperOwnedByJob) wrapper.name'));
  assert.strictEqual((panelSource.match(/async function renderFinalAssets\(/g) || []).length, 1, 'final renderer should have one implementation');
  assert.ok(chromeContentSource.includes('canvasBridgeOrigins:'));
  assert.ok(chromeContentSource.includes('origins[nodeId] = { nodeId, fileName: meta.fileName, origin, at: now }'));
  assert.ok(chromeBackgroundSource.includes('lineageNodeIds: lineageOf(id)'));
  assert.ok(chromeBackgroundSource.includes('origin: asset.origin || null'));
  assert.ok(chromeBackgroundSource.includes('originSourceNodeId: asset.originSourceNodeId ||'));
  assert.ok(chromeContentSource.includes('nodeName: nodeName(item)'));
  assert.ok(chromeBackgroundSource.includes('title: cleanNodeName(titleOverride'));
  assert.ok(chromeBackgroundSource.includes('displayName: String(asset.displayName || asset.fileName'));
});

test('legacy task names migrate to the original AE layer name and queue sorting is deterministic', () => {
  const base = {
    source: { fileName: 'shared-source.png', path: 'C:\\temp\\shared-source.png' },
    origin: {
      layer: { name: '右下_信封 2' },
      source: { name: 'shared-source.png' }
    },
    runs: []
  };
  const migrated = normalizeJob(Object.assign({ id: 'legacy', name: 'shared-source.png', createdAt: 10 }, base), false);
  assert.strictEqual(migrated.name, '右下_信封 2');
  assert.strictEqual(migrated.source.layerName, '右下_信封 2');

  const jobs = [
    normalizeJob({ id: 'draft', name: 'B', createdAt: 4, runs: [] }, false),
    normalizeJob({ id: 'accepted', name: 'C', createdAt: 3, runs: [{ id: 'r1', status: 'completed', candidates: [{ id: 'c1', status: 'accepted' }] }] }, false),
    normalizeJob({ id: 'generating', name: 'A', createdAt: 2, runs: [{ id: 'r2', status: 'running', candidates: [] }] }, false),
    normalizeJob({ id: 'review', name: 'D', createdAt: 1, runs: [{ id: 'r3', status: 'completed', candidates: [{ id: 'c2', status: 'ready' }] }] }, false)
  ];
  assert.deepStrictEqual(sortJobs(jobs, 'status').map(job => job.id), ['review', 'generating', 'accepted', 'draft']);
  assert.deepStrictEqual(sortJobs(jobs, 'generating').map(job => job.id), ['generating', 'review', 'draft', 'accepted']);
  assert.deepStrictEqual(sortJobs(jobs, 'name').map(job => job.id), ['generating', 'draft', 'accepted', 'review']);
});

test('auto-save projects resolve to the original workspace and manual selections normalize safely', () => {
  const root = tempDirectory('kivi-auto-save-recovery');
  try {
    const autoSave = path.join(root, 'Adobe After Effects Auto-Save');
    const workspace = workspacePath(root);
    fs.mkdirSync(autoSave, { recursive: true });
    fs.mkdirSync(workspace, { recursive: true });
    fs.writeFileSync(path.join(workspace, 'jobs.json'), JSON.stringify({ schemaVersion: 2, jobs: [] }), 'utf8');
    const resolved = resolveProjectRoot({ projectDirectory: autoSave });
    assert.strictEqual(resolved.projectRoot, root);
    assert.strictEqual(resolved.workspaceRoot, workspace);
    assert.strictEqual(resolved.source, 'auto-save-parent');
    assert.strictEqual(projectRootFromSelection(workspace), root);
    assert.strictEqual(projectRootFromSelection(path.dirname(workspace)), root);
  } finally { removeDirectory(root); }
});

test('project store repairs moved workspace and accepted candidate paths', () => {
  const root = tempDirectory('kivi-relink-paths');
  try {
    const importRoot = path.join(root, 'Canvas Bridge 导入');
    const workspace = path.join(importRoot, '_KIVI任务工作区');
    const acceptedRoot = path.join(importRoot, 'Kivi Videos');
    const source = path.join(root, 'source.png');
    fs.mkdirSync(acceptedRoot, { recursive: true });
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(workspace);
    store.load();
    const job = store.addRenderedAssets([{ path: source, fileName: 'source.png', width: 1000, height: 1000 }])[0];
    const run = store.createRun(job.id);
    run.status = 'completed';
    run.stage = 'review';
    const output = store.outputDirectory(job.id, run.id);
    const candidatePath = path.join(output, 'source-C001.mp4');
    const acceptedPath = path.join(acceptedRoot, 'source-C001.mp4');
    fs.writeFileSync(candidatePath, Buffer.from('0000ftypisom'));
    fs.copyFileSync(candidatePath, acceptedPath);
    run.candidates = [{ id: 'candidate-1', sequence: 1, localPath: 'Z:\\missing\\source-C001.mp4', acceptedPath: 'Z:\\missing\\source-C001.mp4', status: 'missing' }];
    job.source.path = 'Z:\\missing\\source.png';
    store.save();
    const repairs = store.relinkPaths(importRoot);
    assert.strictEqual(repairs.repairedSources, 1);
    assert.strictEqual(repairs.repairedCandidates, 1);
    assert.strictEqual(repairs.repairedAccepted, 1);
    assert.strictEqual(run.candidates[0].status, 'accepted');
    assert.strictEqual(run.candidates[0].localPath, candidatePath);
    assert.strictEqual(run.candidates[0].acceptedPath, acceptedPath);
  } finally { removeDirectory(root); }
});

test('origin placement centers doubled wrapper content and exposes the exact anchor delta', () => {
  const hostSource = fs.readFileSync(path.resolve(__dirname, '..', 'jsx', 'host.jsx'), 'utf8');
  const sandbox = {};
  vm.runInNewContext(hostSource, sandbox);
  const placement = sandbox.CanvasBridge._kiviPlacement(241, 242);
  assert.strictEqual(placement.wrapperWidth, 482);
  assert.strictEqual(placement.wrapperHeight, 484);
  assert.deepStrictEqual(Array.from(placement.center), [241, 242]);
  assert.deepStrictEqual(Array.from(placement.anchorDelta), [120.5, 121]);
});

test('replacement anchor is rebuilt from the original layer instead of the post-replace anchor', () => {
  const hostSource = fs.readFileSync(path.resolve(__dirname, '..', 'jsx', 'host.jsx'), 'utf8');
  const sandbox = {};
  vm.runInNewContext(hostSource, sandbox);
  const point = value => ({ value, numKeys: 0, setValue(next) { this.value = next; } });
  const parentAnchor = point([250, 300]);
  const replacementAnchor = point([750, 900]);
  const layer = anchor => ({ property(name) { return name === 'ADBE Transform Group' ? { property(child) { return child === 'ADBE Anchor Point' ? anchor : null; } } : null; } });
  sandbox.CanvasBridge._alignReplacementAnchor(layer(replacementAnchor), layer(parentAnchor), [0, 0], 250, 300);
  assert.deepStrictEqual(Array.from(replacementAnchor.value), [500, 600]);

  const keyedParent = { value: [10, 20], numKeys: 2, keyValue(index) { return index === 1 ? [10, 20] : [30, 40]; } };
  const keyedValues = [];
  const keyedReplacement = { numKeys: 2, setValueAtKey(index, value) { keyedValues[index - 1] = value; } };
  sandbox.CanvasBridge._alignReplacementAnchor(layer(keyedReplacement), layer(keyedParent), [0, 0], 5, 6);
  assert.deepStrictEqual(keyedValues.map(value => Array.from(value)), [[15, 26], [35, 46]]);
});

async function withServer(handler, run) {
  const server = http.createServer(handler);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try { return await run(`http://127.0.0.1:${server.address().port}`); }
  finally { await new Promise(resolve => server.close(resolve)); }
}

function readJsonRequest(request) {
  return new Promise(resolve => {
    const chunks = [];
    request.on('data', chunk => chunks.push(chunk));
    request.on('end', () => resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')));
  });
}

test('DeepSeek provider sends one local image through Responses API structured output', async () => {
  const root = tempDirectory('deepseek-provider');
  try {
    const imagePath = path.join(root, 'source.png');
    fs.writeFileSync(imagePath, Buffer.concat([Buffer.from([0x89]), Buffer.from('PNG\r\n\x1a\n'), Buffer.alloc(16)]));
    const encoded = imageDataUrl(imagePath);
    assert.strictEqual(encoded.mimeType, 'image/png');
    let requestBody;
    await withServer(async (request, response) => {
      response.setHeader('Content-Type', 'application/json');
      if (request.method === 'GET') {
        response.end(JSON.stringify({ object: 'list', data: [{ id: 'deepseek-flash', object: 'model', owned_by: 'deepseek' }, { id: 'deepseek-v4-pro', object: 'model', owned_by: 'deepseek' }] }));
        return;
      }
      requestBody = await readJsonRequest(request);
      response.end(JSON.stringify({ id: 'resp-test', status: 'completed', model: 'deepseek-flash', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify({ prompt: 'subtle motion', summary: 'small loop', warnings: [] }) }] }], usage: { input_tokens: 20, output_tokens: 10, total_tokens: 30 } }));
    }, async base => {
      const provider = new DeepSeekProvider({ apiKey: 'test-secret-key', apiBase: base, maxAttempts: 1, timeoutMs: 2000 });
      assert.deepStrictEqual(await provider.listModels(), ['deepseek-flash']);
      const context = { imagePath, skill: { name: 'test', version: 1, content: 'Write concise prompts.' }, job: { id: 'job-1', mode: 'flf2v', settings: { model: 'seedance-2.0', ratio: '1:1', resolution: '720P', duration: 4 } } };
      const result = await provider.generatePrompt(context);
      assert.strictEqual(result.prompt, 'subtle motion');
      assert.strictEqual(result.usage.total_tokens, 30);
      const refined = await provider.refinePrompt(Object.assign({}, context, { currentPrompt: result.prompt, feedback: 'Reduce the glow.', history: [{ role: 'assistant', text: result.prompt }] }));
      assert.strictEqual(refined.prompt, 'subtle motion');
    });
    assert.strictEqual(requestBody.model, 'deepseek-flash');
    assert.strictEqual(requestBody.reasoning.effort, 'none');
    assert.strictEqual(requestBody.text.format.type, 'json_schema');
    assert.match(requestBody.input[0].content[1].image_url, /^data:image\/png;base64,/);
    assert.match(requestBody.input[0].content[0].text, /Reduce the glow/);
    assert.match(requestBody.input[0].content[0].text, /Current prompt/);
    assert.strictEqual(outputText({ output: [{ type: 'reasoning', content: [{ type: 'reasoning_text', text: 'hidden' }] }, { type: 'message', content: [{ type: 'output_text', text: 'visible' }] }] }), 'visible');
  } finally { removeDirectory(root); }
});

test('preview archive persists layout metadata and only deletes managed copies', () => {
  const root = tempDirectory('preview-archive');
  const outside = path.join(root, 'outside.png');
  fs.writeFileSync(outside, Buffer.from('preview'));
  const storeRoot = path.join(root, 'store');
  try {
    const store = new PreviewArchiveStore(storeRoot);
    const archived = store.archive([{ item: { id: 7, name: 'wing', width: 1000, height: 1000 }, layout: { x: 0.4, y: 0.6, scale: 1.2 }, option: { name: 'wing export' }, source: { path: outside, width: 1000, height: 1000 } }]);
    assert.strictEqual(archived.length, 1);
    assert.ok(fs.existsSync(archived[0].source.path));
    assert.strictEqual(new PreviewArchiveStore(storeRoot).list()[0].layout.scale, 1.2);
    assert.strictEqual(store.remove(archived[0].id), 1);
    assert.strictEqual(fs.existsSync(archived[0].source.path), false);
    assert.strictEqual(fs.existsSync(outside), true);
  } finally { removeDirectory(root); }
});

test('API builds first-last and general-reference payloads with 1/2 outputs', async () => {
  const bodies = [];
  await withServer(async (request, response) => {
    if (request.url.endsWith('/batch_get')) {
      const body = await readJsonRequest(request);
      response.setHeader('Content-Type', 'application/json');
      response.end(JSON.stringify({ code: 200, data: body.ids.slice().reverse().map(id => ({ task: { id, status: 'running' }, requests: [] })) }));
      return;
    }
    bodies.push(await readJsonRequest(request));
    response.setHeader('Content-Type', 'application/json');
    response.end(JSON.stringify({ code: 200, data: { id: bodies.length } }));
  }, async base => {
    const client = createClient({ token: 'test-token', apiBase: base });
    await client.createVideo({ mode: 'flf2v', imageUrl: 'https://image/one.png', model: 'seedance-2.0', ratio: '1:1', resolution: '720P', duration: 4, outputCount: 2 });
    await client.createVideo({ mode: 'general_reference', imageUrl: 'https://image/two.png', model: 'seedance-2.0', ratio: '1:1', resolution: '720P', duration: 4, outputCount: 1 });
    const batch = await client.batchGetTasks([11, 12]);
    assert.deepStrictEqual(batch.data.map(item => item.task.id), [12, 11]);
  });
  const first = bodies[0].biz_input;
  assert.strictEqual(first.num_outputs, 2);
  assert.strictEqual(first.general_reference.reference_type, 'flf2v');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(first, 'aspect_ratio'), false, 'first-last generation must follow the first frame ratio');
  assert.strictEqual(first.general_reference.items[0].content, first.general_reference.items[1].content);
  assert.deepStrictEqual(first.general_reference.items.map(item => item.reference_type), ['first_frame', 'last_frame']);
  const reference = bodies[1].biz_input;
  assert.strictEqual(reference.num_outputs, 1);
  assert.strictEqual(reference.general_reference.reference_type, 'general_reference');
  assert.strictEqual(reference.aspect_ratio, '1:1');
  assert.strictEqual(reference.general_reference.items[0].reference_type, 'reference');
});

test('API reads KIVI identity, quota, and per-task accounting fields', async () => {
  await withServer((request, response) => {
    response.setHeader('Content-Type', 'application/json');
    if (request.url === '/api/auth/user/info') {
      response.end(JSON.stringify({ code: 200, data: { username: 'cookie', real_name: 'Cookie', email: 'cookie@example.com', dept_name: 'Design', dept_tag: 'Creative', sub_dept_name: 'Motion', roles: ['user'], permissions: ['AI_VIDEO_GENERATE'] } }));
      return;
    }
    if (request.url === '/api/ai/prediction/quota') {
      response.end(JSON.stringify({ code: 200, data: { basic_coin: 100, tmp_coin: 20, usage: 35, refund: 5, remaining: 120, quota: 150, basic_quota: 120, temp_quota: 30 } }));
      return;
    }
    response.statusCode = 404;
    response.end(JSON.stringify({ code: 404, msg: 'missing' }));
  }, async base => {
    const client = createClient({ token: 'test-token', apiBase: base });
    const user = await client.getUserInfo();
    const quota = await client.getQuota();
    assert.deepStrictEqual(user, normalizeUserInfo({ data: { username: 'cookie', real_name: 'Cookie', email: 'cookie@example.com', dept_name: 'Design', dept_tag: 'Creative', sub_dept_name: 'Motion', roles: ['user'], permissions: ['AI_VIDEO_GENERATE'] } }));
    assert.strictEqual(user.realName, 'Cookie');
    assert.strictEqual(user.departmentName, 'Design');
    assert.deepStrictEqual(quota, normalizeQuota({ data: { basic_coin: 100, tmp_coin: 20, usage: 35, refund: 5, remaining: 120, quota: 150, basic_quota: 120, temp_quota: 30 } }));
    assert.strictEqual(quota.remaining, 120);
  });
  assert.deepStrictEqual(taskAccounting({ task: { cost: 12, refund: true, user_id: 99, retry_times: 2 } }), { cost: 12, refund: true, userId: '99', retryTimes: 2 });
});

test('API extracts every candidate URL from requests', () => {
  const urls = extractVideoUrls({ data: { requests: [
    { content: 'https://cdn/video-a.mp4' },
    { content: 'https://cdn/video-b.mp4' }
  ] } });
  assert.deepStrictEqual(urls, ['https://cdn/video-a.mp4', 'https://cdn/video-b.mp4']);
});

test('API ignores success messages when reading task errors', () => {
  assert.strictEqual(taskError({ code: 200, message: 'Success', task: { status: 'running' } }), '');
  assert.strictEqual(taskError({ code: 200, message: 'Success', task: { status: 'failed', error_msg: 'model rejected input' } }), 'model rejected input');
});

test('runtime model list keeps only active KIVI video models in priority order', () => {
  const models = normalizeVideoModels({ data: [
    { model_name: 'image-only', display_name: 'Image', media_type: 'image', priority: 0 },
    { model_name: 'video-later', display_name: 'Video Later', media_type: 'video', priority: 4 },
    { model_name: 'video-deleted', display_name: 'Deleted', media_type: 'video', is_del: true, priority: 1 },
    { model_name: 'video-first', display_name: 'Video First', media_type: 'video', tags: '720P', priority: 1 }
  ] });
  assert.deepStrictEqual(models.map(model => model.name), ['video-first', 'video-later']);
  assert.strictEqual(models[0].tags, '720P');
});

test('API reads the current KIVI video model catalog at runtime', async () => {
  await withServer((request, response) => {
    assert.strictEqual(request.url, '/api/model/base_models');
    response.setHeader('Content-Type', 'application/json');
    response.end(JSON.stringify({ code: 200, data: [
      { model_name: 'seedance-2.0', display_name: 'Seedance 2.0', media_type: 'video', priority: 2 },
      { model_name: 'wan-3.0', display_name: 'Wan 3.0', media_type: 'video', priority: 1 }
    ] }));
  }, async base => {
    const client = createClient({ token: 'test-token', apiBase: base });
    const models = await client.listVideoModels();
    assert.deepStrictEqual(models.map(model => model.name), ['wan-3.0', 'seedance-2.0']);
  });
});

test('unreviewed candidates take priority over older accepted results', () => {
  const job = {
    runs: [
      { status: 'completed', candidates: [{ status: 'accepted' }] },
      { status: 'completed', candidates: [{ status: 'ready' }] }
    ]
  };
  assert.strictEqual(deriveJobStatus(job), 'review');
});

test('project store creates ten independent jobs and recovers interrupted submissions', () => {
  const root = tempDirectory('kivi-store');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const jobs = store.addRenderedAssets(Array.from({ length: 10 }, (_, index) => ({ path: source, fileName: `asset-${index}.png`, width: 500, height: 500 })));
    assert.strictEqual(jobs.length, 10);
    assert.strictEqual(store.state.jobs.length, 10);
    assert.strictEqual(new Set(store.state.jobs.map(job => job.source.path)).size, 10);
    const run = store.createRun(jobs[0].id);
    assert.strictEqual(deriveJobStatus(jobs[0]), 'generating');
    run.taskId = '';
    run.status = 'submitting';
    store.save();
    const restored = new KiviJobStore(store.root);
    restored.load();
    assert.strictEqual(restored.findJob(jobs[0].id).runs[0].status, 'failed');
  } finally { removeDirectory(root); }
});

test('project store restores its backup when jobs.json is damaged', () => {
  const root = tempDirectory('kivi-store-backup');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 500, height: 500 }]);
    store.state.jobs[0].prompt = 'backup prompt';
    store.save();
    fs.writeFileSync(store.jobsFile, '{broken json', 'utf8');
    const restored = new KiviJobStore(store.root);
    restored.load();
    assert.strictEqual(restored.state.jobs.length, 1);
    assert.ok(fs.existsSync(restored.jobsFile));
  } finally { removeDirectory(root); }
});

test('project store restores backup when the primary file is missing', () => {
  const root = tempDirectory('kivi-store-missing-primary');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 500, height: 500 }]);
    store.save();
    fs.unlinkSync(store.jobsFile);
    const restored = new KiviJobStore(store.root);
    restored.load();
    assert.strictEqual(restored.state.jobs.length, 1);
    assert.ok(fs.existsSync(restored.jobsFile));
  } finally { removeDirectory(root); }
});

test('accepted copy preserves accepted state if the workspace candidate is missing', () => {
  const root = tempDirectory('kivi-accepted-copy');
  try {
    const accepted = path.join(root, 'accepted.mp4');
    fs.writeFileSync(accepted, Buffer.from('0000ftypisom'));
    const run = normalizeRun({
      status: 'completed',
      candidates: [
        { status: 'accepted', localPath: path.join(root, 'missing.mp4'), acceptedPath: accepted },
        { status: 'rejected', rejectedFromStatus: 'accepted', localPath: path.join(root, 'missing-rejected.mp4'), acceptedPath: accepted }
      ]
    }, true);
    assert.strictEqual(run.candidates[0].status, 'accepted');
    assert.strictEqual(run.candidates[1].status, 'rejected');
    assert.strictEqual(run.candidates[1].rejectedFromStatus, 'accepted');
  } finally { removeDirectory(root); }
});

test('schema v1 jobs migrate to stable task-wide candidate sequences without renaming files', () => {
  const root = tempDirectory('kivi-schema-v2');
  try {
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace, { recursive: true });
    const firstPath = path.join(root, 'legacy-one.mp4');
    const acceptedPath = path.join(root, 'legacy-accepted.mp4');
    fs.writeFileSync(firstPath, Buffer.from('0000ftypisom'));
    fs.writeFileSync(acceptedPath, Buffer.from('0000ftypisom'));
    fs.writeFileSync(path.join(workspace, 'jobs.json'), JSON.stringify({ schemaVersion: 1, jobs: [{
      id: 'legacy-job', name: 'legacy', source: {}, runs: [
        { id: 'run-2', createdAt: 200, status: 'completed', candidates: [{ id: 'two', localPath: 'missing.mp4', acceptedPath, status: 'accepted' }] },
        { id: 'run-1', createdAt: 100, status: 'completed', candidates: [{ id: 'one', localPath: firstPath, status: 'ready' }] }
      ]
    }] }), 'utf8');
    const store = new KiviJobStore(workspace);
    store.load();
    const job = store.findJob('legacy-job');
    assert.strictEqual(store.state.schemaVersion, SCHEMA_VERSION);
    assert.deepStrictEqual(job.runs.flatMap(run => run.candidates.map(candidate => candidate.sequence)), [2, 1]);
    assert.strictEqual(job.nextCandidateSequence, 3);
    assert.strictEqual(job.runs[0].candidates[0].acceptedPath, acceptedPath);
    assert.ok(fs.existsSync(acceptedPath));
  } finally { removeDirectory(root); }
});

test('schema v2 jobs migrate to schema v5 and interrupted prompt work becomes retryable', () => {
  const root = tempDirectory('kivi-schema-v3');
  try {
    const workspace = path.join(root, 'workspace');
    fs.mkdirSync(workspace, { recursive: true });
    fs.writeFileSync(path.join(workspace, 'jobs.json'), JSON.stringify({ schemaVersion: 2, jobs: [{
      id: 'legacy-v2', name: 'legacy prompt', source: {}, prompt: 'keep me', promptState: { status: 'analyzing' }, runs: []
    }] }), 'utf8');
    const store = new KiviJobStore(workspace);
    store.load();
    const job = store.findJob('legacy-v2');
    assert.strictEqual(store.state.schemaVersion, SCHEMA_VERSION);
    assert.strictEqual(job.prompt, 'keep me');
    assert.strictEqual(job.promptState.status, 'interrupted');
    assert.match(job.promptState.error, /重新生成 Prompt/);
    assert.deepStrictEqual(job.promptHistory, []);
    assert.strictEqual(job.archivedAt, 0);
  } finally { removeDirectory(root); }
});

test('schema v3 jobs migrate to schema v5 with recoverable archive and preserved accepted copies', () => {
  const root = tempDirectory('kivi-schema-v4-archive');
  try {
    const source = path.join(root, 'source.png');
    const accepted = path.join(root, 'accepted.mp4');
    fs.writeFileSync(source, Buffer.from('png'));
    fs.writeFileSync(accepted, Buffer.from('0000ftypisom'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const job = store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 1000, height: 1000 }])[0];
    job.prompt = 'keep prompt';
    job.runs = [normalizeRun({ id: 'run', status: 'completed', candidates: [{ id: 'candidate', status: 'accepted', acceptedPath: accepted }] })];
    store.save();
    assert.strictEqual(store.archiveJob(job.id), true);
    assert.ok(store.findJob(job.id).archivedAt > 0);
    assert.strictEqual(store.findJob(job.id).prompt, 'keep prompt');
    assert.strictEqual(store.restoreJob(job.id), true);
    assert.strictEqual(store.findJob(job.id).archivedAt, 0);
    store.archiveJob(job.id);
    assert.strictEqual(store.removeJob(job.id), true);
    assert.strictEqual(store.findJob(job.id), null);
    assert.ok(fs.existsSync(accepted), 'accepted library copy must survive permanent task deletion');
  } finally { removeDirectory(root); }
});

test('generated prompt history is bounded, preserves overwritten text, and can be restored', () => {
  const root = tempDirectory('kivi-prompt-history');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const job = store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 500, height: 500 }])[0];
    job.prompt = 'manual original';
    store.applyGeneratedPrompt(job.id, 'agent one', { provider: 'deepseek', model: 'deepseek-flash', skillId: 'skill', skillVersion: 2, skillHash: 'abc' });
    assert.strictEqual(job.promptHistory[0].text, 'manual original');
    store.markPromptManual(job.id, 'manual edit');
    assert.strictEqual(job.promptHistory.some(entry => entry.text === 'agent one'), true);
    for (let index = 0; index < 25; index += 1) store.applyGeneratedPrompt(job.id, `agent ${index + 2}`, { provider: 'deepseek' });
    assert.strictEqual(job.promptHistory.length, 20);
    const restoreId = job.promptHistory[0].id;
    const restoreText = job.promptHistory[0].text;
    store.restorePrompt(job.id, restoreId);
    assert.strictEqual(job.prompt, restoreText);
    assert.strictEqual(job.promptHistory.length, 20);
  } finally { removeDirectory(root); }
});

test('skill store imports UTF-8 Markdown, versions custom edits, and protects bundled skills', () => {
  const root = tempDirectory('agent-skill-store');
  try {
    const bundled = path.join(root, 'bundled');
    const imported = path.join(root, 'motion.md');
    fs.mkdirSync(bundled, { recursive: true });
    fs.writeFileSync(path.join(bundled, 'default.md'), '# Built in\nKeep the subject.', 'utf8');
    fs.writeFileSync(imported, '# Motion\nCreate a subtle loop.', 'utf8');
    const store = new AgentSkillStore({ root: path.join(root, 'data'), bundledRoot: bundled });
    store.load();
    const builtIn = store.getActive();
    assert.strictEqual(builtIn.readOnly, true);
    assert.throws(() => store.update(builtIn.id, 'changed'), /只读/);
    const custom = store.importFile(imported);
    assert.strictEqual(custom.version, 1);
    const updated = store.update(custom.id, '# Motion v2\nCreate a seamless loop.', 'Loop Skill');
    assert.strictEqual(updated.version, 2);
    assert.strictEqual(updated.name, 'Loop Skill');
    assert.ok(updated.hash);
    assert.throws(() => store.importFile(path.join(root, 'wrong.txt')), /仅支持/);
    assert.throws(() => store.update(custom.id, 'x'.repeat(MAX_SKILL_BYTES + 1)), /256 KB/);
    const copy = store.duplicate(builtIn.id);
    assert.strictEqual(copy.readOnly, false);
  } finally { removeDirectory(root); }
});

test('rendered asset origin snapshots are persisted independently', () => {
  const root = tempDirectory('kivi-origin');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const origin = { projectPath: 'project.aep', compId: 10, layerId: 20, export: { backgroundHex: '#00FF00' } };
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const jobs = store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 1000, height: 1000, origin }]);
    origin.export.backgroundHex = '#FF0000';
    assert.strictEqual(jobs[0].origin.export.backgroundHex, '#00FF00');
  } finally { removeDirectory(root); }
});

test('duplicated task keeps editable inputs but starts with isolated source and no cloud results', () => {
  const root = tempDirectory('kivi-duplicate');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const original = store.addRenderedAssets([{ path: source, fileName: 'asset.png', width: 1000, height: 1000, origin: { projectPath: 'project.aep', export: { fitRatio: 1 } } }])[0];
    original.mode = 'general_reference';
    original.prompt = 'first方案';
    original.settings.outputCount = 2;
    original.runs.push({ id: 'old-run', status: 'completed', candidates: [{ id: 'old-candidate', status: 'ready' }] });
    store.save();
    const duplicate = store.duplicateJob(original.id);
    assert.notStrictEqual(duplicate.id, original.id);
    assert.notStrictEqual(duplicate.source.path, original.source.path);
    assert.ok(fs.existsSync(duplicate.source.path));
    assert.strictEqual(duplicate.mode, 'general_reference');
    assert.strictEqual(duplicate.prompt, 'first方案');
    assert.strictEqual(duplicate.settings.outputCount, 2);
    assert.strictEqual(duplicate.runs.length, 0);
    assert.strictEqual(duplicate.nextCandidateSequence, 1);
    duplicate.settings.outputCount = 1;
    duplicate.origin.export.fitRatio = 0.8;
    assert.strictEqual(original.settings.outputCount, 2);
    assert.strictEqual(original.origin.export.fitRatio, 1);
  } finally { removeDirectory(root); }
});

test('local usage analytics calculates adoption efficiency and real KIVI cost without uploading content', () => {
  const snapshot = buildUsageSnapshot({
    generatedAt: 500000,
    identity: { analyticsUserId: 'user-hash', username: 'cookie', realName: 'Cookie', departmentName: 'Design', email: 'must-not-leak@example.com' },
    pluginVersion: '0.4.3',
    aeVersion: '25.0',
    quota: { usage: 35, refund: 10, remaining: 120, quota: 150 },
    jobs: [
      {
        id: 'adopted', createdAt: 100000, runs: [
          { taskId: '1', status: 'failed', promptSource: 'manual', cost: 10, refund: true, candidates: [] },
          { taskId: '2', status: 'completed', promptSource: 'agent', cost: 20, refund: false, candidates: [{ status: 'accepted', acceptedPath: 'accepted.mp4', acceptedAt: 220000 }] }
        ]
      },
      {
        id: 'unused', createdAt: 120000, archivedAt: 400000, runs: [
          { taskId: '3', status: 'completed', promptSource: 'agent', cost: 15, refund: false, candidates: [{ status: 'rejected', rejectedAt: 300000 }] }
        ]
      }
    ]
  });
  assert.strictEqual(snapshot.identity.analyticsUserId, 'user-hash');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(snapshot.identity, 'email'), false);
  assert.strictEqual(snapshot.totals.jobs, 2);
  assert.strictEqual(snapshot.totals.runs, 3);
  assert.strictEqual(snapshot.totals.adoptedJobs, 1);
  assert.strictEqual(snapshot.totals.grossCost, 45);
  assert.strictEqual(snapshot.totals.refundedCost, 10);
  assert.strictEqual(snapshot.totals.netCost, 35);
  assert.strictEqual(snapshot.totals.acceptedJobNetCost, 20);
  assert.strictEqual(snapshot.totals.unadoptedNetCost, 15);
  assert.strictEqual(snapshot.totals.wastedNetCost, 15);
  assert.strictEqual(snapshot.totals.medianRunsToFirstAcceptance, 2);
  assert.strictEqual(snapshot.totals.medianMinutesToFirstAcceptance, 2);
  assert.strictEqual(snapshot.totals.netCostPerAdoptedJob, 20);
  assert.strictEqual(snapshot.totals.agentRuns, 2);
  assert.strictEqual(snapshot.totals.manualRuns, 1);
});

test('usage telemetry defaults on, queues locally, strips email, and respects later disable', async () => {
  const root = tempDirectory('kivi-usage-telemetry');
  try {
    let delivered = null;
    const telemetry = new UsageTelemetry({
      root,
      endpoint: 'https://analytics.example.test/v1/usage/snapshots',
      token: 'install-token',
      transport: async (url, token, payload) => {
        delivered = { url, token, payload };
        return { statusCode: 202, body: '{"ok":true}' };
      }
    });
    assert.strictEqual(telemetry.isEnabled(), true);
    assert.strictEqual(telemetry.isConfigured(), true);
    assert.strictEqual(telemetry.consentState(), 'enabled');
    const captured = await telemetry.capture({
      client: {
        getUserInfo: async () => ({ username: 'cookie', realName: 'Cookie', email: 'private@example.com', departmentName: 'Design' }),
        getQuota: async () => ({ usage: 12, refund: 2, remaining: 88, quota: 100 })
      },
      jobs: [{ id: 'job', createdAt: 1, runs: [{ taskId: '9', status: 'completed', cost: 5, refund: false, candidates: [] }] }],
      pluginVersion: '0.4.3',
      aeVersion: '25.0',
      generatedAt: 1234
    });
    assert.strictEqual(captured.queued, true);
    assert.strictEqual(telemetry.pendingFiles().length, 1);
    assert.strictEqual(JSON.stringify(captured.envelope).includes('private@example.com'), false);
    assert.ok(captured.envelope.installId.startsWith('install-'));
    assert.strictEqual(captured.envelope.consentVersion, '');
    const flushed = await telemetry.flush();
    assert.strictEqual(flushed.sent, 1);
    assert.strictEqual(flushed.pending, 0);
    assert.strictEqual(delivered.url, 'https://analytics.example.test/v1/usage/snapshots');
    assert.strictEqual(delivered.token, 'install-token');
    assert.strictEqual(delivered.payload.eventId, captured.eventId);
    telemetry.setConsent(false);
    assert.deepStrictEqual(await telemetry.capture({ client: null }), { queued: false, reason: 'consent-disabled' });
  } finally { removeDirectory(root); }
});

test('runner submits ten jobs without a client-side concurrency cap and maps reversed batch results', async () => {
  const root = tempDirectory('kivi-runner');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const jobs = store.addRenderedAssets(Array.from({ length: 10 }, (_, index) => ({ path: source, fileName: `asset-${index}.png`, width: 500, height: 500 })));
    jobs[0].settings.outputCount = 2;
    store.save();
    let nextTaskId = 100;
    let activeSubmissions = 0;
    let maximumSubmissions = 0;
    const client = {
      uploadFile: async () => ({ url: 'https://image/reference.png' }),
      createVideo: async () => {
        activeSubmissions += 1;
        maximumSubmissions = Math.max(maximumSubmissions, activeSubmissions);
        await new Promise(resolve => setTimeout(resolve, 5));
        activeSubmissions -= 1;
        nextTaskId += 1;
        return { data: { id: nextTaskId } };
      },
      batchGetTasks: async ids => ({ data: ids.slice().reverse().map(id => ({ task: { id, status: 'success', cost: Number(id) - 100, refund: String(id) === '102', user_id: 900, retry_times: 1 }, requests: [
        { content: `https://cdn/${id}-1.mp4` },
        { content: `https://cdn/${id}-2.mp4` }
      ] })) }),
      taskStatus: task => task.status,
      taskError: () => '',
      extractVideoUrls: record => record.requests.map(item => item.content),
      downloadFile: async (_url, destination) => { fs.writeFileSync(destination, Buffer.from('0000ftypisom')); return { bytes: 12, contentType: 'video/mp4' }; }
    };
    const runner = new KiviJobRunner({ store, readToken: async () => 'token', createClient: () => client, onChange: () => {}, pollIntervalMs: 60000 });
    const submitting = runner.startJobs(jobs.map(job => job.id));
    assert.ok(jobs.every(job => job.runs.length === 1), 'every selected job should expose a placeholder run immediately');
    assert.strictEqual(jobs[0].runs[0].settings.outputCount, 2);
    const submitted = await submitting;
    assert.strictEqual(submitted.filter(item => item.status === 'fulfilled').length, 10);
    assert.ok(maximumSubmissions > 1, 'submissions should overlap');
    await runner.pollNow();
    assert.strictEqual(store.state.jobs.filter(job => deriveJobStatus(job) === 'review').length, 10);
    assert.strictEqual(store.findJob(jobs[0].id).runs[0].candidates.length, 2);
    assert.strictEqual(store.findJob(jobs[0].id).runs[0].cost, 1);
    assert.strictEqual(store.findJob(jobs[0].id).runs[0].refund, false);
    assert.strictEqual(store.findJob(jobs[0].id).runs[0].kiviUserId, '900');
    assert.strictEqual(store.findJob(jobs[0].id).runs[0].retryTimes, 1);
    assert.ok(store.findJob(jobs[0].id).runs[0].completedAt > 0);
    assert.deepStrictEqual(store.findJob(jobs[0].id).runs[0].candidates.map(candidate => candidate.sequence), [1, 2]);
    assert.ok(store.findJob(jobs[0].id).runs[0].candidates[0].localPath.endsWith('asset-0-C001.mp4'));
    assert.strictEqual(store.state.jobs.filter(job => job.runs[0].candidates.length === 1).length, 9);

    await runner.startJob(jobs[0].id);
    await runner.pollNow();
    const regenerated = store.findJob(jobs[0].id);
    assert.deepStrictEqual(regenerated.runs[1].candidates.map(candidate => candidate.sequence), [3, 4]);
    assert.ok(regenerated.runs[1].candidates[0].localPath.endsWith('asset-0-C003.mp4'));
    assert.strictEqual(regenerated.nextCandidateSequence, 5);
    runner.stop();
  } finally { removeDirectory(root); }
});

test('runner resumes saved task ids and isolates partial batch failures', async () => {
  const root = tempDirectory('kivi-runner-resume');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const jobs = store.addRenderedAssets([
      { path: source, fileName: 'success.png', width: 500, height: 500 },
      { path: source, fileName: 'failure.png', width: 500, height: 500 }
    ]);
    jobs.forEach((job, index) => {
      const run = store.createRun(job.id);
      run.taskId = String(700 + index);
      run.status = 'running';
      run.stage = 'running';
    });
    store.save();
    const restored = new KiviJobStore(store.root);
    restored.load();
    const client = {
      batchGetTasks: async ids => ({ data: ids.slice().reverse().map(id => String(id) === '700'
        ? { task: { id, status: 'success' }, requests: [{ content: `https://cdn/${id}.mp4` }] }
        : { task: { id, status: 'failed', error_msg: 'model rejected input' }, requests: [] }) }),
      taskStatus: task => task.status,
      taskError: record => record.task.error_msg || '',
      extractVideoUrls: record => record.requests.map(item => item.content),
      downloadFile: async (_url, destination) => { fs.writeFileSync(destination, Buffer.from('0000ftypisom')); return { bytes: 12, contentType: 'video/mp4' }; }
    };
    const runner = new KiviJobRunner({ store: restored, readToken: async () => 'token', createClient: () => client, onChange: () => {}, pollIntervalMs: 60000 });
    await runner.pollNow();
    assert.strictEqual(deriveJobStatus(restored.findJob(jobs[0].id)), 'review');
    assert.strictEqual(deriveJobStatus(restored.findJob(jobs[1].id)), 'failed');
    assert.match(restored.findJob(jobs[1].id).runs[0].error, /model rejected input/);
    runner.stop();
  } finally { removeDirectory(root); }
});

test('prompt runner limits concurrency to three, skips existing batch prompts, and preserves failures', async () => {
  const root = tempDirectory('prompt-runner');
  try {
    const source = path.join(root, 'source.png');
    fs.writeFileSync(source, Buffer.from('png'));
    const store = new KiviJobStore(path.join(root, 'workspace'));
    store.load();
    const jobs = store.addRenderedAssets(Array.from({ length: 9 }, (_, index) => ({ path: source, fileName: `asset-${index}.png`, width: 500, height: 500 })));
    jobs[0].prompt = 'protected manual prompt';
    store.save();
    let active = 0;
    let maximum = 0;
    const provider = { generatePrompt: async ({ job }) => {
      active += 1;
      maximum = Math.max(maximum, active);
      await new Promise(resolve => setTimeout(resolve, 8));
      active -= 1;
      return { prompt: `generated ${job.id}`, summary: '', warnings: [], provider: 'deepseek', model: 'deepseek-flash', usage: { total_tokens: 5 }, requestId: job.id };
    } };
    const runner = new PromptAgentRunner({ store, createProvider: () => provider, readSkill: () => ({ id: 'skill', name: 'Skill', version: 1, hash: 'hash', content: 'instructions' }), concurrency: 3 });
    const results = await runner.startJobs(jobs.map(job => job.id), { onlyBlank: true });
    assert.strictEqual(results.length, 8);
    assert.strictEqual(maximum, 3);
    assert.strictEqual(jobs[0].prompt, 'protected manual prompt');
    assert.ok(jobs.slice(1).every(job => job.promptState.status === 'ready' && job.prompt.startsWith('generated ')));

    const failedRunner = new PromptAgentRunner({ store, createProvider: () => ({ generatePrompt: async () => { throw new Error('HTTP 400: bad request'); } }), readSkill: () => ({ id: 'skill', version: 1, hash: 'hash', content: 'instructions' }) });
    const previous = jobs[0].prompt;
    const failed = await failedRunner.startJobs([jobs[0].id], { onlyBlank: false });
    assert.strictEqual(failed[0].status, 'rejected');
    assert.strictEqual(jobs[0].prompt, previous);
    assert.strictEqual(jobs[0].promptState.status, 'failed');
  } finally { removeDirectory(root); }
});

test('generic DPAPI helper round-trips and clears a secret on Windows', () => {
  if (process.platform !== 'win32') return;
  const root = tempDirectory('agent-dpapi');
  try {
    const credential = path.join(root, 'deepseek.dpapi');
    const script = path.resolve(__dirname, '..', 'js', 'secure-credentials.ps1');
    const run = (action, input) => childProcess.spawnSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-Action', action, '-Path', credential], { input: input || '', encoding: 'utf8' });
    assert.strictEqual(run('set', 'test-secret-value').status, 0);
    assert.strictEqual(run('exists').stdout, '1');
    assert.strictEqual(run('read').stdout, 'test-secret-value');
    assert.strictEqual(run('clear').status, 0);
    assert.strictEqual(run('exists').stdout, '0');
  } finally { removeDirectory(root); }
});

(async function run() {
  let failures = 0;
  for (const item of tests) {
    try {
      await item.run();
      process.stdout.write(`PASS ${item.name}\n`);
    } catch (error) {
      failures += 1;
      process.stderr.write(`FAIL ${item.name}\n${error.stack || error}\n`);
    }
  }
  if (failures) process.exitCode = 1;
  else process.stdout.write(`\n${tests.length} tests passed.\n`);
}());
