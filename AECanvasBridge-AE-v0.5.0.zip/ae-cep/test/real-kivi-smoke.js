'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { createClient } = require('../js/kivi-api.js');

const imagePath = path.resolve(process.argv[2] || '');
const outputCount = Math.max(1, Math.min(2, Number(process.env.KIVI_OUTPUT_COUNT) || 2));
const credentialPath = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'AE Canvas Bridge', 'kivi-access-token.dpapi');
const credentialScript = path.resolve(__dirname, '..', 'js', 'kivi-credentials.ps1');
const outputRoot = path.resolve(__dirname, '..', '..', 'kivi-mvp', 'outputs');
const successStates = new Set(['success', 'succeed', 'completed', 'complete', 'finished', 'done']);
const failureStates = new Set(['failed', 'failure', 'error', 'cancelled', 'canceled', 'cancel', 'deleted']);

function readCredential() {
  const result = spawnSync('powershell.exe', [
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', credentialScript,
    '-Action', 'read', '-Path', credentialPath
  ], { encoding: 'utf8', windowsHide: true });
  if (result.status !== 0) throw new Error(String(result.stderr || '无法读取本机 KIVI 凭据').trim());
  const token = String(result.stdout || '').trim();
  if (!token) throw new Error('本机 KIVI 凭据为空');
  return token;
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function main() {
  if (!imagePath || !fs.existsSync(imagePath)) throw new Error('请传入存在的测试图片绝对路径');
  fs.mkdirSync(outputRoot, { recursive: true });
  const client = createClient({ token: readCredential() });
  process.stdout.write('REAL KIVI: uploading reference image\n');
  const upload = await client.uploadFile(imagePath, path.basename(imagePath), /\.jpe?g$/i.test(imagePath) ? 'image/jpeg' : 'image/png');
  process.stdout.write(`REAL KIVI: creating general-reference task (${outputCount} outputs)\n`);
  const created = await client.createVideo({
    mode: 'general_reference',
    imageUrl: upload.url,
    prompt: '角色自然地轻轻举杯致意，保持人物造型、服装和画面构图稳定，动作平滑，镜头固定。',
    model: 'seedance-2.0',
    ratio: '1:1',
    resolution: '720P',
    duration: 4,
    outputCount
  });
  const taskId = created && created.data && created.data.id;
  if (!taskId) throw new Error('KIVI 创建响应缺少 data.id');
  process.stdout.write(`REAL KIVI: task ${taskId} submitted\n`);

  let record = null;
  for (let attempt = 0; attempt < 180; attempt += 1) {
    await delay(attempt ? 4000 : 1000);
    const batch = await client.batchGetTasks([taskId]);
    record = Array.isArray(batch && batch.data)
      ? batch.data.find(item => String((item.task || item).id) === String(taskId))
      : null;
    if (!record) continue;
    const status = client.taskStatus(record.task || record);
    if (attempt === 0 || attempt % 6 === 0) process.stdout.write(`REAL KIVI: task ${taskId} status ${status || 'unknown'}\n`);
    if (successStates.has(status)) break;
    if (failureStates.has(status)) throw new Error(`KIVI task failed: ${client.taskError(record) || status}`);
    record = null;
  }
  if (!record) throw new Error(`KIVI task ${taskId} did not finish before timeout`);
  const urls = client.extractVideoUrls(record).slice(0, outputCount);
  if (urls.length !== outputCount) throw new Error(`KIVI task ${taskId} returned ${urls.length}/${outputCount} video URLs`);
  const outputs = [];
  for (let index = 0; index < urls.length; index += 1) {
    const destination = path.join(outputRoot, `real-general-reference-${taskId}-${String(index + 1).padStart(2, '0')}.mp4`);
    await client.downloadFile(urls[index], destination);
    const header = fs.readFileSync(destination).subarray(0, 32).toString('latin1');
    if (!/ftyp/.test(header)) throw new Error(`${path.basename(destination)} is not a valid MP4`);
    outputs.push(destination);
  }
  process.stdout.write(`REAL KIVI PASS: task ${taskId}; ${outputs.length} candidates\n`);
  outputs.forEach(file => process.stdout.write(`${file}\n`));
}

main().catch(error => {
  process.stderr.write(`REAL KIVI FAIL: ${error && error.message ? error.message : error}\n`);
  process.exitCode = 1;
});
