'use strict';

function numericParts(version) {
  return String(version || '')
    .split('.')
    .map(function (part) { return parseInt(part, 10) || 0; });
}

function compareVersions(left, right) {
  var leftParts = numericParts(left);
  var rightParts = numericParts(right);
  var length = Math.max(leftParts.length, rightParts.length);
  var index;
  for (index = 0; index < length; index += 1) {
    if ((leftParts[index] || 0) > (rightParts[index] || 0)) return 1;
    if ((leftParts[index] || 0) < (rightParts[index] || 0)) return -1;
  }
  return 0;
}

function installArrayIncludes() {
  if (Array.prototype.includes) return;
  Object.defineProperty(Array.prototype, 'includes', {
    configurable: true,
    writable: true,
    value: function (searchElement, fromIndex) {
      var source = Object(this);
      var length = parseInt(source.length, 10) || 0;
      var index = Number(fromIndex) || 0;
      if (index < 0) index = Math.max(length + index, 0);
      while (index < length) {
        if (source[index] === searchElement || (source[index] !== source[index] && searchElement !== searchElement)) return true;
        index += 1;
      }
      return false;
    }
  });
}

function installStringPadStart() {
  if (String.prototype.padStart) return;
  Object.defineProperty(String.prototype, 'padStart', {
    configurable: true,
    writable: true,
    value: function (targetLength, padString) {
      var text = String(this);
      var target = Math.max(parseInt(targetLength, 10) || 0, 0);
      var padding = padString === undefined ? ' ' : String(padString);
      if (text.length >= target || !padding) return text;
      while (padding.length < target - text.length) padding += padding;
      return padding.slice(0, target - text.length) + text;
    }
  });
}

function installObjectEntries() {
  if (Object.entries) return;
  Object.entries = function (value) {
    return Object.keys(Object(value)).map(function (key) { return [key, value[key]]; });
  };
}

function installPromiseFinally() {
  if (typeof Promise === 'undefined' || Promise.prototype.finally) return;
  Promise.prototype.finally = function (callback) {
    var Constructor = this.constructor;
    if (typeof callback !== 'function') return this.then(callback, callback);
    return this.then(
      function (value) { return Constructor.resolve(callback()).then(function () { return value; }); },
      function (reason) { return Constructor.resolve(callback()).then(function () { throw reason; }); }
    );
  };
}

function installUrl(root) {
  if (root.URL) return;
  try {
    root.URL = require('url').URL;
  } catch (_) {}
}

function detectChromiumVersion(userAgent, versions) {
  var runtimeVersions = versions || {};
  var direct = runtimeVersions.chromium || runtimeVersions.chrome;
  var match;
  if (direct) return String(direct);
  match = String(userAgent || '').match(/(?:Chrome|Chromium)\/([0-9.]+)/i);
  return match ? match[1] : '';
}

function install(userAgent, versions) {
  var root = typeof window !== 'undefined' ? window : global;
  var runtimeVersions = versions || (typeof process !== 'undefined' ? process.versions : {}) || {};
  var nodeVersion = String(runtimeVersions.node || '');
  var chromiumVersion = detectChromiumVersion(userAgent, runtimeVersions);
  var missing = [];

  installArrayIncludes();
  installStringPadStart();
  installObjectEntries();
  installPromiseFinally();
  installUrl(root);

  if (!Array.prototype.includes) missing.push('Array.includes');
  if (!String.prototype.padStart) missing.push('String.padStart');
  if (!Object.entries) missing.push('Object.entries');
  if (typeof Promise === 'undefined' || !Promise.prototype.finally) missing.push('Promise.finally');
  if (!root.URL) missing.push('URL');

  return {
    baseline: 'CEP 9 / AE 2019',
    nodeVersion: nodeVersion || 'unknown',
    chromiumVersion: chromiumVersion || 'unknown',
    nodeCompatible: !nodeVersion || compareVersions(nodeVersion, '8.6.0') >= 0,
    chromiumCompatible: !chromiumVersion || compareVersions(chromiumVersion, '61.0.3163.91') >= 0,
    missing: missing,
    ok: missing.length === 0 && (!nodeVersion || compareVersions(nodeVersion, '8.6.0') >= 0) && (!chromiumVersion || compareVersions(chromiumVersion, '61.0.3163.91') >= 0)
  };
}

module.exports = { compareVersions: compareVersions, install: install };
