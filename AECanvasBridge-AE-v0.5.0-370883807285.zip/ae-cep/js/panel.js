(function () {
  'use strict';

  const path = require('path');
  const fs = require('fs');
  const os = require('os');
  const crypto = require('crypto');
  const http = require('http');
  const https = require('https');
  const childProcess = require('child_process');
  const extensionRoot = decodeURIComponent(window.location.pathname)
    .replace(/^\/([A-Za-z]:)/, '$1')
    .replace(/\/index\.html$/i, '')
    .replace(/\//g, path.sep);
  const { BridgeServer } = require(path.join(extensionRoot, 'js', 'bridge-server.js'));
  const { createClient: createKiviClient } = require(path.join(extensionRoot, 'js', 'kivi-api.js'));
  const { KiviJobStore, deriveJobStatus, sortJobs } = require(path.join(extensionRoot, 'js', 'kivi-job-store.js'));
  const { KiviJobRunner } = require(path.join(extensionRoot, 'js', 'kivi-job-runner.js'));
  const KiviWorkspaceRecovery = require(path.join(extensionRoot, 'js', 'kivi-workspace-recovery.js'));
  const { DeepSeekProvider } = require(path.join(extensionRoot, 'js', 'deepseek-provider.js'));
  const { PromptAgentRunner } = require(path.join(extensionRoot, 'js', 'prompt-agent-runner.js'));
  const { AgentSkillStore } = require(path.join(extensionRoot, 'js', 'agent-skill-store.js'));
  const { UsageTelemetry } = require(path.join(extensionRoot, 'js', 'usage-telemetry.js'));
  const { PreviewArchiveStore } = require(path.join(extensionRoot, 'js', 'preview-archive-store.js'));
  const packageInfo = require(path.join(extensionRoot, 'package.json'));
  const CURRENT_AE_VERSION = String(packageInfo.version || '0.0.0');

  const $ = id => document.getElementById(id);
  const ui = {
    badge: $('connectionBadge'), code: $('pairingCode'), copyCode: $('copyPairingCode'), selectionSummary: $('selectionSummary'), selectionList: $('selectionList'),
    loadSelection: $('loadSelectionButton'), clearSelection: $('clearSelectionButton'), sizePresets: $('sizePresets'), customSize: $('customSize'), customWidth: $('customWidth'), customHeight: $('customHeight'),
    backgroundMode: $('backgroundMode'), customColorRow: $('customColorRow'), customColor: $('customColor'), customColorText: $('customColorText'),
    preview: $('previewButton'), previewSection: $('previewSection'), previewGrid: $('previewGrid'), previewZoom: $('previewZoom'), previewZoomValue: $('previewZoomValue'),
    previewActiveTab: $('previewActiveTab'), previewArchiveTab: $('previewArchiveTab'), previewArchiveCount: $('previewArchiveCount'), previewArchiveActions: $('previewArchiveActions'),
    restoreAllPreviewArchive: $('restoreAllPreviewArchive'), deleteAllPreviewArchive: $('deleteAllPreviewArchive'),
    status: $('statusText'), card: $('statusCard'), batchProgress: $('batchProgress'), progress: $('progressTrack'), bar: $('progressBar'),
    send: $('sendButton'), retry: $('retryButton'),
    exportPath: $('exportPath'), browseExportPath: $('browseExportPath'),
    localExport: $('localExportButton'), eagleExport: $('eagleExportButton'),
    moduleTabs: document.querySelectorAll('.module-tabs button'), exportModule: $('exportModule'), importModule: $('importModule'), renderModule: $('renderModule'), versionModule: $('versionModule'), kiviVideoModule: $('kiviVideoModule'), otherModule: $('otherModule'),
    importStatus: $('importStatusText'), importProgress: $('importProgressTrack'), importBar: $('importProgressBar'), importCount: $('importCount'), importZoomValue: $('importZoomValue'), importDirectory: $('importDirectory'),
    importHistory: $('importHistory'), clearImportHistory: $('clearImportHistory'), importSortMode: $('importSortMode'), importFormatFilter: $('importFormatFilter'),
    importRatingFilter: $('importRatingFilter'), importLayoutMode: $('importLayoutMode'), importVideoSound: $('importVideoSound'),
    reloadImportAssets: $('reloadImportAssets'), externalImportAssets: $('externalImportAssets'), batchImportEagle: $('batchImportEagle'), batchExportLocal: $('batchExportLocal'),
    toggleImportInfo: $('toggleImportInfo'), importInfoPanel: $('importInfoPanel'), kiviLoopDuration: $('kiviLoopDuration'),
    updateStatus: $('updateStatusText'), updateBadge: $('updateBadge'), currentAeVersion: $('currentAeVersion'), latestAeVersion: $('latestAeVersion'),
    updateNotes: $('updateNotes'), checkUpdate: $('checkUpdateButton'), installUpdate: $('installUpdateButton'),
    queueKiviVideo: $('queueKiviVideoButton'), kiviVideoStatus: $('kiviVideoStatus'), kiviKeyBadge: $('kiviKeyBadge'), prepareKiviVideoAssets: $('prepareKiviVideoAssets'),
    kiviJobFilter: $('kiviJobFilter'), kiviJobSort: $('kiviJobSort'), kiviSelectAll: $('kiviSelectAll'), generateSelectedKiviJobs: $('generateSelectedKiviJobs'),
    generateDraftPrompts: $('generateDraftPrompts'), cancelPromptBatch: $('cancelPromptBatch'),
    kiviJobCount: $('kiviJobCount'), kiviTaskZoomValue: $('kiviTaskZoomValue'), kiviJobList: $('kiviJobList'), kiviJobDetail: $('kiviJobDetail'), kiviCredentialSummary: $('kiviCredentialSummary'),
    kiviQueueTab: $('kiviQueueTab'), kiviArchiveTab: $('kiviArchiveTab'), kiviArchiveCount: $('kiviArchiveCount'), archiveAllKiviJobs: $('archiveAllKiviJobs'), purgeUnusedKiviMedia: $('purgeUnusedKiviMedia'),
    restoreAllArchivedJobs: $('restoreAllArchivedJobs'), deleteAllArchivedJobs: $('deleteAllArchivedJobs'), kiviQueueResizer: $('kiviQueueResizer'),
    autoRecoverKiviWorkspace: $('autoRecoverKiviWorkspace'), chooseKiviWorkspace: $('chooseKiviWorkspace'),
    kiviKeyInput: $('kiviKeyInput'), saveKiviKey: $('saveKiviKey'), clearKiviKey: $('clearKiviKey'),
    deepseekKeyBadge: $('deepseekKeyBadge'), deepseekKeyInput: $('deepseekKeyInput'), saveDeepseekKey: $('saveDeepseekKey'), clearDeepseekKey: $('clearDeepseekKey'),
    agentModel: $('agentModel'), testDeepseekConnection: $('testDeepseekConnection'), agentProviderStatus: $('agentProviderStatus'),
    agentSkillCard: $('agentSkillCard'), agentSkillStatus: $('agentSkillStatus'), agentSkillSelect: $('agentSkillSelect'), importAgentSkill: $('importAgentSkill'), duplicateAgentSkill: $('duplicateAgentSkill'),
    exportAgentSkill: $('exportAgentSkill'), deleteAgentSkill: $('deleteAgentSkill'), agentSkillName: $('agentSkillName'), agentSkillEditor: $('agentSkillEditor'),
    agentSkillMeta: $('agentSkillMeta'), reloadAgentSkill: $('reloadAgentSkill'), saveAgentSkill: $('saveAgentSkill'),
    agentDebugTask: $('agentDebugTask'), agentDebugPreview: $('agentDebugPreview'), runAgentDebug: $('runAgentDebug'), agentDebugSummary: $('agentDebugSummary'), agentDebugOutput: $('agentDebugOutput'),
    agentDebugConversation: $('agentDebugConversation'), agentDebugFeedback: $('agentDebugFeedback'), sendAgentDebugFeedback: $('sendAgentDebugFeedback'),
    applyAgentDebugPrompt: $('applyAgentDebugPrompt'), clearAgentDebugConversation: $('clearAgentDebugConversation'),
    usageReportingStatus: $('usageReportingStatus'), usageReportingToggle: $('usageReportingToggle'), usageReportingSync: $('usageReportingSync'), usageReportingDetail: $('usageReportingDetail')
  };

  let selectionItems = [];
  let selectionKey = '';
  let selectedSize = '1000';
  let previewReady = false;
  let busy = false;
  let lastRetryAssets = [];
  const layouts = new Map();
  const previewSources = new Map();
  const itemOptions = new Map();
  const previewArchiveStore = new PreviewArchiveStore(previewArchiveRoot());
  let previewView = localStorage.getItem('canvasBridgePreviewView') === 'archive' ? 'archive' : 'active';
  const agentDebugSessions = new Map();
  let importHistory = [];
  let pendingAutoPreview = false;
  let latestUpdate = null;
  let importBatchBusy = false;
  let kiviAdoptionDuration = 2;
  let kiviStore = null;
  let kiviRunner = null;
  let promptAgentRunner = null;
  let agentSkillStore = null;
  let deepseekCredentialConfigured = false;
  let kiviWorkspaceRoot = '';
  let kiviProjectRoot = '';
  let selectedKiviJobId = '';
  let kiviQueueView = localStorage.getItem('canvasBridgeKiviQueueView') === 'archive' ? 'archive' : 'queue';
  let kiviWorkspaceLoading = null;
  let kiviCountdownTimer = null;
  let usageTelemetry = null;
  let usageTelemetryTimer = null;
  let projectSaveMonitor = null;
  let lastProjectSaveSignature = '';
  let usageTelemetryInFlight = null;
  const fallbackKiviVideoModels = [{ name: 'seedance-2.0', label: 'Seedance 2.0', tags: '', description: '', priority: 0 }];
  let kiviVideoModels = fallbackKiviVideoModels.slice();
  let kiviVideoModelsLoading = null;
  let kiviVideoModelsLoaded = false;
  let importAssetZoom = Math.max(0.55, Math.min(1.5, Number(localStorage.getItem('canvasBridgeImportAssetZoom')) || 1));
  let kiviResultZoom = Math.max(0.55, Math.min(1.6, Number(localStorage.getItem('canvasBridgeKiviResultZoom')) || 1));
  let kiviTaskZoom = Math.max(0.65, Math.min(1.5, Number(localStorage.getItem('canvasBridgeKiviTaskZoom')) || 1));
  const suppressedConfirmActions = new Set();
  const importableExtensions = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.mov', '.webm']);

  function rawEvalScript(script) {
    return new Promise((resolve, reject) => {
      if (!window.__adobe_cep__) return reject(new Error('请在 After Effects CEP 面板中运行'));
      window.__adobe_cep__.evalScript(script, result => result === 'EvalScript error.' ? reject(new Error('AE 脚本执行失败')) : resolve(result));
    });
  }

  const hostScriptPath = path.join(extensionRoot, 'jsx', 'host.jsx').replace(/\\/g, '/');
  let hostScriptLoadPromise = null;

  async function ensureHostScriptLoaded(forceReload) {
    if (hostScriptLoadPromise && !forceReload) return hostScriptLoadPromise;
    const bootstrap = `var __cbHostStatus='';try{$.evalFile(new File(${quote(hostScriptPath)}));if(typeof CanvasBridge==='undefined'||typeof CanvasBridge.getSelectionInfo!=='function'){__cbHostStatus='__CB_HOST_ERROR__|CanvasBridge API 未注册|0';}else{__cbHostStatus='__CB_HOST_OK__';}}catch(e){__cbHostStatus='__CB_HOST_ERROR__|'+e.toString()+'|'+(e.line||0);}__cbHostStatus;`;
    hostScriptLoadPromise = rawEvalScript(bootstrap).then(raw => {
      const result = String(raw == null ? '' : raw).trim();
      if (result === '__CB_HOST_OK__') return true;
      if (result.indexOf('__CB_HOST_ERROR__|') === 0) {
        const parts = result.split('|');
        const line = Number(parts.pop()) || 0;
        const detail = parts.slice(1).join('|') || '未知错误';
        throw new Error(`AE 宿主脚本加载失败${line ? `（第 ${line} 行）` : ''}：${detail}`);
      }
      throw new Error(`AE 宿主脚本加载无响应：${result || 'AE 未返回数据'}`);
    }).catch(error => {
      hostScriptLoadPromise = null;
      throw error;
    });
    return hostScriptLoadPromise;
  }

  async function evalScript(script) {
    if (/^\s*CanvasBridge\./.test(String(script || ''))) await ensureHostScriptLoaded(false);
    return rawEvalScript(script);
  }

  function parseEvalJson(raw, actionName) {
    let text = String(raw == null ? '' : raw).replace(/^\uFEFF/, '').trim();
    if (!text) throw new Error(`${actionName || 'AE 脚本'}没有返回数据，请重启 AE 后重试`);
    if ((text[0] !== '{' && text[0] !== '[') || /;\s*[}\]]/.test(text)) {
      const startObject = text.indexOf('{');
      const startArray = text.indexOf('[');
      const start = startObject >= 0 && startArray >= 0 ? Math.min(startObject, startArray) : Math.max(startObject, startArray);
      const end = Math.max(text.lastIndexOf('}'), text.lastIndexOf(']'));
      if (start >= 0 && end > start) text = text.slice(start, end + 1);
    }
    try { return JSON.parse(text); } catch (error) {
      const preview = text.replace(/\s+/g, ' ').slice(0, 180);
      throw new Error(`${actionName || 'AE 脚本'}返回了非 JSON 数据：${preview || '(空)'}。已在新版中改用 Canvas Bridge 自带 JSON 编码器；请重新安装本次更新并完全重启 AE 2025。`);
    }
  }

  function quote(value) { return JSON.stringify(String(value)); }
  function ensureDirectory(directory) {
    if (fs.existsSync(directory)) return;
    const parent = path.dirname(directory);
    if (parent && parent !== directory) ensureDirectory(parent);
    try { fs.mkdirSync(directory); } catch (error) { if (!fs.existsSync(directory)) throw error; }
  }
  function directoryEntries(directory) {
    return fs.readdirSync(directory).map(name => {
      const fullPath = path.join(directory, name);
      const stat = fs.lstatSync(fullPath);
      return { name, isDirectory: () => stat.isDirectory(), isFile: () => stat.isFile() };
    });
  }
  function tempRoot() {
    const root = path.join(os.tmpdir(), 'ae-canvas-bridge');
    if (!fs.existsSync(root)) fs.mkdirSync(root);
    return root;
  }
  function previewArchiveRoot() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'preview-archive');
  }
  function tempPng(prefix) { return path.join(tempRoot(), `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}.png`); }
  function eagleStagingRoot() {
    const root = path.join(tempRoot(), 'eagle-staging');
    ensureDirectory(root);
    return root;
  }
  function cleanupEagleStaging() {
    const root = eagleStagingRoot();
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    try {
      for (const name of fs.readdirSync(root)) {
        const filePath = path.join(root, name);
        try { if (fs.statSync(filePath).mtimeMs < cutoff) safeUnlink(filePath); } catch (_) {}
      }
    } catch (_) {}
  }
  function fileUrl(filePath) { return encodeURI(`file:///${filePath.replace(/\\/g, '/')}`); }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
  function safeUnlink(filePath) { try { if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {} }
  function safeRename(source, target) { try { fs.renameSync(source, target); } catch (_) { fs.copyFileSync(source, target); safeUnlink(source); } }
  function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
  async function waitForStableFile(filePath, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let lastSize = -1;
    let stableChecks = 0;
    while (Date.now() < deadline) {
      try {
        const size = fs.statSync(filePath).size;
        if (size > 0 && size === lastSize) {
          stableChecks += 1;
          if (stableChecks >= 2) return;
        } else stableChecks = 0;
        lastSize = size;
      } catch (_) { stableChecks = 0; }
      await delay(150);
    }
    throw new Error('等待 AE 写入 PNG 超时');
  }

  function compareVersions(a, b) {
    const left = String(a || '0').replace(/^v/i, '').split('.').map(part => parseInt(part, 10) || 0);
    const right = String(b || '0').replace(/^v/i, '').split('.').map(part => parseInt(part, 10) || 0);
    for (let i = 0; i < Math.max(left.length, right.length); i += 1) {
      const diff = (left[i] || 0) - (right[i] || 0);
      if (diff) return diff;
    }
    return 0;
  }

  function updateTempRoot(version) {
    const root = path.join(tempRoot(), 'updates', String(version || 'latest'));
    ensureDirectory(root);
    return root;
  }

  function removeDirectory(directory) {
    if (!fs.existsSync(directory)) return;
    for (const entry of fs.readdirSync(directory)) {
      const fullPath = path.join(directory, entry);
      const stat = fs.lstatSync(fullPath);
      if (stat.isDirectory()) removeDirectory(fullPath);
      else fs.unlinkSync(fullPath);
    }
    fs.rmdirSync(directory);
  }

  function readUpdateConfig() {
    const defaults = {
      provider: 'githubRelease',
      owner: '',
      repo: 'ae-canvas-bridge',
      tokenEnv: 'AE_CANVAS_BRIDGE_GITHUB_TOKEN',
      assetPattern: 'AECanvasBridge-AE-.*\\.zip$'
    };
    const configPath = path.join(extensionRoot, 'updater-config.json');
    if (!fs.existsSync(configPath)) return defaults;
    return Object.assign(defaults, JSON.parse(fs.readFileSync(configPath, 'utf8')));
  }

  function updateAuthHeaders(config, accept) {
    const token = config.token || process.env[config.tokenEnv || 'AE_CANVAS_BRIDGE_GITHUB_TOKEN'] || process.env.GITHUB_TOKEN || process.env.GH_TOKEN || '';
    const headers = {
      'Accept': accept || 'application/vnd.github+json',
      'User-Agent': 'AE-Canvas-Bridge-Updater'
    };
    if (token) headers.Authorization = `Bearer ${token}`;
    return headers;
  }

  function requestBuffer(url, headers, redirectCount) {
    return new Promise((resolve, reject) => {
      const client = /^https:/i.test(url) ? https : http;
      const request = client.get(url, { headers: headers || {} }, response => {
        if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location && (redirectCount || 0) < 5) {
          response.resume();
          resolve(requestBuffer(new URL(response.headers.location, url).toString(), headers, (redirectCount || 0) + 1));
          return;
        }
        const chunks = [];
        response.on('data', chunk => chunks.push(chunk));
        response.on('end', () => {
          const body = Buffer.concat(chunks);
          if (response.statusCode < 200 || response.statusCode >= 300) {
            reject(new Error(`更新源请求失败：HTTP ${response.statusCode} ${body.toString('utf8').slice(0, 160)}`));
            return;
          }
          resolve(body);
        });
      });
      request.on('error', reject);
      request.setTimeout(30000, () => request.destroy(new Error('更新源请求超时')));
    });
  }

  async function requestJson(url, headers) {
    return JSON.parse((await requestBuffer(url, headers)).toString('utf8'));
  }

  function withCacheBust(url) {
    const separator = String(url).indexOf('?') >= 0 ? '&' : '?';
    return `${url}${separator}t=${Date.now()}`;
  }

  function normalizeManifest(manifest, config) {
    if (!manifest || !manifest.version || !manifest.package || !manifest.package.url) throw new Error('更新 manifest 缺少 version 或 package.url');
    return {
      version: String(manifest.version).replace(/^v/i, ''),
      notes: manifest.notes || manifest.body || '',
      fileName: manifest.package.fileName || `AECanvasBridge-AE-v${manifest.version}.zip`,
      downloadUrl: manifest.package.url,
      sha256: manifest.package.sha256 || '',
      size: manifest.package.size || 0,
      downloadHeaders: updateAuthHeaders(config, manifest.package.githubAsset ? 'application/octet-stream' : '*/*')
    };
  }

  async function resolveLatestUpdate() {
    const config = readUpdateConfig();
    if (config.manifestUrl) {
      const response = await requestJson(withCacheBust(config.manifestUrl), updateAuthHeaders(config));
      const manifest = response && response.encoding === 'base64' && response.content
        ? JSON.parse(Buffer.from(String(response.content).replace(/\s/g, ''), 'base64').toString('utf8'))
        : response;
      return normalizeManifest(manifest, config);
    }
    if (!config.owner || !config.repo) throw new Error('尚未配置私有 GitHub 仓库。请在 updater-config.json 填写 owner 和 repo。');
    const release = await requestJson(`https://api.github.com/repos/${config.owner}/${config.repo}/releases/latest`, updateAuthHeaders(config));
    const pattern = new RegExp(config.assetPattern || 'AECanvasBridge-AE-.*\\.zip$', 'i');
    const asset = (release.assets || []).find(item => pattern.test(item.name)) || (release.assets || []).find(item => /\.zip$/i.test(item.name));
    if (!asset) throw new Error('最新 GitHub Release 中没有找到 AE 插件 zip 资源');
    return {
      version: String(release.tag_name || release.name || '').replace(/^v/i, ''),
      notes: release.body || '',
      fileName: asset.name,
      downloadUrl: asset.url,
      sha256: '',
      size: asset.size || 0,
      downloadHeaders: updateAuthHeaders(config, 'application/octet-stream')
    };
  }

  function findExtensionPayload(directory, depth) {
    if (depth < 0) return null;
    if (fs.existsSync(path.join(directory, 'index.html')) && fs.existsSync(path.join(directory, 'CSXS', 'manifest.xml'))) return directory;
    for (const entry of directoryEntries(directory)) {
      if (!entry.isDirectory()) continue;
      const found = findExtensionPayload(path.join(directory, entry.name), depth - 1);
      if (found) return found;
    }
    return null;
  }

  function writeApplyUpdateScript(scriptPath) {
    const script = `param(
  [Parameter(Mandatory=$true)][string]$Source,
  [Parameter(Mandatory=$true)][string]$Target,
  [Parameter(Mandatory=$true)][string]$Marker,
  [string]$TaskName = ''
)
$ErrorActionPreference = 'Stop'
$Log = Join-Path (Split-Path -Parent $Marker) 'install.log'
$ErrorLog = Join-Path (Split-Path -Parent $Marker) 'install-error.txt'
function Write-InstallLog([string]$Message) {
  $line = '[' + (Get-Date).ToString('s') + '] ' + $Message
  Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}
try {
  Write-InstallLog 'installer-started'
  $sourcePath = (Resolve-Path -LiteralPath $Source).Path
  $targetPath = $Target
  if (!(Test-Path -LiteralPath $targetPath)) { New-Item -ItemType Directory -Path $targetPath -Force | Out-Null }
  $targetPath = (Resolve-Path -LiteralPath $targetPath).Path
  if (!(Test-Path -LiteralPath (Join-Path $sourcePath 'index.html'))) { throw 'Source is missing index.html: ' + $sourcePath }
  if (!(Test-Path -LiteralPath (Join-Path $sourcePath 'CSXS\\manifest.xml'))) { throw 'Source is missing CSXS\\manifest.xml: ' + $sourcePath }
  Write-InstallLog ('source=' + $sourcePath)
  Write-InstallLog ('target=' + $targetPath)
  while (Get-Process -Name AfterFX -ErrorAction SilentlyContinue) {
    Write-InstallLog 'waiting-afterfx'
    Start-Sleep -Seconds 2
  }
  for ($i = 0; $i -lt 20; $i += 1) {
    $cep = Get-CimInstance Win32_Process -Filter "name = 'CEPHtmlEngine.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -like '*com.local.aecanvasbridge.kivivideo.dev.panel*' -or $_.CommandLine -like '*AECanvasBridgeKiviVideoDev*' }
    if (!$cep) { break }
    Write-InstallLog 'waiting-cephtmlengine'
    Start-Sleep -Seconds 1
  }
  $robocopyLog = Join-Path (Split-Path -Parent $Marker) 'robocopy.log'
  & robocopy $sourcePath $targetPath /MIR /R:20 /W:1 /NFL /NDL /NP /LOG:$robocopyLog | Out-Null
  $exitCode = $LASTEXITCODE
  Write-InstallLog ('robocopy-exit=' + $exitCode)
  if ($exitCode -gt 7) { throw 'Robocopy failed with exit code ' + $exitCode + '. See ' + $robocopyLog }
  $packageJson = Join-Path $targetPath 'package.json'
  if (!(Test-Path -LiteralPath $packageJson)) { throw 'Installed package.json missing.' }
  Set-Content -LiteralPath $Marker -Value ("updated=" + (Get-Date).ToString("s")) -Encoding UTF8
  if (Test-Path -LiteralPath $ErrorLog) { Remove-Item -LiteralPath $ErrorLog -Force }
  Write-InstallLog 'installer-finished'
} catch {
  $message = $_.Exception.Message
  Write-InstallLog ('installer-error=' + $message)
  Set-Content -LiteralPath $ErrorLog -Value $message -Encoding UTF8
  throw
} finally {
  if ($TaskName) {
    try { schtasks.exe /Delete /TN $TaskName /F | Out-Null } catch {}
  }
}
`;
    fs.writeFileSync(scriptPath, script, 'utf8');
  }

  function quoteCmd(value) {
    return `"${String(value).replace(/"/g, '""')}"`;
  }

  function quoteVbsString(value) {
    return `"${String(value).replace(/"/g, '""')}"`;
  }

  function scheduleUpdateInstall(root, applyScript, payload, target, marker, version) {
    const taskName = `AECanvasBridgeKiviVideoDevUpdate-${String(version || 'latest').replace(/[^0-9A-Za-z_-]/g, '_')}-${Date.now()}`;
    const schedulerLog = path.join(root, 'scheduler.log');
    const runnerPath = path.join(root, 'run-update-hidden.vbs');
    const spawnLog = path.join(root, 'spawn.log');
    const powerShellArgs = [
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass',
      '-WindowStyle', 'Hidden',
      '-File', applyScript,
      '-Source', payload,
      '-Target', target,
      '-Marker', marker
    ];
    const installCommand = [
      'powershell.exe',
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass',
      '-WindowStyle', 'Hidden',
      '-File', quoteCmd(applyScript),
      '-Source', quoteCmd(payload),
      '-Target', quoteCmd(target),
      '-Marker', quoteCmd(marker),
      '-TaskName', quoteCmd(taskName)
    ].join(' ');
    const runner = [
      'Set shell = CreateObject("WScript.Shell")',
      'Set fso = CreateObject("Scripting.FileSystemObject")',
      `Set logFile = fso.OpenTextFile(${quoteVbsString(spawnLog)}, 8, True)`,
      'logFile.WriteLine Now & " launching hidden installer"',
      'logFile.Close',
      `shell.Run ${quoteVbsString(installCommand)}, 0, False`
    ].join('\r\n');
    fs.writeFileSync(runnerPath, runner, 'ascii');
    const taskAction = [
      'wscript.exe',
      quoteCmd(runnerPath)
    ].join(' ');
    fs.appendFileSync(schedulerLog, `[${new Date().toISOString()}] create ${taskName}\nrunner=${runnerPath}\naction=${taskAction}\n`, 'utf8');
    const runAt = new Date(Date.now() + 60 * 1000);
    const hh = String(runAt.getHours()).padStart(2, '0');
    const mm = String(runAt.getMinutes()).padStart(2, '0');
    try {
      childProcess.execFileSync('schtasks.exe', ['/Create', '/TN', taskName, '/SC', 'ONCE', '/ST', `${hh}:${mm}`, '/TR', taskAction, '/F'], { windowsHide: true });
      childProcess.execFileSync('schtasks.exe', ['/Run', '/TN', taskName], { windowsHide: true });
      fs.appendFileSync(schedulerLog, `[${new Date().toISOString()}] started ${taskName}\n`, 'utf8');
      return { method: 'taskScheduler', taskName, schedulerLog, runnerPath };
    } catch (error) {
      fs.appendFileSync(schedulerLog, `[${new Date().toISOString()}] task-scheduler-failed ${error.message}\n`, 'utf8');
      const fallbackArgs = powerShellArgs.concat(['-TaskName', '']);
      const child = childProcess.spawn('powershell.exe', fallbackArgs, {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      });
      child.unref();
      fs.appendFileSync(schedulerLog, `[${new Date().toISOString()}] started detached-powershell fallback\n`, 'utf8');
      return { method: 'detachedPowerShell', taskName: '', schedulerLog, runnerPath: '', fallback: true };
    }
  }

  function expandZip(zipPath, destinationPath) {
    const scriptPath = path.join(path.dirname(zipPath), 'expand-update.ps1');
    fs.writeFileSync(scriptPath, `param(
  [Parameter(Mandatory=$true)][string]$ZipPath,
  [Parameter(Mandatory=$true)][string]$DestinationPath
)
$ErrorActionPreference = 'Stop'
Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestinationPath -Force
`, 'utf8');
    childProcess.execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, '-ZipPath', zipPath, '-DestinationPath', destinationPath], { windowsHide: true });
  }

  function setUpdateUi(state, message, update) {
    if (!ui.updateStatus) return;
    ui.updateStatus.textContent = message;
    ui.currentAeVersion.textContent = CURRENT_AE_VERSION;
    ui.latestAeVersion.textContent = update && update.version ? update.version : '--';
    ui.updateBadge.textContent = state === 'ready' ? '可更新' : state === 'current' ? '已最新' : state === 'error' ? '异常' : '检查中';
    ui.updateBadge.className = `badge ${state === 'ready' ? 'ready' : state === 'error' ? 'error' : state === 'current' ? 'online' : 'offline'}`;
    ui.installUpdate.disabled = !(state === 'ready' && update);
    if (update && update.notes) ui.updateNotes.textContent = String(update.notes).slice(0, 500);
  }

  async function checkForUpdates(manual) {
    if (!ui.updateStatus) return;
    try {
      ui.checkUpdate.disabled = true;
      setUpdateUi('checking', '正在检查更新...', latestUpdate);
      const update = await resolveLatestUpdate();
      latestUpdate = update;
      if (compareVersions(update.version, CURRENT_AE_VERSION) > 0) setUpdateUi('ready', `发现新版本 v${update.version}，可以下载并准备安装。`, update);
      else setUpdateUi('current', `当前已是最新版本 v${CURRENT_AE_VERSION}。`, update);
    } catch (error) {
      latestUpdate = null;
      setUpdateUi('error', `${manual ? '检查更新失败' : '自动检查失败'}：${error.message}`, null);
    } finally {
      ui.checkUpdate.disabled = false;
    }
  }

  async function installLatestUpdate() {
    if (!latestUpdate) return;
    try {
      ui.installUpdate.disabled = true;
      ui.checkUpdate.disabled = true;
      setUpdateUi('checking', `正在下载 v${latestUpdate.version}...`, latestUpdate);
      const root = updateTempRoot(latestUpdate.version);
      const zipPath = path.join(root, latestUpdate.fileName || `AECanvasBridge-AE-v${latestUpdate.version}.zip`);
      const extractPath = path.join(root, 'extracted');
      const markerPath = path.join(root, 'installed-after-ae-close.txt');
      if (fs.existsSync(extractPath)) removeDirectory(extractPath);
      ensureDirectory(extractPath);
      const data = await requestBuffer(latestUpdate.downloadUrl, latestUpdate.downloadHeaders);
      fs.writeFileSync(zipPath, data);
      if (latestUpdate.sha256) {
        const actual = crypto.createHash('sha256').update(data).digest('hex').toLowerCase();
        if (actual !== String(latestUpdate.sha256).toLowerCase()) throw new Error('下载文件校验失败，已停止安装');
      }
      setUpdateUi('checking', '正在解压更新包...', latestUpdate);
      expandZip(zipPath, extractPath);
      const payload = findExtensionPayload(extractPath, 4);
      if (!payload) throw new Error('更新包中没有找到 AE CEP 插件内容');
      const applyScript = path.join(root, 'apply-update-after-ae-close.ps1');
      writeApplyUpdateScript(applyScript);
      const scheduled = scheduleUpdateInstall(root, applyScript, payload, extensionRoot, markerPath, latestUpdate.version);
      const installerMode = scheduled.method === 'detachedPowerShell'
        ? '计划任务被系统拒绝，已切换备用后台安装方式'
        : `Windows 任务计划程序会接管安装；任务：${scheduled.taskName}`;
      setUpdateUi('current', `v${latestUpdate.version} 已准备好。请完全退出 AE，${installerMode}；重新打开 AE 后生效。日志：${path.join(root, 'install.log')}`, latestUpdate);    } catch (error) {
      setUpdateUi('error', `安装准备失败：${error.message}`, latestUpdate);
    } finally {
      ui.checkUpdate.disabled = false;
    }
  }

  function pairingCode() {
    let code = localStorage.getItem('canvasBridgePairingCode');
    if (!/^\d{6}$/.test(code || '')) {
      code = String(100000 + (crypto.randomBytes(4).readUInt32BE(0) % 900000));
      localStorage.setItem('canvasBridgePairingCode', code);
    }
    return code;
  }

  const code = pairingCode();
  ui.code.textContent = code;

  function copyPairingCode() {
    try {
      if (window.nw && window.nw.Clipboard) window.nw.Clipboard.get().set(code, 'text');
      else if (typeof require === 'function') require('nw.gui').Clipboard.get().set(code, 'text');
      else throw new Error('clipboard unavailable');
      ui.copyCode.textContent = '已复制';
      setTimeout(() => { ui.copyCode.textContent = '复制'; }, 1200);
    } catch (_) {
      const input = document.createElement('textarea');
      input.value = code;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      input.remove();
      ui.copyCode.textContent = '已复制';
      setTimeout(() => { ui.copyCode.textContent = '复制'; }, 1200);
    }
  }
  ui.copyCode.addEventListener('click', copyPairingCode);
  ui.code.addEventListener('click', copyPairingCode);

  function setConnection(connected) {
    ui.badge.textContent = connected ? '已连接' : '未连接';
    ui.badge.className = `badge ${connected ? 'online' : 'offline'}`;
    updateButtons();
  }
  function setStatus(text, kind) {
    ui.status.textContent = text;
    ui.card.className = `card status-card${kind ? ` ${kind}` : ''}`;
  }
  function updateButtons() {
    if (ui.preview) ui.preview.disabled = busy || selectionItems.length === 0;
    if (ui.clearSelection) ui.clearSelection.disabled = busy || selectionItems.length === 0;
    ui.send.disabled = busy || !previewReady || !server.client;
    ui.localExport.disabled = busy || !previewReady;
    ui.eagleExport.disabled = busy || !previewReady;
    if (ui.queueKiviVideo) ui.queueKiviVideo.disabled = busy || !previewReady;
    if (ui.prepareKiviVideoAssets) ui.prepareKiviVideoAssets.disabled = busy || !previewReady;
    if (ui.generateDraftPrompts) {
      const eligible = kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt && deriveJobStatus(job) === 'draft' && !String(job.prompt || '').trim() && !['queued', 'analyzing'].includes(job.promptState && job.promptState.status)) : [];
      const activeSkill = agentSkillStore && agentSkillStore.getActive();
      ui.generateDraftPrompts.disabled = busy || !!(promptAgentRunner && promptAgentRunner.isRunning()) || !eligible.length || !activeSkill || !deepseekCredentialConfigured;
    }
    if (ui.cancelPromptBatch) ui.cancelPromptBatch.classList.toggle('hidden', !(promptAgentRunner && promptAgentRunner.isRunning()));
    if (ui.generateSelectedKiviJobs) {
      const selectedJobs = kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt && job.selected && deriveJobStatus(job) !== 'generating' && String(job.prompt || '').trim()) : [];
      ui.generateSelectedKiviJobs.disabled = busy || !selectedJobs.length;
    }
  }

  function switchModule(name) {
    const normalized = name === 'other' && !ui.otherModule ? 'version' : name;
    const selected = ['export', 'import', 'render', 'version', 'kivi-video', 'other'].includes(normalized) ? normalized : 'export';
    ui.exportModule.classList.toggle('hidden', selected !== 'export');
    ui.importModule.classList.toggle('hidden', selected !== 'import');
    if (ui.renderModule) ui.renderModule.classList.toggle('hidden', selected !== 'render');
    if (ui.versionModule) ui.versionModule.classList.toggle('hidden', selected !== 'version');
    if (ui.kiviVideoModule) ui.kiviVideoModule.classList.toggle('hidden', selected !== 'kivi-video');
    if (ui.otherModule) ui.otherModule.classList.toggle('hidden', selected !== 'other');
    ui.moduleTabs.forEach(button => button.classList.toggle('active', button.dataset.module === selected));
    localStorage.setItem('canvasBridgeKiviVideoDevActiveModule', selected);
    if (selected === 'import') refreshImportDirectoryLabel();
    if (selected === 'kivi-video') {
      ensureKiviWorkspace()
        .then(() => refreshKiviVideoModels())
        .catch(error => setKiviVideoStatus(error.message, 'error'));
    }
  }

  function resetSelectionState(message) {
    clearPreviews();
    selectionItems = [];
    selectionKey = '';
    previewReady = false;
    ui.selectionSummary.textContent = message || '尚未载入素材';
    ui.selectionList.innerHTML = '';
    ui.previewSection.classList.add('hidden');
    ui.batchProgress.textContent = '';
    ui.bar.style.width = '0%';
    updateButtons();
  }

  function updatePreviewZoom() {
    if (!ui.previewSection || !ui.previewZoom) return;
    const value = Math.max(40, Math.min(160, Number(ui.previewZoom.value) || 100));
    ui.previewSection.style.setProperty('--preview-scale', String(value / 100));
    if (ui.previewZoomValue) ui.previewZoomValue.textContent = `${value}%`;
    renderAllPreviews();
  }

  function zoomPreviewWithWheel(event) {
    if (!event.ctrlKey || !ui.previewZoom || ui.previewSection.classList.contains('hidden')) return;
    event.preventDefault();
    const direction = event.deltaY > 0 ? -1 : 1;
    const next = Math.max(Number(ui.previewZoom.min), Math.min(Number(ui.previewZoom.max), Number(ui.previewZoom.value) + direction * 5));
    ui.previewZoom.value = String(next);
    updatePreviewZoom();
  }

  function applyImportAssetZoom() {
    const card = ui.importHistory && ui.importHistory.closest('.import-history-card');
    if (card) card.style.setProperty('--import-scale', String(importAssetZoom));
    if (ui.importZoomValue) ui.importZoomValue.textContent = `${Math.round(importAssetZoom * 100)}%`;
    localStorage.setItem('canvasBridgeImportAssetZoom', String(importAssetZoom));
  }

  function zoomImportAssetsWithWheel(event) {
    if (!event.ctrlKey || !ui.importHistory) return;
    event.preventDefault();
    importAssetZoom = Math.max(0.55, Math.min(1.5, importAssetZoom + (event.deltaY > 0 ? -0.1 : 0.1)));
    applyImportAssetZoom();
  }

  function applyKiviResultZoom() {
    if (!ui.kiviJobDetail) return;
    const results = ui.kiviJobDetail.querySelector('.kivi-results');
    const value = ui.kiviJobDetail.querySelector('#kiviResultZoomValue');
    if (results) results.style.setProperty('--kivi-result-scale', String(kiviResultZoom));
    if (value) value.textContent = `${Math.round(kiviResultZoom * 100)}%`;
    localStorage.setItem('canvasBridgeKiviResultZoom', String(kiviResultZoom));
  }

  function zoomKiviResultsWithWheel(event) {
    if (!event.ctrlKey || !event.target.closest('.kivi-results')) return;
    event.preventDefault();
    kiviResultZoom = Math.max(0.55, Math.min(1.6, kiviResultZoom + (event.deltaY > 0 ? -0.1 : 0.1)));
    applyKiviResultZoom();
  }

  function applyKiviTaskZoom() {
    if (ui.kiviJobList) ui.kiviJobList.style.setProperty('--kivi-task-scale', String(kiviTaskZoom));
    if (ui.kiviTaskZoomValue) ui.kiviTaskZoomValue.textContent = `${Math.round(kiviTaskZoom * 100)}%`;
    localStorage.setItem('canvasBridgeKiviTaskZoom', String(kiviTaskZoom));
  }

  function zoomKiviTasksWithWheel(event) {
    if (!event.ctrlKey || !ui.kiviJobList) return;
    event.preventDefault();
    kiviTaskZoom = Math.max(0.65, Math.min(1.5, kiviTaskZoom + (event.deltaY > 0 ? -0.1 : 0.1)));
    applyKiviTaskZoom();
  }

  function applyStoredHeight(target, storageKey, defaultHeight, minimum, maximum) {
    if (!target) return;
    const stored = Number(localStorage.getItem(storageKey));
    const height = Math.max(minimum, Math.min(maximum, stored || defaultHeight));
    target.style.height = `${height}px`;
  }

  function bindVerticalResizer(handle, target, storageKey, defaultHeight, minimum, maximum) {
    if (!handle || !target) return;
    applyStoredHeight(target, storageKey, defaultHeight, minimum, maximum);
    handle.onmousedown = event => {
      const startY = event.clientY;
      const startHeight = target.getBoundingClientRect().height;
      const move = moveEvent => {
        const height = Math.max(minimum, Math.min(maximum, startHeight + moveEvent.clientY - startY));
        target.style.height = `${height}px`;
        localStorage.setItem(storageKey, String(Math.round(height)));
      };
      const stop = () => {
        window.removeEventListener('mousemove', move);
        window.removeEventListener('mouseup', stop);
        document.body.classList.remove('resizing-vertical');
      };
      document.body.classList.add('resizing-vertical');
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', stop);
      event.preventDefault();
    };
  }

  function sanitizeFileName(value) {
    const safe = String(value || 'image').replace(/[<>:\"/\\|?*\x00-\x1F]/g, '_').replace(/[. ]+$/g, '').trim();
    return safe || 'image';
  }

  function uniquePath(directory, fileName) {
    const parsed = path.parse(fileName);
    let candidate = path.join(directory, fileName);
    let index = 2;
    while (fs.existsSync(candidate)) {
      candidate = path.join(directory, `${parsed.name} (${index})${parsed.ext}`);
      index += 1;
    }
    return candidate;
  }

  async function defaultExportDirectory() {
    const raw = await evalScript('CanvasBridge.getProjectDirectory()');
    const result = parseEvalJson(raw, '读取 AE 工程目录');
    if (!result.ok) throw new Error(result.error);
    return path.join(result.path, 'Canvas Bridge 导出');
  }

  async function currentProjectContext() {
    const raw = await evalScript('CanvasBridge.getProjectContext()');
    const result = parseEvalJson(raw, '读取 AE 工程信息');
    if (!result.ok) throw new Error(result.error);
    return result;
  }

  function workspaceLinkKey(projectDirectory, projectName) {
    const normalizedName = String(projectName || '').replace(/\.aep$/i, '').replace(/[\s_-]*auto[- ]?save[\s_-]*\d*$/i, '').toLowerCase();
    return `canvasBridgeKiviWorkspace:${KiviWorkspaceRecovery.projectFamilyRoot(projectDirectory).toLowerCase()}:${normalizedName}`;
  }

  async function resolveProjectStorage(selectedPath) {
    const context = await currentProjectContext();
    const linkKey = workspaceLinkKey(context.path, context.projectName);
    const savedRoot = localStorage.getItem(linkKey) || '';
    const resolved = KiviWorkspaceRecovery.resolveProjectRoot({
      projectDirectory: context.path,
      savedRoot,
      selectedPath
    });
    if (selectedPath) localStorage.setItem(linkKey, resolved.projectRoot);
    return Object.assign({ context }, resolved);
  }

  async function defaultImportDirectory() {
    const resolved = await resolveProjectStorage();
    return path.join(resolved.projectRoot, KiviWorkspaceRecovery.IMPORT_DIRECTORY);
  }

  function importHistoryKey() { return 'canvasBridgeKiviImportHistory'; }
  function loadImportHistory() {
    try { importHistory = JSON.parse(localStorage.getItem(importHistoryKey()) || '[]'); }
    catch (_) { importHistory = []; }
    if (!Array.isArray(importHistory)) importHistory = [];
    renderImportHistory();
  }
  function saveImportHistory() {
    importHistory = importHistory.slice(0, 80);
    localStorage.setItem(importHistoryKey(), JSON.stringify(importHistory));
    renderImportHistory();
  }
  function nodeTypeFromFile(filePath) {
    return ['.mp4', '.mov', '.webm'].includes(path.extname(filePath || '').toLowerCase()) ? 'video' : 'image';
  }
  function mimeFromFile(filePath) {
    const ext = path.extname(filePath || '').toLowerCase();
    const map = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm' };
    return map[ext] || (nodeTypeFromFile(filePath) === 'video' ? 'video/mp4' : 'image/png');
  }
  function upsertImportHistory(item) {
    const key = String(item.localPath || '').toLowerCase();
    const existing = importHistory.findIndex(candidate => String(candidate.localPath || '').toLowerCase() === key);
    if (existing >= 0) importHistory[existing] = Object.assign({}, importHistory[existing], item, { rating: importHistory[existing].rating || item.rating || 0 });
    else importHistory.unshift(item);
  }

  function restoreAcceptedHistoryFromJobs() {
    if (!kiviStore) return 0;
    let restored = 0;
    for (const job of kiviStore.state.jobs || []) {
      for (const run of job.runs || []) {
        for (const candidate of run.candidates || []) {
          const localPath = candidate.acceptedPath && fs.existsSync(candidate.acceptedPath) ? candidate.acceptedPath : '';
          if (!localPath) continue;
          const stat = fs.statSync(localPath);
          upsertImportHistory({
            localPath,
            fileName: path.basename(localPath),
            displayName: path.basename(localPath),
            mimeType: 'video/mp4',
            nodeType: 'video',
            format: 'video',
            folderName: 'Kivi Videos',
            byteSize: stat.size,
            at: stat.mtimeMs || Date.now(),
            importedAt: stat.mtimeMs || Date.now(),
            taskId: String(run.taskId || ''),
            kiviJobId: job.id,
            kiviJobName: job.name,
            kiviCandidateId: candidate.id,
            kiviCandidateLabel: `候选 C${String(Number(candidate.sequence) || 0).padStart(3, '0')}`,
            origin: job.origin ? JSON.parse(JSON.stringify(job.origin)) : null
          });
          restored += 1;
        }
      }
    }
    return restored;
  }
  function scanFiles(root) {
    const result = [];
    if (!fs.existsSync(root)) return result;
    const stack = [root];
    while (stack.length) {
      const current = stack.pop();
      let entries = [];
      try { entries = directoryEntries(current); } catch (_) { continue; }
      for (const entry of entries) {
        const full = path.join(current, entry.name);
        if (entry.isDirectory() && entry.name !== '_KIVI任务工作区') stack.push(full);
        else if (entry.isFile() && importableExtensions.has(path.extname(entry.name).toLowerCase())) result.push(full);
      }
    }
    return result;
  }
  function assetExtension(item) {
    const ext = path.extname(item.fileName || item.localPath || '').replace('.', '').toLowerCase();
    if (ext === 'jpeg') return 'jpg';
    return ext || (String(item.mimeType || '').split('/')[1] || '').toLowerCase();
  }
  function assetRatioStyle(item, exists) {
    if (!exists) return '';
    const width = Number(item.width) || Number(item.metaWidth) || 0;
    const height = Number(item.height) || Number(item.metaHeight) || 0;
    if (width > 0 && height > 0) return ` style="--asset-ratio:${width}/${height}"`;
    return '';
  }
  function setItemRating(index, rating) {
    if (!importHistory[index]) return;
    importHistory[index].rating = Math.max(0, Math.min(5, Number(rating) || 0));
    saveImportHistory();
  }
  function importDisplayName(item) {
    return item.displayName || item.fileName || path.basename(item.localPath || '') || 'asset';
  }
  function updateImportDimensions(index, width, height, previewElement) {
    width = Math.round(Number(width) || 0);
    height = Math.round(Number(height) || 0);
    if (!(width > 0 && height > 0) || !importHistory[index]) return;
    if (previewElement) previewElement.style.setProperty('--asset-ratio', `${width}/${height}`);
    if (Number(importHistory[index].width) === width && Number(importHistory[index].height) === height) return;
    importHistory[index].width = width;
    importHistory[index].height = height;
    localStorage.setItem(importHistoryKey(), JSON.stringify(importHistory.slice(0, 80)));
  }
  async function renameImportAsset(index, nextName) {
    const item = importHistory[index];
    if (!item) return;
    const previousName = importDisplayName(item);
    const currentExtension = path.extname(item.fileName || item.localPath || '');
    let fileName = sanitizeFileName(nextName || previousName);
    if (currentExtension && path.extname(fileName).toLowerCase() !== currentExtension.toLowerCase()) {
      fileName = sanitizeFileName(fileName.replace(/\.[^.]+$/, '')) + currentExtension;
    }
    if (!fileName || fileName === previousName) {
      renderImportHistory();
      return;
    }
    try {
      item.fileName = fileName;
      item.displayName = fileName;
      if (item.aeItemId) {
        const raw = await evalScript(`CanvasBridge.renameProjectItem(${Number(item.aeItemId)},${quote(fileName)})`);
        const result = parseEvalJson(raw, '重命名 AE 素材');
        if (!result.ok) throw new Error(result.error);
        if (result.itemName) item.fileName = result.itemName;
      }
      saveImportHistory();
      setImportStatus(`已重命名：${item.fileName}`, 'success');
    } catch (error) {
      setImportStatus(`重命名失败：${error.message}`, 'error');
      renderImportHistory();
    }
  }
  function matchesImportFilters(item) {
    const format = ui.importFormatFilter ? ui.importFormatFilter.value : 'all';
    const ratingFilter = ui.importRatingFilter ? ui.importRatingFilter.value : 'all';
    const ext = assetExtension(item);
    const rating = Number(item.rating) || 0;
    if (format !== 'all' && ext !== format) return false;
    if (ratingFilter === '0') return rating === 0;
    if (ratingFilter !== 'all' && rating < Number(ratingFilter)) return false;
    return true;
  }
  function visibleImportAssets() {
    const sortMode = ui.importSortMode ? ui.importSortMode.value : 'recent';
    const items = importHistory.map((item, originalIndex) => Object.assign({ originalIndex }, item)).filter(matchesImportFilters);
    items.sort((a, b) => {
      if (sortMode === 'name') return String(a.fileName || '').localeCompare(String(b.fileName || ''), 'zh-Hans-CN') || ((b.at || 0) - (a.at || 0));
      if (sortMode === 'type') return String(a.nodeType || '').localeCompare(String(b.nodeType || '')) || String(a.fileName || '').localeCompare(String(b.fileName || ''), 'zh-Hans-CN');
      return (b.at || 0) - (a.at || 0);
    });
    return items;
  }
  function openInExplorer(filePath) {
    try { require('child_process').execFile('explorer.exe', ['/select,', filePath]); }
    catch (error) { setImportStatus(`无法打开资源管理器：${error.message}`, 'error'); }
  }
  function confirmPanelAction(title, message, confirmLabel, options) {
    const settings = options || {};
    const suppressionKey = settings.suppressionKey || '';
    if (suppressionKey && suppressedConfirmActions.has(suppressionKey)) return Promise.resolve(true);
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.className = 'panel-confirm-overlay';
      overlay.innerHTML = `<div class="panel-confirm" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}">
        <div class="panel-confirm-title">${escapeHtml(title)}</div>
        <div class="panel-confirm-message">${escapeHtml(message)}</div>
        <div class="panel-confirm-warning">${escapeHtml(settings.warningText || '此操作不可恢复')}</div>
        ${settings.allowSuppress ? '<label class="panel-confirm-suppress"><input type="checkbox" data-confirm-suppress>本次启动不再提醒</label>' : ''}
        <div class="panel-confirm-actions"><button data-confirm-cancel>取消</button><button class="panel-confirm-danger" data-confirm-accept>${escapeHtml(confirmLabel || '永久删除')}</button></div>
      </div>`;
      const finish = value => {
        document.removeEventListener('keydown', onKeyDown);
        overlay.remove();
        resolve(value);
      };
      const onKeyDown = event => { if (event.key === 'Escape') finish(false); };
      overlay.addEventListener('click', event => { if (event.target === overlay) finish(false); });
      overlay.querySelector('[data-confirm-cancel]').addEventListener('click', () => finish(false));
      overlay.querySelector('[data-confirm-accept]').addEventListener('click', () => {
        const suppress = overlay.querySelector('[data-confirm-suppress]');
        if (suppressionKey && suppress && suppress.checked) suppressedConfirmActions.add(suppressionKey);
        finish(true);
      });
      document.addEventListener('keydown', onKeyDown);
      document.body.appendChild(overlay);
      overlay.querySelector('[data-confirm-cancel]').focus();
    });
  }

  function showPanelContextMenu(event, actions) {
    event.preventDefault();
    document.querySelectorAll('.panel-context-menu').forEach(menu => menu.remove());
    const available = (actions || []).filter(action => action && !action.hidden);
    if (!available.length) return;
    const menu = document.createElement('div');
    menu.className = 'panel-context-menu';
    menu.setAttribute('role', 'menu');
    menu.innerHTML = available.map((action, index) => `<button role="menuitem" data-context-action="${index}"${action.disabled ? ' disabled' : ''}>${escapeHtml(action.label)}</button>`).join('');
    document.body.appendChild(menu);
    const close = () => {
      document.removeEventListener('mousedown', onOutside, true);
      document.removeEventListener('keydown', onKeyDown, true);
      menu.remove();
    };
    const onOutside = outsideEvent => { if (!menu.contains(outsideEvent.target)) close(); };
    const onKeyDown = keyEvent => { if (keyEvent.key === 'Escape') close(); };
    menu.querySelectorAll('[data-context-action]').forEach(button => button.addEventListener('click', () => {
      const action = available[Number(button.dataset.contextAction)];
      close();
      if (action && !action.disabled) Promise.resolve(action.run()).catch(error => setKiviVideoStatus(error.message, 'error'));
    }));
    const rect = menu.getBoundingClientRect();
    menu.style.left = `${Math.max(6, Math.min(event.clientX, window.innerWidth - rect.width - 6))}px`;
    menu.style.top = `${Math.max(6, Math.min(event.clientY, window.innerHeight - rect.height - 6))}px`;
    setTimeout(() => {
      document.addEventListener('mousedown', onOutside, true);
      document.addEventListener('keydown', onKeyDown, true);
    }, 0);
    const first = menu.querySelector('button:not([disabled])');
    if (first) first.focus();
  }

  function identityName(value) {
    return String(value || '')
      .replace(/\.[a-z0-9]{2,5}$/i, '')
      .replace(/^(KIVI_|CB_KIVI_|原始对照_|原始素材_)/i, '')
      .replace(/[\s_\-\u2013\u2014\[\]()（）【】]+/g, '')
      .replace(/(副本|方案|comp\d*)$/i, '')
      .toLowerCase();
  }

  function identityNamesSimilar(left, right) {
    const a = identityName(left);
    const b = identityName(right);
    return !!a && !!b && (a === b || (Math.min(a.length, b.length) >= 4 && (a.includes(b) || b.includes(a))));
  }

  function stableRecoveryId(prefix, value) {
    return `${prefix}-${crypto.createHash('sha1').update(String(value || prefix)).digest('hex').slice(0, 16)}`;
  }

  function mediaCornerBackground(filePath) {
    return new Promise(resolve => {
      const video = document.createElement('video');
      const canvas = document.createElement('canvas');
      let settled = false;
      const finish = value => {
        if (settled) return;
        settled = true;
        video.removeAttribute('src');
        resolve(value || '#00FF00');
      };
      const timer = window.setTimeout(() => finish('#00FF00'), 3500);
      video.muted = true;
      video.preload = 'auto';
      video.addEventListener('error', () => { window.clearTimeout(timer); finish('#00FF00'); }, { once: true });
      video.addEventListener('loadeddata', () => {
        try {
          const width = Math.max(2, Math.min(96, Number(video.videoWidth) || 2));
          const height = Math.max(2, Math.min(96, Number(video.videoHeight) || 2));
          canvas.width = width;
          canvas.height = height;
          const context = canvas.getContext('2d', { willReadFrequently: true });
          context.drawImage(video, 0, 0, width, height);
          const points = [[1, 1], [width - 2, 1], [1, height - 2], [width - 2, height - 2]];
          const totals = [0, 0, 0];
          points.forEach(point => {
            const pixel = context.getImageData(point[0], point[1], 1, 1).data;
            totals[0] += pixel[0]; totals[1] += pixel[1]; totals[2] += pixel[2];
          });
          const hex = totals.map(total => Math.round(total / points.length).toString(16).padStart(2, '0')).join('').toUpperCase();
          window.clearTimeout(timer);
          finish(`#${hex}`);
        } catch (_) {
          window.clearTimeout(timer);
          finish('#00FF00');
        }
      }, { once: true });
      video.src = fileUrl(filePath);
      video.load();
    });
  }

  function originFromSelectionItem(item, exportInfo) {
    return {
      projectPath: item.projectPath || '',
      comp: item.comp || null,
      layer: item.layer || null,
      source: {
        itemId: Number(item.sourceItemId || 0),
        kind: item.kind || 'image',
        name: item.sourceName || item.name || '',
        layerName: item.layerName || item.layer && item.layer.name || item.name || '',
        width: Number(item.width) || 0,
        height: Number(item.height) || 0
      },
      export: Object.assign({
        width: Number(item.width) || 1000,
        height: Number(item.height) || 1000,
        x: 0.5,
        y: 0.5,
        scaleMultiplier: 1,
        fitRatio: 0.8,
        rotation: 0,
        backgroundMode: 'custom',
        backgroundHex: '#00FF00'
      }, exportInfo || {})
    };
  }

  function normalizeBridgeOrigin(value) {
    if (!value || typeof value !== 'object') return null;
    let serialized = '';
    try { serialized = JSON.stringify(value); } catch (_) { return null; }
    if (!serialized || serialized.length > 65536) return null;
    const number = input => Number.isFinite(Number(input)) ? Number(input) : 0;
    const text = (input, limit) => String(input == null ? '' : input).slice(0, limit || 1000);
    const point = input => Array.isArray(input) ? input.slice(0, 3).map(number) : null;
    const comp = value.comp && typeof value.comp === 'object' ? {
      id: number(value.comp.id), name: text(value.comp.name, 260), width: number(value.comp.width), height: number(value.comp.height), time: number(value.comp.time)
    } : null;
    const layerValue = value.layer && typeof value.layer === 'object' ? value.layer : null;
    const transformValue = layerValue && layerValue.transform && typeof layerValue.transform === 'object' ? layerValue.transform : null;
    const layer = layerValue ? {
      id: number(layerValue.id), index: number(layerValue.index), name: text(layerValue.name, 260), sourceItemId: number(layerValue.sourceItemId),
      sourceName: text(layerValue.sourceName, 260), sourceWidth: number(layerValue.sourceWidth), sourceHeight: number(layerValue.sourceHeight),
      compId: number(layerValue.compId), compName: text(layerValue.compName, 260), compTime: number(layerValue.compTime),
      inPoint: number(layerValue.inPoint), outPoint: number(layerValue.outPoint), startTime: number(layerValue.startTime), stretch: number(layerValue.stretch),
      parentLayerId: number(layerValue.parentLayerId), threeDLayer: !!layerValue.threeDLayer,
      transform: transformValue ? {
        anchorPoint: point(transformValue.anchorPoint), position: point(transformValue.position), scale: point(transformValue.scale),
        rotation: number(transformValue.rotation), opacity: number(transformValue.opacity)
      } : null
    } : null;
    const sourceValue = value.source && typeof value.source === 'object' ? value.source : {};
    const exportValue = value.export && typeof value.export === 'object' ? value.export : {};
    const projectPath = text(value.projectPath, 1000);
    if (!projectPath || !comp || !layer) return null;
    return {
      projectPath,
      comp,
      layer,
      source: {
        itemId: number(sourceValue.itemId), kind: text(sourceValue.kind, 40), name: text(sourceValue.name, 260),
        layerName: text(sourceValue.layerName, 260), width: number(sourceValue.width), height: number(sourceValue.height)
      },
      export: {
        width: number(exportValue.width), height: number(exportValue.height), x: number(exportValue.x), y: number(exportValue.y),
        scaleMultiplier: number(exportValue.scaleMultiplier), fitRatio: number(exportValue.fitRatio), rotation: number(exportValue.rotation),
        backgroundMode: text(exportValue.backgroundMode, 40), backgroundHex: text(exportValue.backgroundHex, 16)
      }
    };
  }

  async function selectedOriginForRecovery(job, filePath) {
    const raw = await evalScript('CanvasBridge.getSelectionInfo()');
    const selection = parseEvalJson(raw, '读取时间线目标图层');
    if (!selection.ok) throw new Error(selection.error);
    const items = selection.items || [];
    if (!items.length) throw new Error('请在原始合成时间线上选中目标图层');
    let selected = items[0];
    if (items.length > 1) {
      const references = [job && job.name, job && job.source && job.source.layerName, job && job.source && job.source.sourceName, job && job.source && path.parse(job.source.path || '').name].filter(Boolean);
      const ranked = items.map(item => ({ item, score: references.reduce((score, name) => score + (identityName(name) === identityName(item.name) ? 4 : identityNamesSimilar(name, item.name) || identityNamesSimilar(name, item.sourceName) ? 2 : 0), 0) }));
      ranked.sort((left, right) => right.score - left.score);
      if (!ranked[0].score || ranked[1] && ranked[1].score === ranked[0].score) throw new Error('当前选中了多个图层，无法唯一判断目标；请只保留一个目标图层选中');
      selected = ranked[0].item;
    }
    const backgroundHex = await mediaCornerBackground(filePath);
    const source = job && job.source || {};
    return originFromSelectionItem(selected, {
      width: Number(source.width) || 1000,
      height: Number(source.height) || 1000,
      backgroundHex
    });
  }

  function persistRecoveredOrigin(job, origin) {
    if (!job || !origin) return;
    job.origin = JSON.parse(JSON.stringify(origin));
    job.source = job.source || {};
    const layerName = origin.layer && origin.layer.name || origin.source && origin.source.layerName || '';
    if (layerName) {
      const oldLayerName = job.source.layerName;
      job.source.layerName = layerName;
      const genericNames = [oldLayerName, job.source.sourceName, job.origin.source && job.origin.source.name, path.parse(job.source.path || '').name].filter(Boolean);
      if (!job.name || genericNames.some(name => identityName(name) === identityName(job.name))) job.name = layerName;
    }
    job.updatedAt = Date.now();
  }

  async function addImportedKiviToOrigin(item, manualSelection, button) {
    if (!item || !item.localPath) return;
    button.disabled = true;
    try {
      const linkedJob = kiviStore && item.kiviJobId ? kiviStore.findJob(item.kiviJobId) : null;
      let origin = item.origin || linkedJob && linkedJob.origin || null;
      if (!origin && manualSelection) origin = await selectedOriginForRecovery(linkedJob || { name: item.kiviJobName || path.parse(item.fileName || '').name, source: { path: item.localPath } }, item.localPath);
      if (!origin) throw new Error('旧素材没有原始来源记录；请在时间线上选中目标图层后使用“手动替换原始”');
      const payload = {
        jobId: item.kiviJobId || stableRecoveryId('manual-job', item.localPath),
        jobName: item.kiviJobName || path.parse(item.fileName || '').name,
        candidateId: item.kiviCandidateId || stableRecoveryId('manual-candidate', item.localPath),
        candidateLabel: item.kiviCandidateLabel || path.parse(item.fileName || '').name,
        filePath: item.localPath,
        origin,
        manualSelection: !!manualSelection,
        loopDuration: kiviAdoptionDuration
      };
      const method = manualSelection ? 'addKiviCandidateToSelectedLayer' : 'addKiviCandidateToOrigin';
      const raw = await evalScript(`CanvasBridge.${method}(${quote(JSON.stringify(payload))})`);
      const result = parseEvalJson(raw, manualSelection ? '手动替换原始' : '加入原始合成');
      if (!result.ok) throw new Error(result.error);
      item.aeItemId = result.footageItemId || item.aeItemId;
      item.originCompId = result.compId;
      item.originCompName = result.compName;
      item.originLayerName = result.layerName;
      item.addedToOriginAt = Date.now();
      if (result.origin) {
        item.origin = result.origin;
        if (linkedJob) {
          persistRecoveredOrigin(linkedJob, result.origin);
          kiviStore.save();
        }
      }
      saveImportHistory();
      setImportStatus(`${result.reused ? '已切换' : '已加入'}${manualSelection ? '所选图层' : '原始合成'}：${item.fileName}`, 'success');
    } catch (error) {
      setImportStatus(`${manualSelection ? '手动替换' : '加入原始合成'}失败：${error.message}`, 'error');
    } finally {
      button.disabled = false;
    }
  }

  function kiviLoopDurationLabel() {
    return `${kiviAdoptionDuration}S 循环`;
  }

  function stopLoopPreview(button) {
    if (!button) return;
    button.classList.remove('active');
    button.textContent = kiviLoopDurationLabel();
    const container = button.closest('.import-preview, .kivi-candidate');
    const video = container && container.querySelector('video');
    if (!video) return;
    video.dataset.looping = 'false';
    video.pause();
    video.loop = false;
    video.playbackRate = 1;
    try { video.currentTime = 0; } catch (_) {}
  }

  function setKiviAdoptionDuration(value, announce) {
    kiviAdoptionDuration = Number(value) === 3 ? 3 : 2;
    if (ui.kiviLoopDuration) {
      ui.kiviLoopDuration.querySelectorAll('[data-loop-duration]').forEach(button => {
        const active = Number(button.dataset.loopDuration) === kiviAdoptionDuration;
        button.classList.toggle('active', active);
        button.setAttribute('aria-pressed', String(active));
      });
    }
    document.querySelectorAll('[data-import-loop], [data-kivi-loop]').forEach(stopLoopPreview);
    if (announce !== false) setImportStatus(`加入原始合成将按 ${kiviAdoptionDuration} 秒循环创建`, 'success');
  }

  function renderImportHistory() {
    if (!ui.importHistory) return;
    ui.importCount.textContent = `${importHistory.length} 项`;
    if (!importHistory.length) {
      ui.importHistory.innerHTML = '<div class="muted">暂无导入记录</div>';
      if (ui.batchImportEagle) ui.batchImportEagle.disabled = true;
      if (ui.batchExportLocal) ui.batchExportLocal.disabled = true;
      return;
    }
    const layoutMode = ui.importLayoutMode ? ui.importLayoutMode.value : 'masonry';
    ui.importHistory.className = `import-history layout-${layoutMode}`;
    const viewItems = visibleImportAssets();
    if (ui.batchImportEagle) ui.batchImportEagle.disabled = importBatchBusy || !viewItems.some(item => fs.existsSync(item.localPath || ''));
    if (ui.batchExportLocal) ui.batchExportLocal.disabled = importBatchBusy || !viewItems.some(item => fs.existsSync(item.localPath || ''));
    if (!viewItems.length) {
      ui.importHistory.innerHTML = '<div class="muted">没有符合筛选条件的素材</div>';
      return;
    }
    ui.importHistory.innerHTML = viewItems.map(item => {
      const isImage = /^image\//.test(item.mimeType || '') || item.nodeType === 'image';
      const isVideo = /^video\//.test(item.mimeType || '') || item.nodeType === 'video';
      const exists = fs.existsSync(item.localPath || '');
      const rating = Number(item.rating) || 0;
      const displayName = importDisplayName(item);
      const submeta = `${item.nodeType || 'asset'} · ${item.folderName || ''} · ${new Date(item.at || Date.now()).toLocaleString()}`;
      const stars = [1, 2, 3, 4, 5].map(value => `<button class="star-button ${rating >= value ? 'active' : ''}" data-rate-import="${item.originalIndex}" data-rating="${value}" title="${value} 星">★</button>`).join('');
      const preview = isImage && exists
        ? `<img src="${fileUrl(item.localPath)}" title="${escapeHtml(displayName)}" draggable="true" data-drag-file="${escapeHtml(item.localPath)}" data-measure-import="${item.originalIndex}">`
        : isVideo && exists
        ? `<video src="${fileUrl(item.localPath)}" preload="metadata" muted title="${escapeHtml(displayName)}" draggable="true" data-drag-file="${escapeHtml(item.localPath)}" data-measure-import="${item.originalIndex}"></video><span class="video-badge">VIDEO</span><button class="import-loop-overlay" data-import-loop="${item.originalIndex}">${kiviLoopDurationLabel()}</button>`
        : 'FILE';
      const canAddToOrigin = isVideo && !!(item.origin && item.origin.projectPath);
      const canManualReplace = isVideo && exists;
      const originButton = isVideo ? `<div class="import-origin-actions"><button data-add-origin="${item.originalIndex}"${canAddToOrigin ? '' : ' disabled title="旧素材没有原始图层信息，请先使用手动替换恢复"'}>加入原始合成</button><button data-add-origin-manual="${item.originalIndex}"${canManualReplace ? '' : ' disabled'}>手动替换原始</button></div>` : '';
      return `<article class="import-item" data-import-item="${item.originalIndex}" draggable="true" data-drag-file="${escapeHtml(item.localPath || '')}">
        <div class="import-preview"${assetRatioStyle(item, exists)}>${preview}</div>
        <div class="import-meta">
          <input class="import-name-input" data-rename-import="${item.originalIndex}" value="${escapeHtml(displayName)}" title="重命名素材">
          <div class="import-submeta">${escapeHtml(submeta)}</div>
          <div class="rating-row">${stars}<button class="star-button" data-rate-import="${item.originalIndex}" data-rating="0" title="取消评分">×</button></div>
          <div class="import-actions">${originButton}<button data-add-comp="${item.originalIndex}" class="wide">加入当前合成</button><button data-reveal-import="${item.originalIndex}">资源管理器</button><button data-remove-import="${item.originalIndex}">移除</button></div>
        </div>
      </article>`;
    }).join('');
    ui.importHistory.querySelectorAll('[data-rename-import]').forEach(input => {
      input.addEventListener('click', event => event.stopPropagation());
      input.addEventListener('dragstart', event => event.preventDefault());
      input.addEventListener('keydown', event => {
        if (event.key === 'Enter') input.blur();
        if (event.key === 'Escape') {
          const item = importHistory[Number(input.dataset.renameImport)];
          input.value = item ? importDisplayName(item) : input.value;
          input.blur();
        }
      });
      input.addEventListener('change', () => renameImportAsset(Number(input.dataset.renameImport), input.value));
    });
    ui.importHistory.querySelectorAll('[data-reveal-import]').forEach(button => button.addEventListener('click', () => {
      const item = importHistory[Number(button.dataset.revealImport)];
      if (item && item.localPath) openInExplorer(item.localPath);
    }));
    ui.importHistory.querySelectorAll('[data-add-comp]').forEach(button => button.addEventListener('click', async () => {
      const item = importHistory[Number(button.dataset.addComp)];
      if (!item || !item.localPath) return;
      try {
        const raw = await evalScript(`CanvasBridge.addAssetToActiveComp(${quote(item.localPath)},${quote(item.nodeType || nodeTypeFromFile(item.localPath))},${quote(item.folderName || '')})`);
        const result = parseEvalJson(raw, '加入当前合成');
        if (!result.ok) throw new Error(result.error);
        setImportStatus(`已加入当前合成：${item.fileName}`, 'success');
      } catch (error) { setImportStatus(error.message, 'error'); }
    }));
    ui.importHistory.querySelectorAll('[data-add-origin]').forEach(button => button.addEventListener('click', () => {
      addImportedKiviToOrigin(importHistory[Number(button.dataset.addOrigin)], false, button);
    }));
    ui.importHistory.querySelectorAll('[data-add-origin-manual]').forEach(button => button.addEventListener('click', () => {
      addImportedKiviToOrigin(importHistory[Number(button.dataset.addOriginManual)], true, button);
    }));
    ui.importHistory.querySelectorAll('[data-import-loop]').forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      const preview = button.closest('.import-preview');
      const video = preview && preview.querySelector('video');
      if (!video) return;
      const active = button.classList.toggle('active');
      ui.importHistory.querySelectorAll('[data-import-loop].active').forEach(other => {
        if (other === button) return;
        stopLoopPreview(other);
      });
      const playLoop = () => {
        if (!Number.isFinite(video.duration) || video.duration <= 0) return;
        video.dataset.looping = 'true';
        video.playbackRate = Math.max(0.25, Math.min(16, video.duration / kiviAdoptionDuration));
        video.loop = true;
        video.currentTime = 0;
        button.textContent = '停止循环';
        video.play().catch(() => {});
      };
      if (!active) {
        video.dataset.looping = 'false';
        video.pause();
        video.loop = false;
        video.playbackRate = 1;
        button.textContent = kiviLoopDurationLabel();
      } else if (video.readyState >= 1) playLoop();
      else video.addEventListener('loadedmetadata', playLoop, { once: true });
    }));
    ui.importHistory.querySelectorAll('[data-remove-import]').forEach(button => button.addEventListener('click', () => {
      importHistory.splice(Number(button.dataset.removeImport), 1);
      saveImportHistory();
    }));
    ui.importHistory.querySelectorAll('[data-rate-import]').forEach(button => button.addEventListener('click', () => {
      setItemRating(Number(button.dataset.rateImport), Number(button.dataset.rating));
    }));
    ui.importHistory.querySelectorAll('[data-import-item]').forEach(element => element.addEventListener('click', () => {
      ui.importHistory.querySelectorAll('.import-item.selected').forEach(item => item.classList.remove('selected'));
      element.classList.add('selected');
    }));
    ui.importHistory.querySelectorAll('[data-drag-file]').forEach(element => element.addEventListener('dragstart', event => {
      const filePath = element.dataset.dragFile;
      event.dataTransfer.effectAllowed = 'copy';
      event.dataTransfer.setData('text/plain', filePath);
      event.dataTransfer.setData('text/uri-list', fileUrl(filePath));
      event.dataTransfer.setData('DownloadURL', `${mimeFromFile(filePath)}:${path.basename(filePath)}:${fileUrl(filePath)}`);
    }));
    ui.importHistory.querySelectorAll('img[data-measure-import]').forEach(image => {
      const applySize = () => updateImportDimensions(Number(image.dataset.measureImport), image.naturalWidth, image.naturalHeight, image.closest('.import-preview'));
      if (image.complete) applySize();
      else image.addEventListener('load', applySize, { once: true });
    });
    ui.importHistory.querySelectorAll('video').forEach(video => {
      video.muted = !(ui.importVideoSound && ui.importVideoSound.checked);
      let hoverScrubbing = false;
      video.addEventListener('loadedmetadata', () => {
        updateImportDimensions(Number(video.dataset.measureImport), video.videoWidth, video.videoHeight, video.closest('.import-preview'));
      }, { once: true });
      video.addEventListener('mousemove', event => {
        if (video.dataset.looping === 'true') return;
        if (!Number.isFinite(video.duration) || video.duration <= 0) return;
        hoverScrubbing = true;
        const rect = video.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
        video.currentTime = ratio * video.duration;
        window.clearTimeout(video._canvasBridgePlayTimer);
        video._canvasBridgePlayTimer = window.setTimeout(() => {
          hoverScrubbing = false;
          video.play().catch(() => {});
        }, 320);
      });
      video.addEventListener('mouseenter', () => { video.muted = !(ui.importVideoSound && ui.importVideoSound.checked); });
      video.addEventListener('mouseleave', () => { window.clearTimeout(video._canvasBridgePlayTimer); if (video.dataset.looping !== 'true') video.pause(); hoverScrubbing = false; });
    });
  }
  function setImportStatus(text, kind) {
    if (!ui.importStatus) return;
    ui.importStatus.textContent = text;
    ui.importStatus.style.color = kind === 'error' ? '#ffb4ab' : kind === 'success' ? '#8ce99a' : '';
  }
  async function refreshImportDirectoryLabel() {
    try {
      const directory = await defaultImportDirectory();
      ui.importDirectory.textContent = `${directory}\\Kivi Images / Kivi Videos`;
    } catch (error) {
      ui.importDirectory.textContent = error.message;
    }
  }

  async function handleKiviImportAsset(meta, tempPath) {
    const root = await defaultImportDirectory();
    const nodeType = meta.nodeType === 'video' || /^video\//.test(meta.mimeType || '') ? 'video' : 'image';
    const child = path.join(root, nodeType === 'video' ? 'Kivi Videos' : 'Kivi Images');
    ensureDirectory(child);
    const target = uniquePath(child, sanitizeFileName(meta.fileName || (nodeType === 'video' ? 'kivi-video.mp4' : 'kivi-image.png')));
    safeRename(tempPath, target);
    const displayName = String(meta.displayName || meta.fileName || '').replace(/\.[A-Za-z0-9]{2,5}$/, '').trim();
    const raw = await evalScript(`CanvasBridge.importKiviAsset(${quote(target)},${quote(nodeType)},${quote(displayName)})`);
    const result = parseEvalJson(raw, '导入 Kivi 素材到 AE');
    if (!result.ok) throw new Error(result.error);
    const item = {
      transferId: meta.transferId,
      batchId: meta.batchId,
      nodeId: meta.nodeId,
      nodeType,
      fileName: path.basename(target),
      mimeType: meta.mimeType || '',
      byteSize: Number(meta.byteSize) || 0,
      localPath: target,
      aeItemName: result.itemName,
      aeItemId: result.itemId,
      folderName: result.folderName,
      width: meta.width || 0,
      height: meta.height || 0,
      duration: meta.duration || 0,
      origin: normalizeBridgeOrigin(meta.origin || meta.bridgeOrigin),
      originSourceNodeId: String(meta.originSourceNodeId || ''),
      rating: 0,
      at: Date.now()
    };
    importHistory.unshift(item);
    saveImportHistory();
    setImportStatus(`已导入：${item.fileName}`, 'success');
    return { localPath: target, aeItemName: result.itemName, aeItemId: result.itemId };
  }

  async function importKnownFileToAe(filePath, folderName) {
    const nodeType = nodeTypeFromFile(filePath);
    const raw = await evalScript(`CanvasBridge.importBridgeAsset(${quote(filePath)},${quote(nodeType)},${quote(folderName || (nodeType === 'video' ? 'Kivi Videos' : 'Kivi Images'))})`);
    const result = parseEvalJson(raw, '导入素材到 AE');
    if (!result.ok) throw new Error(result.error);
    return result;
  }

  async function reloadImportAssets() {
    try {
      const root = await defaultImportDirectory();
      const files = scanFiles(root);
      for (const filePath of files) {
        const stat = fs.statSync(filePath);
        const nodeType = nodeTypeFromFile(filePath);
        const folderName = filePath.indexOf(`${path.sep}外部 导入素材${path.sep}`) >= 0 ? '外部 导入素材' : nodeType === 'video' ? 'Kivi Videos' : 'Kivi Images';
        upsertImportHistory({
          transferId: '',
          batchId: '',
          nodeId: '',
          nodeType,
          fileName: path.basename(filePath),
          mimeType: mimeFromFile(filePath),
          byteSize: stat.size,
          localPath: filePath,
          aeItemName: path.basename(filePath),
          aeItemId: 0,
          folderName,
          rating: 0,
          at: stat.mtimeMs || Date.now()
        });
      }
      restoreAcceptedHistoryFromJobs();
      saveImportHistory();
      setImportStatus(`已重新加载 ${files.length} 个资源`, 'success');
    } catch (error) { setImportStatus(error.message, 'error'); }
  }

  async function importExternalAssets() {
    try {
      if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) throw new Error('当前 CEP 环境不支持文件选择器');
      const root = await defaultImportDirectory();
      const targetDir = path.join(root, '外部 导入素材');
      ensureDirectory(targetDir);
      const result = window.cep.fs.showOpenDialog(true, false, '选择要导入 Canvas Bridge 的外部素材', undefined, ['png', 'jpg', 'jpeg', 'webp', 'gif', 'mp4', 'mov', 'webm']);
      if (!result || result.err !== 0 || !result.data || !result.data.length) return;
      let imported = 0;
      for (const source of result.data) {
        const ext = path.extname(source).toLowerCase();
        if (!importableExtensions.has(ext)) continue;
        const target = uniquePath(targetDir, path.basename(source));
        fs.copyFileSync(source, target);
        const nodeType = nodeTypeFromFile(target);
        const aeResult = await importKnownFileToAe(target, '外部 导入素材');
        const stat = fs.statSync(target);
        upsertImportHistory({
          transferId: '',
          batchId: '',
          nodeId: '',
          nodeType,
          fileName: path.basename(target),
          mimeType: mimeFromFile(target),
          byteSize: stat.size,
          localPath: target,
          aeItemName: aeResult.itemName,
          aeItemId: aeResult.itemId,
          folderName: aeResult.folderName || '外部 导入素材',
          rating: 0,
          at: Date.now()
        });
        imported += 1;
      }
      saveImportHistory();
      setImportStatus(`已导入 ${imported} 个外部素材`, 'success');
    } catch (error) { setImportStatus(error.message, 'error'); }
  }

  async function selectedExportDirectory() {
    const customPath = ui.exportPath.value.trim();
    const directory = customPath || await defaultExportDirectory();
    ensureDirectory(directory);
    if (!fs.statSync(directory).isDirectory()) throw new Error('选择的导出路径不是文件夹');
    return directory;
  }

  async function chooseExportDirectory() {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) {
      setStatus('当前 CEP 环境不支持目录选择器', 'error');
      return;
    }
    let initialPath = ui.exportPath.value.trim();
    if (!initialPath) {
      try { initialPath = await defaultExportDirectory(); } catch (_) { initialPath = ''; }
    }
    const result = window.cep.fs.showOpenDialog(false, true, '选择 Canvas Bridge 导出目录', initialPath || undefined);
    if (result && result.err === 0 && result.data && result.data[0]) {
      ui.exportPath.value = result.data[0];
      localStorage.setItem('canvasBridgeExportPath', result.data[0]);
    }
  }

  function eagleAddFromPath(filePath, asset) {
    return new Promise((resolve, reject) => {
      const payload = JSON.stringify({
        path: filePath,
        name: path.parse(asset.fileName).name,
        tags: ['AE', 'Canvas Bridge'],
        annotation: `由 Canvas Bridge 从 After Effects 导入，${asset.width}×${asset.height}`
      });
      const request = http.request({
        hostname: '127.0.0.1', port: 41595, path: '/api/item/addFromPath', method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) }, timeout: 15000
      }, response => {
        let body = '';
        response.setEncoding('utf8');
        response.on('data', chunk => { body += chunk; });
        response.on('end', () => {
          let data = null;
          try { data = body ? JSON.parse(body) : null; } catch (_) {}
          if (response.statusCode >= 200 && response.statusCode < 300 && (!data || data.status !== 'error')) resolve(data);
          else reject(new Error(`Eagle 导入失败：${data && (data.message || data.error) ? data.message || data.error : `HTTP ${response.statusCode}`}`));
        });
      });
      request.on('timeout', () => request.destroy(new Error('Eagle 响应超时')));
      request.on('error', error => reject(new Error(`无法连接 Eagle，请确认 Eagle 已启动：${error.message}`)));
      request.write(payload);
      request.end();
    });
  }

  const server = new BridgeServer({
    pairingCode: code,
    tempRoot: tempRoot(),
    onState: state => { setConnection(state.connected); if (!busy) setStatus(state.message); },
    onProgress: p => {
      ui.progress.classList.remove('hidden');
      ui.bar.style.width = `${Math.min(100, Math.round(p.sent / p.total * 100))}%`;
    },
    onImportProgress: p => {
      if (!ui.importProgress) return;
      ui.importProgress.classList.remove('hidden');
      const total = Number(p.total) || 0;
      const percent = total ? Math.min(100, Math.round((Number(p.received) || 0) / total * 100)) : (p.phase === 'done' ? 100 : 8);
      ui.importBar.style.width = `${percent}%`;
      if (p.phase === 'start') setImportStatus(`正在接收：${p.meta && p.meta.fileName ? p.meta.fileName : 'Kivi 素材'}`);
      if (p.phase === 'done') setTimeout(() => ui.importProgress.classList.add('hidden'), 1200);
    },
    onImportAsset: handleKiviImportAsset
  });

  function clearPreviews() {
    for (const source of previewSources.values()) safeUnlink(source.path);
    previewSources.clear();
    layouts.clear();
    itemOptions.clear();
    ui.previewGrid.innerHTML = '';
    ui.previewSection.classList.add('hidden');
    previewReady = false;
    updateButtons();
  }

  function previewArchiveEntries() {
    return previewArchiveStore.list();
  }

  function updatePreviewArchiveUi() {
    const count = previewArchiveEntries().length;
    if (ui.previewArchiveCount) ui.previewArchiveCount.textContent = count;
    if (ui.previewActiveTab) {
      ui.previewActiveTab.classList.toggle('active', previewView === 'active');
      ui.previewActiveTab.setAttribute('aria-selected', String(previewView === 'active'));
    }
    if (ui.previewArchiveTab) {
      ui.previewArchiveTab.classList.toggle('active', previewView === 'archive');
      ui.previewArchiveTab.setAttribute('aria-selected', String(previewView === 'archive'));
    }
    if (ui.previewArchiveActions) ui.previewArchiveActions.classList.toggle('hidden', previewView !== 'archive');
    if (ui.restoreAllPreviewArchive) ui.restoreAllPreviewArchive.disabled = !count || busy;
    if (ui.deleteAllPreviewArchive) ui.deleteAllPreviewArchive.disabled = !count || busy;
    if (ui.previewZoom) ui.previewZoom.closest('.preview-zoom').classList.toggle('hidden', previewView === 'archive');
    if (ui.previewSection) ui.previewSection.classList.toggle('hidden', !previewSources.size && !count);
  }

  function renderPreviewArchive() {
    const entries = previewArchiveEntries();
    ui.previewGrid.innerHTML = entries.length ? entries.map(entry => `
      <article class="preview-card preview-archive-card">
        <div class="preview-title"><strong title="${escapeHtml(entry.item.name || entry.option.name || '未命名素材')}">${escapeHtml(entry.item.name || entry.option.name || '未命名素材')}</strong><small>${Number(entry.source.width) || '?'}×${Number(entry.source.height) || '?'}</small></div>
        <div class="canvas-wrap"><img src="${fileUrl(entry.source.path)}" alt="${escapeHtml(entry.item.name || '草稿箱素材')}"></div>
        <div class="preview-archive-meta"><span>已移入草稿箱</span><time>${new Date(entry.archivedAt).toLocaleString()}</time></div>
        <button class="secondary" data-preview-restore="${escapeHtml(entry.id)}">恢复到当前预览</button>
      </article>`).join('') : '<div class="preview-archive-empty">草稿箱为空。清空或移除的预览会保留在这里。</div>';
    ui.previewGrid.querySelectorAll('[data-preview-restore]').forEach(button => button.addEventListener('click', () => restorePreviewEntries([button.dataset.previewRestore])));
    updatePreviewArchiveUi();
  }

  function renderPreviewWorkspace() {
    if (previewView === 'archive') renderPreviewArchive();
    else if (previewSources.size) {
      createPreviewCards();
      renderAllPreviews();
      updatePreviewArchiveUi();
    } else {
      ui.previewGrid.innerHTML = previewArchiveEntries().length ? '<div class="preview-archive-empty">当前预览为空，可切换到草稿箱恢复素材。</div>' : '';
      updatePreviewArchiveUi();
    }
  }

  function switchPreviewView(view) {
    previewView = view === 'archive' ? 'archive' : 'active';
    localStorage.setItem('canvasBridgePreviewView', previewView);
    renderPreviewWorkspace();
  }

  function activePreviewRecords(items) {
    return (items || selectionItems).map(item => ({
      item,
      layout: layouts.get(item.id) || defaultPreviewLayout(),
      option: itemOptions.get(item.id) || defaultItemOption(item),
      source: previewSources.get(item.id)
    })).filter(record => record.source && record.source.path);
  }

  function removeActivePreviewIds(ids) {
    const selected = new Set((ids || []).map(String));
    for (const item of selectionItems) {
      if (!selected.has(String(item.id))) continue;
      const source = previewSources.get(item.id);
      if (source) safeUnlink(source.path);
      previewSources.delete(item.id);
      layouts.delete(item.id);
      itemOptions.delete(item.id);
    }
    selectionItems = selectionItems.filter(item => !selected.has(String(item.id)));
    selectionKey = selectionItems.map(item => item.id).join(',');
    previewReady = previewSources.size > 0;
    ui.selectionSummary.textContent = selectionItems.length ? `当前预览保留 ${selectionItems.length} 项` : '当前预览为空，可从草稿箱恢复';
    updateButtons();
  }

  function archiveActivePreviews(items) {
    const records = activePreviewRecords(items);
    if (!records.length) return 0;
    const archived = previewArchiveStore.archive(records);
    removeActivePreviewIds(records.map(record => record.item.id));
    updatePreviewArchiveUi();
    return archived.length;
  }

  async function restorePreviewEntries(ids) {
    if (busy) return;
    const selected = new Set((ids || []).map(String));
    const entries = previewArchiveEntries().filter(entry => selected.has(String(entry.id)));
    if (!entries.length) return;
    busy = true;
    updateButtons();
    let restored = 0;
    let skipped = 0;
    try {
      for (const entry of entries) {
        if (selectionItems.some(item => String(item.id) === String(entry.item.id))) { skipped += 1; continue; }
        const targetPath = tempPng(`restored-${entry.item.id || 'preview'}`);
        fs.copyFileSync(entry.source.path, targetPath);
        const image = new Image();
        await new Promise((resolve, reject) => {
          image.onload = resolve;
          image.onerror = () => reject(new Error(`无法恢复“${entry.item.name || '素材'}”的预览图`));
          image.src = fileUrl(targetPath);
        });
        selectionItems.push(entry.item);
        layouts.set(entry.item.id, Object.assign(defaultPreviewLayout(), entry.layout || {}));
        itemOptions.set(entry.item.id, Object.assign(defaultItemOption(entry.item), entry.option || {}));
        previewSources.set(entry.item.id, { path: targetPath, width: entry.source.width, height: entry.source.height, image });
        previewArchiveStore.remove(entry.id);
        restored += 1;
      }
      selectionKey = selectionItems.map(item => item.id).join(',');
      previewReady = previewSources.size > 0;
      ui.selectionSummary.textContent = `当前预览保留 ${selectionItems.length} 项`;
      switchPreviewView('active');
      setStatus(`已恢复 ${restored} 项预览${skipped ? `，${skipped} 项因当前预览中已存在而跳过` : ''}`, restored ? 'success' : 'error');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy = false; updateButtons(); updatePreviewArchiveUi(); }
  }

  async function clearPreviewPanelToArchive() {
    const records = activePreviewRecords();
    if (!records.length) return;
    const confirmed = await confirmPanelAction('清空预览面板', `将 ${records.length} 项预览移入草稿箱，为下一批任务腾出空间。排版、命名和预览图都会保留，可随时恢复。`, '移入草稿箱', { warningText: '这些预览不会被永久删除' });
    if (!confirmed) return;
    const count = archiveActivePreviews(selectionItems.slice());
    switchPreviewView('archive');
    setStatus(`已将 ${count} 项预览移入草稿箱`, 'success');
  }

  async function deleteAllPreviewArchive() {
    const entries = previewArchiveEntries();
    if (!entries.length) return;
    const confirmed = await confirmPanelAction('永久删除预览草稿', `将永久删除草稿箱中的 ${entries.length} 项预览及其排版信息，此操作不可恢复。已加入 KIVI 任务、素材库或 AE 项目的内容不会受影响。`, '永久删除');
    if (!confirmed) return;
    previewArchiveStore.remove(entries.map(entry => entry.id));
    renderPreviewArchive();
    setStatus(`已永久删除 ${entries.length} 项预览草稿`, 'success');
  }

  async function loadSelection(autoPreview) {
    if (busy) return;
    busy = true; updateButtons();
    let shouldGenerate = false;
    try {
      await ensureHostScriptLoaded(true);
      const raw = await evalScript('CanvasBridge.getSelectionInfo()');
      const info = parseEvalJson(raw, '读取 AE 所选素材');
      if (!info.ok) throw new Error(info.error);
      const nextKey = info.items.map(item => item.id).join(',');
      if (nextKey !== selectionKey && previewSources.size) archiveActivePreviews(selectionItems.slice());
      selectionKey = nextKey;
      selectionItems = info.items;
      previewView = 'active';
      localStorage.setItem('canvasBridgePreviewView', previewView);
      const sourceLabel = info.selectionSource === 'timeline' ? '时间线图层' : '项目面板';
      ui.selectionSummary.textContent = `批次已载入 ${selectionItems.length} 项 · 来源：${sourceLabel}`;
      ui.selectionList.innerHTML = selectionItems.map((item, index) =>
        `<div class="selection-item"><span>${index + 1}. ${escapeHtml(item.name)}</span><small>${item.kind === 'comp' ? '合成' : '图片'} · ${item.width}×${item.height}</small></div>`
      ).join('');
      shouldGenerate = !!autoPreview;
    } catch (error) {
      if (selectionKey) clearPreviews();
      selectionKey = '';
      selectionItems = [];
      ui.selectionSummary.textContent = '尚未载入素材';
      ui.selectionList.innerHTML = `<div class="muted">${escapeHtml(error.message)}</div>`;
      setStatus(error.message, 'error');
      renderPreviewWorkspace();
    }
    busy = false;
    updateButtons();
    if (shouldGenerate) await generatePreviews();
  }

  function sourceItemSize(item) {
    const width = Math.round(Number(item && item.width));
    const height = Math.round(Number(item && item.height));
    if (!(width >= 1 && width <= 8192 && height >= 1 && height <= 8192)) throw new Error('素材原始尺寸无效或超出 8192 像素');
    return { width, height };
  }
  function chooseLocalDirectory(title, initialPath) {
    if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) throw new Error('当前 CEP 环境不支持目录选择器');
    const result = window.cep.fs.showOpenDialog(false, true, title, initialPath || undefined);
    if (!result || result.err !== 0 || !result.data || !result.data[0]) return '';
    return result.data[0];
  }
  async function runImportBatch(mode) {
    if (importBatchBusy) return;
    const items = visibleImportAssets().filter(item => item.localPath && fs.existsSync(item.localPath));
    if (!items.length) {
      setImportStatus('当前筛选结果没有可用素材', 'error');
      return;
    }
    let directory = '';
    if (mode === 'local') {
      directory = chooseLocalDirectory('选择素材库导出目录', localStorage.getItem('canvasBridgeImportBatchExportPath') || '');
      if (!directory) return;
      ensureDirectory(directory);
      localStorage.setItem('canvasBridgeImportBatchExportPath', directory);
    }
    importBatchBusy = true;
    renderImportHistory();
    ui.importProgress.classList.remove('hidden');
    ui.importBar.style.width = '0%';
    const failures = [];
    let completed = 0;
    try {
      for (let index = 0; index < items.length; index += 1) {
        const item = items[index];
        try {
          if (mode === 'eagle') await eagleAddFromPath(item.localPath, Object.assign({ fileName: path.basename(item.localPath) }, item));
          else fs.copyFileSync(item.localPath, uniquePath(directory, sanitizeFileName(item.fileName || path.basename(item.localPath))));
          completed += 1;
        } catch (error) { failures.push(`${path.basename(item.localPath)}：${error.message}`); }
        ui.importBar.style.width = `${Math.round((index + 1) / items.length * 100)}%`;
        setImportStatus(`${mode === 'eagle' ? '导入 Eagle' : '导出本地'} ${index + 1}/${items.length}`);
      }
      const suffix = failures.length ? `，${failures.length} 项失败` : '';
      setImportStatus(`${mode === 'eagle' ? '已导入 Eagle' : `已导出至 ${directory}`}：${completed} 项${suffix}`, failures.length ? 'error' : 'success');
    } finally {
      importBatchBusy = false;
      window.setTimeout(() => ui.importProgress.classList.add('hidden'), 900);
      renderImportHistory();
    }
  }

  function outputSize(item) {
    if (selectedSize === 'original') return sourceItemSize(item);
    if (selectedSize !== 'custom') return { width: Number(selectedSize), height: Number(selectedSize) };
    const width = Math.round(Number(ui.customWidth.value));
    const height = Math.round(Number(ui.customHeight.value));
    if (!(width >= 64 && width <= 8192 && height >= 64 && height <= 8192)) throw new Error('自定义尺寸必须在 64–8192 像素之间');
    return { width, height };
  }

  function defaultItemOption(item) {
    const size = outputSize(item);
    return {
      name: path.parse(item.name).name,
      sizeMode: selectedSize,
      width: size.width,
      height: size.height,
      originalSize: selectedSize === 'original',
      backgroundMode: ui.backgroundMode.value,
      customColor: ui.customColorText.value.trim().toUpperCase()
    };
  }

  function itemSize(itemId) {
    const option = itemOptions.get(itemId);
    const item = selectionItems.find(candidate => String(candidate.id) === String(itemId));
    if (!option) return outputSize(item);
    const original = option.sizeMode === 'original' ? sourceItemSize(item) : null;
    const width = original ? original.width : option.sizeMode === 'custom' ? Math.round(Number(option.width)) : Number(option.sizeMode);
    const height = original ? original.height : option.sizeMode === 'custom' ? Math.round(Number(option.height)) : Number(option.sizeMode);
    if (!(width >= 64 && width <= 8192 && height >= 64 && height <= 8192)) throw new Error('单张图片的自定义尺寸必须在 64–8192 像素之间');
    return { width, height };
  }

  function itemBackground(itemId) {
    const option = itemOptions.get(itemId);
    if (!option) return backgroundColor();
    if (option.backgroundMode === 'transparent') return '';
    if (option.backgroundMode !== 'custom') return option.backgroundMode;
    const value = String(option.customColor || '').trim().toUpperCase();
    if (!/^#[0-9A-F]{6}$/.test(value)) throw new Error('单张图片的自定义背景色无效');
    return value;
  }

  function itemFitRatio(itemId) {
    const option = itemOptions.get(itemId);
    return option && (option.originalSize || option.sizeMode === 'original') ? 1 : 0.8;
  }

  function applyGlobalSettingsToAll() {
    if (!previewReady) return;
    for (const item of selectionItems) {
      const option = itemOptions.get(item.id);
      if (!option) continue;
      const size = outputSize(item);
      option.sizeMode = selectedSize;
      option.width = size.width;
      option.height = size.height;
      option.originalSize = selectedSize === 'original';
      option.backgroundMode = ui.backgroundMode.value;
      option.customColor = ui.customColorText.value.trim().toUpperCase();
    }
    createPreviewCards();
    renderAllPreviews();
  }

  function backgroundColor() {
    const mode = ui.backgroundMode.value;
    if (mode === 'transparent') return '';
    if (mode !== 'custom') return mode;
    const value = ui.customColorText.value.trim().toUpperCase();
    if (!/^#[0-9A-F]{6}$/.test(value)) throw new Error('请输入有效的颜色，例如 #00FF00');
    return value;
  }

  function drawCheckerboard(ctx, width, height) {
    const size = 16;
    for (let y = 0; y < height; y += size) for (let x = 0; x < width; x += size) {
      ctx.fillStyle = ((x / size + y / size) % 2) ? '#34363a' : '#4a4c50';
      ctx.fillRect(x, y, size, size);
    }
  }

  function previewCanvasSize(size) {
    const factor = Math.min(600 / size.width, 600 / size.height, 1);
    return { width: Math.max(1, Math.round(size.width * factor)), height: Math.max(1, Math.round(size.height * factor)) };
  }

  function renderPreview(itemId) {
    const source = previewSources.get(itemId);
    const layout = layouts.get(itemId);
    const canvas = document.querySelector(`canvas[data-item-id="${itemId}"]`);
    if (!source || !layout || !canvas || !source.image.complete) return;
    const size = itemSize(itemId);
    const previewSize = previewCanvasSize(size);
    canvas.width = previewSize.width;
    canvas.height = previewSize.height;
    canvas.style.aspectRatio = `${size.width} / ${size.height}`;
    const ctx = canvas.getContext('2d');
    const bg = itemBackground(itemId);
    if (bg) { ctx.fillStyle = bg; ctx.fillRect(0, 0, canvas.width, canvas.height); }
    else drawCheckerboard(ctx, canvas.width, canvas.height);
    const fit = Math.min(canvas.width / source.width, canvas.height / source.height) * itemFitRatio(itemId) * layout.scale;
    const drawWidth = source.width * fit;
    const drawHeight = source.height * fit;
    ctx.drawImage(source.image, layout.x * canvas.width - drawWidth / 2, layout.y * canvas.height - drawHeight / 2, drawWidth, drawHeight);
    const scaleLabel = document.querySelector(`[data-scale-label="${itemId}"]`);
    if (scaleLabel) scaleLabel.textContent = `${Math.round(layout.scale * 100)}%`;
    const scaleNumber = document.querySelector(`[data-scale-number="${itemId}"]`);
    if (scaleNumber && document.activeElement !== scaleNumber) scaleNumber.value = Math.round(layout.scale * 100);
    const sizeLabel = document.querySelector(`[data-size-label="${itemId}"]`);
    if (sizeLabel) sizeLabel.textContent = `${size.width}×${size.height}`;
  }

  function renderAllPreviews() {
    if (!previewReady) return;
    try { for (const item of selectionItems) renderPreview(item.id); }
    catch (error) { setStatus(error.message, 'error'); }
  }

  function bindPreviewCard(item) {
    const canvas = document.querySelector(`canvas[data-item-id="${item.id}"]`);
    const scaleInput = document.querySelector(`[data-scale="${item.id}"]`);
    const scaleNumber = document.querySelector(`[data-scale-number="${item.id}"]`);
    const reset = document.querySelector(`[data-reset="${item.id}"]`);
    const nameInput = document.querySelector(`[data-name="${item.id}"]`);
    const sizeMode = document.querySelector(`[data-size-mode="${item.id}"]`);
    const originalSizeButton = document.querySelector(`[data-original-size="${item.id}"]`);
    const widthInput = document.querySelector(`[data-width="${item.id}"]`);
    const heightInput = document.querySelector(`[data-height="${item.id}"]`);
    const customSizeRow = document.querySelector(`[data-custom-size="${item.id}"]`);
    const backgroundMode = document.querySelector(`[data-background="${item.id}"]`);
    const colorInput = document.querySelector(`[data-color="${item.id}"]`);
    const deleteButton = document.querySelector(`[data-delete="${item.id}"]`);
    let dragging = false;
    let dragStart = null;
    function setFromPointer(event) {
      const rect = canvas.getBoundingClientRect();
      const layout = layouts.get(item.id);
      if (dragStart) {
        layout.x = Math.max(0, Math.min(1, dragStart.x + (event.clientX - dragStart.clientX) / rect.width));
        layout.y = Math.max(0, Math.min(1, dragStart.y + (event.clientY - dragStart.clientY) / rect.height));
      }
      renderPreview(item.id);
    }
    canvas.addEventListener('mousedown', event => {
      const layout = layouts.get(item.id);
      dragging = true;
      dragStart = { clientX: event.clientX, clientY: event.clientY, x: layout.x, y: layout.y };
      event.preventDefault();
    });
    window.addEventListener('mousemove', event => { if (dragging) setFromPointer(event); });
    window.addEventListener('mouseup', () => { dragging = false; dragStart = null; });
    scaleInput.addEventListener('input', () => { layouts.get(item.id).scale = Number(scaleInput.value) / 100; renderPreview(item.id); });
    reset.addEventListener('click', () => { layouts.set(item.id, { x: 0.5, y: 0.5, scale: 1 }); scaleInput.value = 100; renderPreview(item.id); });
    nameInput.addEventListener('change', () => {
      const option = itemOptions.get(item.id);
      option.name = sanitizeFileName(nameInput.value);
      nameInput.value = option.name;
    });
    sizeMode.addEventListener('change', () => {
      const option = itemOptions.get(item.id);
      option.sizeMode = sizeMode.value;
      option.originalSize = false;
      if (sizeMode.value !== 'custom') option.width = option.height = Number(sizeMode.value);
      customSizeRow.classList.toggle('hidden', sizeMode.value !== 'custom');
      if (originalSizeButton) originalSizeButton.classList.remove('active');
      renderPreview(item.id);
    });
    if (originalSizeButton) originalSizeButton.addEventListener('click', () => {
      const option = itemOptions.get(item.id);
      const original = sourceItemSize(item);
      option.sizeMode = 'custom';
      option.width = original.width;
      option.height = original.height;
      option.originalSize = true;
      sizeMode.value = 'custom';
      widthInput.value = original.width;
      heightInput.value = original.height;
      customSizeRow.classList.remove('hidden');
      originalSizeButton.classList.add('active');
      renderPreview(item.id);
    });
    widthInput.addEventListener('change', () => { const option = itemOptions.get(item.id); option.width = Number(widthInput.value); option.originalSize = false; if (originalSizeButton) originalSizeButton.classList.remove('active'); renderPreview(item.id); });
    heightInput.addEventListener('change', () => { const option = itemOptions.get(item.id); option.height = Number(heightInput.value); option.originalSize = false; if (originalSizeButton) originalSizeButton.classList.remove('active'); renderPreview(item.id); });
    backgroundMode.addEventListener('change', () => {
      itemOptions.get(item.id).backgroundMode = backgroundMode.value;
      colorInput.classList.toggle('hidden', backgroundMode.value !== 'custom');
      renderPreview(item.id);
    });
    colorInput.addEventListener('input', () => { itemOptions.get(item.id).customColor = colorInput.value.toUpperCase(); renderPreview(item.id); });
    deleteButton.addEventListener('click', () => {
      const count = archiveActivePreviews([item]);
      renderPreviewWorkspace();
      setStatus(count ? `已将“${item.name}”移入草稿箱` : '该预览无法移入草稿箱', count ? 'success' : 'error');
    });
  }

  function createPreviewCards() {
    ui.previewGrid.innerHTML = selectionItems.map(item => {
      const layout = layouts.get(item.id) || { x: 0.5, y: 0.5, scale: 1 };
      const option = itemOptions.get(item.id) || defaultItemOption(item);
      itemOptions.set(item.id, option);
      const size = itemSize(item.id);
      if (option.sizeMode === 'original') {
        const original = sourceItemSize(item);
        option.sizeMode = 'custom';
        option.width = original.width;
        option.height = original.height;
        option.originalSize = true;
      }
      const sizeOptions = [['500', '500 × 500'], ['1000', '1000 × 1000'], ['custom', '自定义']]
        .map(pair => `<option value="${pair[0]}"${option.sizeMode === pair[0] ? ' selected' : ''}>${pair[1]}</option>`).join('');
      const backgrounds = [['transparent', '透明'], ['#00FF00', '纯绿'], ['#0000FF', '纯蓝'], ['#FF0000', '纯红'], ['#000000', '纯黑'], ['custom', '自定义']]
        .map(pair => `<option value="${pair[0]}"${option.backgroundMode === pair[0] ? ' selected' : ''}>${pair[1]}</option>`).join('');
      return `
      <article class="preview-card">
        <div class="preview-title"><strong title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</strong><small data-size-label="${item.id}">${size.width}×${size.height}</small></div>
        <div class="canvas-wrap"><button data-delete="${item.id}" class="delete-preview" title="移入草稿箱">×</button><canvas data-item-id="${item.id}"></canvas></div>
        <div class="preview-controls">
          <div class="card-field name-field"><label>导出名称</label><input data-name="${item.id}" type="text" value="${escapeHtml(option.name)}"></div>
          <div class="card-field size-field"><label>尺寸</label><div class="size-control-row"><select data-size-mode="${item.id}">${sizeOptions}</select><button data-original-size="${item.id}" class="secondary${option.originalSize ? ' active' : ''}" title="恢复为 AE 原素材的像素尺寸">原始尺寸</button></div></div>
          <div class="card-field"><label>背景</label><select data-background="${item.id}">${backgrounds}</select></div>
          <div data-custom-size="${item.id}" class="mini-size ${option.sizeMode === 'custom' ? '' : 'hidden'}">
            <input data-width="${item.id}" type="number" min="64" max="8192" value="${option.width}"><span>×</span><input data-height="${item.id}" type="number" min="64" max="8192" value="${option.height}">
          </div>
          <input data-color="${item.id}" type="color" value="${escapeHtml(option.customColor || '#00FF00')}" class="${option.backgroundMode === 'custom' ? '' : 'hidden'}">
          <div class="scale-row"><span>大小</span><input data-scale="${item.id}" type="range" min="10" max="250" value="${Math.round(layout.scale * 100)}"><span data-scale-label="${item.id}">${Math.round(layout.scale * 100)}%</span></div>
          <div class="legacy-reset-row"><button data-reset="${item.id}">复位</button></div>
        </div>
      </article>`;
    }).join('');
    for (const item of selectionItems) bindPreviewCard(item);
  }
  async function generatePreviews() {
    if (!selectionItems.length) return;
    busy = true; updateButtons(); clearPreviews(); busy = true;
    ui.previewSection.classList.remove('hidden');
    setStatus('正在从 AE 生成预览源…');
    ui.progress.classList.remove('hidden');
    try {
      for (let i = 0; i < selectionItems.length; i += 1) {
        const item = selectionItems[i];
        ui.batchProgress.textContent = `${i + 1}/${selectionItems.length}`;
        ui.bar.style.width = `${Math.round(i / selectionItems.length * 100)}%`;
        const targetPath = tempPng(`preview-${item.id}`);
        const raw = await evalScript(`CanvasBridge.preparePreviewSource(${Number(item.id)},${quote(targetPath)})`);
        const result = parseEvalJson(raw, `生成“${item.name}”预览`);
        if (!result.ok) throw new Error(result.error);
        await waitForStableFile(result.path, 30000);
        const image = new Image();
        const loaded = new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error(`无法载入“${item.name}”的预览图`)); });
        image.src = fileUrl(result.path);
        await loaded;
        previewSources.set(item.id, { path: result.path, width: result.width, height: result.height, image });
        layouts.set(item.id, { x: 0.5, y: 0.5, scale: 1 });
      }
      createPreviewCards();
      previewReady = true;
      renderAllPreviews();
      setStatus(`已生成 ${selectionItems.length} 项预览，请调整排版`, 'success');
    } catch (error) {
      clearPreviews();
      setStatus(error.message, 'error');
    } finally {
      busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons();
    }
  }

  async function sendAssets(assets) {
    lastRetryAssets = [];
    const batchId = assets.length && assets[0].batchId ? assets[0].batchId : `ae-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    for (let i = 0; i < assets.length; i += 1) {
      const asset = assets[i];
      asset.batchId = asset.batchId || batchId;
      asset.batchIndex = Number.isInteger(asset.batchIndex) ? asset.batchIndex : i;
      asset.batchCount = Number.isInteger(asset.batchCount) ? asset.batchCount : assets.length;
      ui.batchProgress.textContent = `发送 ${i + 1}/${assets.length}`;
      setStatus(`正在发送：${asset.fileName}`);
      try {
        await server.sendAsset(asset.path, {
          fileName: asset.fileName, mimeType: asset.mimeType, width: asset.width, height: asset.height, sourceType: asset.sourceType,
          batchId: asset.batchId, batchIndex: asset.batchIndex, batchCount: asset.batchCount,
          origin: normalizeBridgeOrigin(asset.origin)
        });
        safeUnlink(asset.path);
      } catch (error) {
        lastRetryAssets = assets.slice(i);
        throw error;
      }
    }
  }

  async function exportAndSend() {
    if (!previewReady) return;
    busy = true; updateButtons(); ui.retry.classList.add('hidden');
    ui.progress.classList.remove('hidden'); ui.bar.style.width = '0%';
    let rendered = [];
    try {
      rendered = await renderFinalAssets();
      await sendAssets(rendered);
      ui.bar.style.width = '100%';
      setStatus(`已将 ${selectionItems.length} 张图片插入当前画板`, 'success');
    } catch (error) {
      if (!lastRetryAssets.length) for (const asset of rendered) safeUnlink(asset.path);
      setStatus(error.message, 'error');
      if (lastRetryAssets.length) ui.retry.classList.remove('hidden');
    } finally {
      busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons();
    }
  }

  async function exportToLocal() {
    if (!previewReady) return;
    busy = true; updateButtons(); ui.progress.classList.remove('hidden'); ui.bar.style.width = '0%';
    let rendered = [];
    try {
      const directory = await selectedExportDirectory();
      rendered = await renderFinalAssets();
      const savedPaths = [];
      for (let i = 0; i < rendered.length; i += 1) {
        const asset = rendered[i];
        ui.batchProgress.textContent = `保存 ${i + 1}/${rendered.length}`;
        const target = uniquePath(directory, `${sanitizeFileName(path.parse(asset.fileName).name)}.png`);
        fs.copyFileSync(asset.path, target);
        savedPaths.push(target);
        safeUnlink(asset.path);
        ui.bar.style.width = `${Math.round((i + 1) / rendered.length * 100)}%`;
      }
      setStatus(`已导出 ${savedPaths.length} 张图片到：${directory}`, 'success');
    } catch (error) {
      for (const asset of rendered) safeUnlink(asset.path);
      setStatus(error.message, 'error');
    } finally {
      busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons();
    }
  }

  async function exportToEagle() {
    if (!previewReady) return;
    busy = true; updateButtons(); ui.progress.classList.remove('hidden'); ui.bar.style.width = '0%';
    let rendered = [];
    try {
      rendered = await renderFinalAssets();
      for (let i = 0; i < rendered.length; i += 1) {
        const asset = rendered[i];
        const stablePath = uniquePath(eagleStagingRoot(), `${sanitizeFileName(path.parse(asset.fileName).name)}-${Date.now()}.png`);
        fs.copyFileSync(asset.path, stablePath);
        safeUnlink(asset.path);
        asset.path = stablePath;
        ui.batchProgress.textContent = `Eagle ${i + 1}/${rendered.length}`;
        setStatus(`正在导入 Eagle：${asset.fileName}`);
        await eagleAddFromPath(asset.path, asset);
        ui.bar.style.width = `${Math.round((i + 1) / rendered.length * 100)}%`;
      }
      setStatus(`已将 ${rendered.length} 张图片交给 Eagle，暂存文件将保留 24 小时`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons();
    }
  }

  async function retryRemaining() {
    if (!lastRetryAssets.length) return;
    busy = true; updateButtons(); ui.retry.classList.add('hidden'); ui.progress.classList.remove('hidden');
    try {
      const count = lastRetryAssets.length;
      await sendAssets(lastRetryAssets.slice());
      setStatus(`剩余 ${count} 张图片已发送`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
      ui.retry.classList.remove('hidden');
    } finally { busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons(); }
  }

  function defaultPreviewLayout() {
    return { x: 0.5, y: 0.5, scale: 1, rotation: 0 };
  }

  function refreshSelectionList(sourceLabel, addedCount) {
    selectionKey = selectionItems.map(item => item.id).join(',');
    ui.selectionSummary.textContent = `当前预览保留 ${selectionItems.length} 项 · 本次新增 ${addedCount} 项 · 来源：${sourceLabel}`;
    ui.selectionList.innerHTML = selectionItems.map((item, index) =>
      `<div class="selection-item"><span>${index + 1}. ${escapeHtml(item.name)}</span><small>${item.kind === 'comp' ? '合成' : '图片'} · ${item.width}×${item.height}</small></div>`
    ).join('');
  }

  loadSelection = async function loadSelection(autoPreview) {
    if (busy) return;
    busy = true; updateButtons();
    let shouldGenerate = false;
    try {
      await ensureHostScriptLoaded(true);
      const raw = await evalScript('CanvasBridge.getSelectionInfo()');
      const info = parseEvalJson(raw, '读取 AE 所选素材');
      if (!info.ok) throw new Error(info.error);
      const sourceLabel = info.selectionSource === 'timeline' ? '时间线图层' : '项目面板';
      const knownIds = new Set(selectionItems.map(item => String(item.id)));
      let addedCount = 0;
      if (autoPreview || selectionItems.length) {
        for (const item of info.items) {
          if (knownIds.has(String(item.id))) continue;
          selectionItems.push(item);
          knownIds.add(String(item.id));
          addedCount += 1;
        }
      } else {
        selectionItems = info.items.slice();
        addedCount = selectionItems.length;
      }
      refreshSelectionList(sourceLabel, addedCount);
      shouldGenerate = !!autoPreview;
    } catch (error) {
      if (!selectionItems.length) {
        selectionKey = '';
        ui.selectionSummary.textContent = '尚未载入素材';
        ui.selectionList.innerHTML = `<div class="muted">${escapeHtml(error.message)}</div>`;
      }
      setStatus(error.message, 'error');
    }
    busy = false;
    updateButtons();
    if (shouldGenerate) await generatePreviews();
  };

  renderPreview = function renderPreview(itemId) {
    const source = previewSources.get(itemId);
    const layout = Object.assign(defaultPreviewLayout(), layouts.get(itemId) || {});
    const canvas = document.querySelector(`canvas[data-item-id="${itemId}"]`);
    if (!source || !layout || !canvas || !source.image.complete) return;
    layouts.set(itemId, layout);
    const size = itemSize(itemId);
    const previewSize = previewCanvasSize(size);
    canvas.width = previewSize.width;
    canvas.height = previewSize.height;
    canvas.style.aspectRatio = `${size.width} / ${size.height}`;
    const ctx = canvas.getContext('2d');
    const bg = itemBackground(itemId);
    if (bg) { ctx.fillStyle = bg; ctx.fillRect(0, 0, canvas.width, canvas.height); }
    else drawCheckerboard(ctx, canvas.width, canvas.height);
    const fit = Math.min(canvas.width / source.width, canvas.height / source.height) * itemFitRatio(itemId) * layout.scale;
    const drawWidth = source.width * fit;
    const drawHeight = source.height * fit;
    const rotation = Number(layout.rotation) || 0;
    ctx.save();
    ctx.translate(layout.x * canvas.width, layout.y * canvas.height);
    ctx.rotate(rotation * Math.PI / 180);
    ctx.drawImage(source.image, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
    ctx.restore();
    const scaleLabel = document.querySelector(`[data-scale-label="${itemId}"]`);
    if (scaleLabel) scaleLabel.textContent = `${Math.round(layout.scale * 100)}%`;
    const scaleNumber = document.querySelector(`[data-scale-number="${itemId}"]`);
    if (scaleNumber && document.activeElement !== scaleNumber) scaleNumber.value = Math.round(layout.scale * 100);
    const rotationRange = document.querySelector(`[data-rotation="${itemId}"]`);
    const rotationNumber = document.querySelector(`[data-rotation-number="${itemId}"]`);
    if (rotationRange && document.activeElement !== rotationRange) rotationRange.value = Math.round(rotation);
    if (rotationNumber && document.activeElement !== rotationNumber) rotationNumber.value = Math.round(rotation);
    const sizeLabel = document.querySelector(`[data-size-label="${itemId}"]`);
    if (sizeLabel) sizeLabel.textContent = `${size.width}×${size.height}`;
  };

  bindPreviewCard = function bindPreviewCard(item) {
    const canvas = document.querySelector(`canvas[data-item-id="${item.id}"]`);
    const scaleInput = document.querySelector(`[data-scale="${item.id}"]`);
    const scaleNumber = document.querySelector(`[data-scale-number="${item.id}"]`);
    const rotationInput = document.querySelector(`[data-rotation="${item.id}"]`);
    const rotationNumber = document.querySelector(`[data-rotation-number="${item.id}"]`);
    const reset = document.querySelector(`[data-reset="${item.id}"]`);
    const nameInput = document.querySelector(`[data-name="${item.id}"]`);
    const sizeMode = document.querySelector(`[data-size-mode="${item.id}"]`);
    const originalSizeButton = document.querySelector(`[data-original-size="${item.id}"]`);
    const widthInput = document.querySelector(`[data-width="${item.id}"]`);
    const heightInput = document.querySelector(`[data-height="${item.id}"]`);
    const customSizeRow = document.querySelector(`[data-custom-size="${item.id}"]`);
    const backgroundMode = document.querySelector(`[data-background="${item.id}"]`);
    const colorInput = document.querySelector(`[data-color="${item.id}"]`);
    const deleteButton = document.querySelector(`[data-delete="${item.id}"]`);
    const sendKiviBoard = document.querySelector(`[data-send-kivi-board="${item.id}"]`);
    const queueKivi = document.querySelector(`[data-queue-kivi="${item.id}"]`);
    let dragging = false;
    let dragStart = null;
    function setFromPointer(event) {
      const rect = canvas.getBoundingClientRect();
      const layout = layouts.get(item.id);
      if (dragStart) {
        layout.x = Math.max(0, Math.min(1, dragStart.x + (event.clientX - dragStart.clientX) / rect.width));
        layout.y = Math.max(0, Math.min(1, dragStart.y + (event.clientY - dragStart.clientY) / rect.height));
      }
      renderPreview(item.id);
    }
    function setRotation(value) {
      const rotation = Math.max(-180, Math.min(180, Math.round(Number(value) || 0)));
      const layout = layouts.get(item.id);
      layout.rotation = rotation;
      rotationInput.value = rotation;
      rotationNumber.value = rotation;
      renderPreview(item.id);
    }
    function setScale(value) {
      const scale = Math.max(10, Math.min(250, Math.round(Number(value) || 100)));
      layouts.get(item.id).scale = scale / 100;
      scaleInput.value = scale;
      if (scaleNumber) scaleNumber.value = scale;
      renderPreview(item.id);
    }
    canvas.addEventListener('mousedown', event => {
      const layout = layouts.get(item.id);
      dragging = true;
      dragStart = { clientX: event.clientX, clientY: event.clientY, x: layout.x, y: layout.y };
      event.preventDefault();
    });
    window.addEventListener('mousemove', event => { if (dragging) setFromPointer(event); });
    window.addEventListener('mouseup', () => { dragging = false; dragStart = null; });
    scaleInput.addEventListener('input', () => setScale(scaleInput.value));
    if (scaleNumber) scaleNumber.addEventListener('input', () => setScale(scaleNumber.value));
    rotationInput.addEventListener('input', () => setRotation(rotationInput.value));
    rotationNumber.addEventListener('input', () => setRotation(rotationNumber.value));
    reset.addEventListener('click', () => { layouts.set(item.id, defaultPreviewLayout()); scaleInput.value = 100; if (scaleNumber) scaleNumber.value = 100; rotationInput.value = 0; rotationNumber.value = 0; renderPreview(item.id); });
    nameInput.addEventListener('change', () => {
      const option = itemOptions.get(item.id);
      option.name = sanitizeFileName(nameInput.value);
      nameInput.value = option.name;
    });
    sizeMode.addEventListener('change', () => {
      const option = itemOptions.get(item.id);
      option.sizeMode = sizeMode.value;
      option.originalSize = false;
      if (sizeMode.value !== 'custom') option.width = option.height = Number(sizeMode.value);
      customSizeRow.classList.toggle('hidden', sizeMode.value !== 'custom');
      if (originalSizeButton) originalSizeButton.classList.remove('active');
      renderPreview(item.id);
    });
    if (originalSizeButton) originalSizeButton.addEventListener('click', () => {
      const option = itemOptions.get(item.id);
      const original = sourceItemSize(item);
      option.sizeMode = 'custom';
      option.width = original.width;
      option.height = original.height;
      option.originalSize = true;
      sizeMode.value = 'custom';
      widthInput.value = original.width;
      heightInput.value = original.height;
      customSizeRow.classList.remove('hidden');
      originalSizeButton.classList.add('active');
      renderPreview(item.id);
    });
    widthInput.addEventListener('change', () => { const option = itemOptions.get(item.id); option.width = Number(widthInput.value); option.originalSize = false; if (originalSizeButton) originalSizeButton.classList.remove('active'); renderPreview(item.id); });
    heightInput.addEventListener('change', () => { const option = itemOptions.get(item.id); option.height = Number(heightInput.value); option.originalSize = false; if (originalSizeButton) originalSizeButton.classList.remove('active'); renderPreview(item.id); });
    backgroundMode.addEventListener('change', () => {
      itemOptions.get(item.id).backgroundMode = backgroundMode.value;
      colorInput.classList.toggle('hidden', backgroundMode.value !== 'custom');
      renderPreview(item.id);
    });
    colorInput.addEventListener('input', () => { itemOptions.get(item.id).customColor = colorInput.value.toUpperCase(); renderPreview(item.id); });
    if (sendKiviBoard) sendKiviBoard.addEventListener('click', () => sendSinglePreviewToBoard(item.id));
    if (queueKivi) queueKivi.addEventListener('click', () => prepareKiviVideoAssets([item]));
    deleteButton.addEventListener('click', () => {
      const count = archiveActivePreviews([item]);
      renderPreviewWorkspace();
      setStatus(count ? `已将“${item.name}”移入草稿箱` : '该预览无法移入草稿箱', count ? 'success' : 'error');
    });
  };

  createPreviewCards = function createPreviewCards() {
    ui.previewGrid.innerHTML = selectionItems.map(item => {
      const layout = Object.assign(defaultPreviewLayout(), layouts.get(item.id) || {});
      layouts.set(item.id, layout);
      const option = itemOptions.get(item.id) || defaultItemOption(item);
      itemOptions.set(item.id, option);
      const size = itemSize(item.id);
      if (option.sizeMode === 'original') {
        const original = sourceItemSize(item);
        option.sizeMode = 'custom';
        option.width = original.width;
        option.height = original.height;
        option.originalSize = true;
      }
      const sizeOptions = [['500', '500 × 500'], ['1000', '1000 × 1000'], ['custom', '自定义']]
        .map(pair => `<option value="${pair[0]}"${option.sizeMode === pair[0] ? ' selected' : ''}>${pair[1]}</option>`).join('');
      const backgrounds = [['transparent', '透明'], ['#00FF00', '纯绿'], ['#0000FF', '纯蓝'], ['#FF0000', '纯红'], ['#000000', '纯黑'], ['custom', '自定义']]
        .map(pair => `<option value="${pair[0]}"${option.backgroundMode === pair[0] ? ' selected' : ''}>${pair[1]}</option>`).join('');
      return `
      <article class="preview-card">
        <div class="preview-title"><strong title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</strong><small data-size-label="${item.id}">${size.width}×${size.height}</small></div>
        <div class="canvas-wrap"><button data-delete="${item.id}" class="delete-preview" title="移入草稿箱">×</button><canvas data-item-id="${item.id}"></canvas></div>
        <div class="preview-controls">
          <div class="card-field name-field"><label>导出名称</label><input data-name="${item.id}" type="text" value="${escapeHtml(option.name)}"></div>
          <div class="card-field size-field"><label>尺寸</label><div class="size-control-row"><select data-size-mode="${item.id}">${sizeOptions}</select><button data-original-size="${item.id}" class="secondary${option.originalSize ? ' active' : ''}" title="恢复为 AE 原素材的像素尺寸">原始尺寸</button></div></div>
          <div class="card-field"><label>背景</label><select data-background="${item.id}">${backgrounds}</select></div>
          <div data-custom-size="${item.id}" class="mini-size ${option.sizeMode === 'custom' ? '' : 'hidden'}">
            <input data-width="${item.id}" type="number" min="64" max="8192" value="${option.width}"><span>×</span><input data-height="${item.id}" type="number" min="64" max="8192" value="${option.height}">
          </div>
          <input data-color="${item.id}" type="color" value="${escapeHtml(option.customColor || '#00FF00')}" class="${option.backgroundMode === 'custom' ? '' : 'hidden'}">
          <div class="transform-row">
            <label class="transform-control scale-control"><span>大小</span><input data-scale="${item.id}" type="range" min="10" max="250" step="1" value="${Math.round(layout.scale * 100)}"><input data-scale-number="${item.id}" type="number" min="10" max="250" step="1" value="${Math.round(layout.scale * 100)}" aria-label="大小百分比"><i>%</i></label>
            <label class="transform-control rotation-control"><span>旋转</span><input data-rotation="${item.id}" type="range" min="-180" max="180" step="1" value="${Math.round(layout.rotation || 0)}"><input data-rotation-number="${item.id}" type="number" min="-180" max="180" step="1" value="${Math.round(layout.rotation || 0)}" aria-label="旋转角度"><i>°</i></label>
            <button data-reset="${item.id}" title="复位位置、大小和旋转">复位</button>
          </div>
          <div class="preview-card-actions"><button data-queue-kivi="${item.id}" class="primary kivi-queue-button">添加KIVI队列</button><button data-send-kivi-board="${item.id}" class="secondary send-kivi-board">发送KIVI画板</button></div>
        </div>
      </article>`;
    }).join('');
    for (const item of selectionItems) bindPreviewCard(item);
  };

  generatePreviews = async function generatePreviews() {
    if (!selectionItems.length) return;
    busy = true; updateButtons();
    ui.previewSection.classList.remove('hidden');
    const pendingItems = selectionItems.filter(item => !previewSources.has(item.id));
    if (!pendingItems.length) {
      createPreviewCards();
      previewReady = true;
      renderAllPreviews();
      setStatus(`当前已保留 ${selectionItems.length} 项预览`, 'success');
      busy = false; updateButtons();
      return;
    }
    setStatus('正在从 AE 生成新增素材预览…');
    ui.progress.classList.remove('hidden');
    const createdIds = [];
    try {
      for (let i = 0; i < pendingItems.length; i += 1) {
        const item = pendingItems[i];
        ui.batchProgress.textContent = `${i + 1}/${pendingItems.length}`;
        ui.bar.style.width = `${Math.round(i / pendingItems.length * 100)}%`;
        const targetPath = tempPng(`preview-${item.id}`);
        const raw = await evalScript(`CanvasBridge.preparePreviewSource(${Number(item.sourceItemId || item.id)},${quote(targetPath)})`);
        const result = parseEvalJson(raw, `生成“${item.name}”预览`);
        if (!result.ok) throw new Error(result.error);
        await waitForStableFile(result.path, 30000);
        const image = new Image();
        const loaded = new Promise((resolve, reject) => { image.onload = resolve; image.onerror = () => reject(new Error(`无法载入“${item.name}”的预览图`)); });
        image.src = fileUrl(result.path);
        await loaded;
        previewSources.set(item.id, { path: result.path, width: result.width, height: result.height, image });
        if (!layouts.has(item.id)) layouts.set(item.id, defaultPreviewLayout());
        createdIds.push(item.id);
      }
      createPreviewCards();
      previewReady = true;
      renderAllPreviews();
      setStatus(`已新增 ${pendingItems.length} 项预览，当前共保留 ${selectionItems.length} 项`, 'success');
    } catch (error) {
      for (const id of createdIds) {
        const source = previewSources.get(id);
        if (source) safeUnlink(source.path);
        previewSources.delete(id);
      }
      previewReady = previewSources.size > 0;
      if (previewReady) { createPreviewCards(); renderAllPreviews(); }
      setStatus(error.message, 'error');
    } finally {
      busy = false; ui.batchProgress.textContent = ''; ui.progress.classList.add('hidden'); updateButtons();
    }
  };

  async function renderFinalAssets(items) {
    const assets = [];
    const targets = Array.isArray(items) ? items : selectionItems;
    try {
      for (let i = 0; i < targets.length; i += 1) {
        const item = targets[i];
        const layout = Object.assign(defaultPreviewLayout(), layouts.get(item.id) || {});
        const option = itemOptions.get(item.id) || defaultItemOption(item);
        const size = itemSize(item.id);
        const background = itemBackground(item.id);
        ui.batchProgress.textContent = `渲染 ${i + 1}/${targets.length}`;
        ui.bar.style.width = `${Math.round(i / targets.length * 100)}%`;
        setStatus(`正在渲染：${option.name}`);
        const targetPath = tempPng(`export-${String(item.id).replace(/[^0-9A-Za-z_-]/g, '_')}`);
        const fitRatio = itemFitRatio(item.id);
        const raw = await evalScript(`CanvasBridge.renderBatchAsset(${Number(item.sourceItemId || item.id)},${quote(targetPath)},${size.width},${size.height},${quote(background)},${layout.x},${layout.y},${layout.scale},${Number(layout.rotation) || 0},${fitRatio})`);
        const result = parseEvalJson(raw, `渲染“${item.name}”`);
        if (!result.ok) throw new Error(result.error);
        await waitForStableFile(result.path, 30000);
        result.fileName = `${sanitizeFileName(option.name)}.png`;
        result.origin = {
          projectPath: item.projectPath || '',
          comp: item.comp || null,
          layer: item.layer || null,
          source: {
            itemId: Number(item.sourceItemId || 0),
            kind: item.kind,
            name: item.sourceName || item.name,
            layerName: item.layer && item.layer.name ? item.layer.name : item.name,
            width: Number(item.width) || 0,
            height: Number(item.height) || 0
          },
          export: {
            width: size.width,
            height: size.height,
            x: Number(layout.x),
            y: Number(layout.y),
            scaleMultiplier: Number(layout.scale),
            fitRatio,
            rotation: Number(layout.rotation) || 0,
            backgroundMode: option.backgroundMode,
            backgroundHex: background || '#000000'
          }
        };
        assets.push(result);
      }
      return assets;
    } catch (error) {
      for (const asset of assets) safeUnlink(asset.path);
      throw error;
    }
  }

  function kiviCredentialFile() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'kivi-access-token.dpapi');
  }

  function runKiviCredential(action, token) {
    const scriptPath = path.join(extensionRoot, 'js', 'kivi-credentials.ps1');
    return new Promise((resolve, reject) => {
      const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
      const child = childProcess.spawn(executable, [
        '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath,
        '-Action', action, '-Path', kiviCredentialFile()
      ], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      let stdout = '';
      let stderr = '';
      child.stdout.on('data', chunk => { stdout += String(chunk); });
      child.stderr.on('data', chunk => { stderr += String(chunk); });
      child.on('error', error => reject(error));
      child.on('close', code => {
        if (code === 0) resolve(stdout.trim());
        else reject(new Error((stderr || '无法访问本机 KIVI 凭据').trim().slice(0, 300)));
      });
      child.stdin.end(token ? String(token) : '');
    });
  }

  function agentDataRoot() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'agent');
  }

  function deepseekCredentialFile() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'credentials', 'deepseek.dpapi');
  }

  function runSecureCredential(action, credentialPath, value) {
    const scriptPath = path.join(extensionRoot, 'js', 'secure-credentials.ps1');
    return new Promise((resolve, reject) => {
      const executable = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
      const child = childProcess.spawn(executable, [
        '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath,
        '-Action', action, '-Path', credentialPath
      ], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      let stdout = '';
      let stderr = '';
      child.stdout.on('data', chunk => { stdout += String(chunk); });
      child.stderr.on('data', chunk => { stderr += String(chunk); });
      child.on('error', reject);
      child.on('close', code => code === 0 ? resolve(stdout.trim()) : reject(new Error((stderr || '无法访问本机加密凭据').trim().slice(0, 300))));
      child.stdin.end(value ? String(value) : '');
    });
  }

  function usageTelemetryRoot() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'analytics');
  }

  function usageRelayTokenFile() {
    const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(localAppData, 'AE Canvas Bridge', 'credentials', 'usage-relay.dpapi');
  }

  function readUsageRelayConfig() {
    const configFile = path.join(usageTelemetryRoot(), 'relay.json');
    if (!fs.existsSync(configFile)) return { endpoint: '', consentVersion: '' };
    try {
      const parsed = JSON.parse(fs.readFileSync(configFile, 'utf8').replace(/^\uFEFF/, ''));
      const endpoint = String(parsed.endpoint || '').trim();
      if (endpoint && !/^https:\/\//i.test(endpoint)) throw new Error('Relay 地址必须使用 HTTPS');
      return { endpoint, consentVersion: String(parsed.consentVersion || '') };
    } catch (error) {
      return { endpoint: '', consentVersion: '', error: `Relay 配置无效：${error.message}` };
    }
  }

  function currentHostVersion() {
    try {
      const host = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      return String(host.appVersion || host.appName || 'unknown');
    } catch (_) {
      return 'unknown';
    }
  }

  function refreshUsageReportingUi(message, kind) {
    if (!ui.usageReportingStatus) return;
    const configured = !!(usageTelemetry && usageTelemetry.isConfigured());
    const enabled = configured && usageTelemetry.isEnabled();
    const state = usageTelemetry ? usageTelemetry.consentState() : 'unset';
    ui.usageReportingToggle.disabled = !configured;
    ui.usageReportingToggle.checked = enabled;
    ui.usageReportingSync.disabled = !enabled || !!usageTelemetryInFlight;
    ui.usageReportingStatus.textContent = !configured ? '未配置' : enabled ? '已启用' : state === 'unset' ? '等待选择' : '已关闭';
    ui.usageReportingStatus.className = `badge ${enabled ? 'online' : 'offline'}`;
    const pending = usageTelemetry ? usageTelemetry.pendingFiles().length : 0;
    ui.usageReportingDetail.textContent = message || (!configured
      ? '需要先配置公司内部 Relay，插件不会直接持有飞书密钥。'
      : enabled ? `后台同步已启用${pending ? `，待发送 ${pending} 条` : '，当前无待发送数据'}。` : '使用数据不会发送；可随时重新启用。');
    ui.usageReportingDetail.style.color = kind === 'error' ? '#ffb4ab' : kind === 'success' ? '#8ce99a' : '';
  }

  async function captureAndFlushUsageTelemetry(manual) {
    if (usageTelemetryInFlight) return usageTelemetryInFlight;
    if (!usageTelemetry || !usageTelemetry.isConfigured() || !usageTelemetry.isEnabled()) {
      refreshUsageReportingUi('使用改进数据未启用。');
      return null;
    }
    if (!kiviStore) {
      refreshUsageReportingUi('等待当前工程任务库加载完成。');
      return null;
    }
    usageTelemetryInFlight = (async () => {
      try {
        refreshUsageReportingUi('正在整理脱敏统计并同步…');
        const client = createKiviClient({ token: await readKiviCredential() });
        const queued = await usageTelemetry.capture({
          client,
          jobs: kiviStore.state.jobs,
          pluginVersion: CURRENT_AE_VERSION,
          aeVersion: currentHostVersion()
        });
        const result = await usageTelemetry.flush();
        const detail = result.reason === 'not-configured'
          ? 'Relay 尚未配置完整。'
          : result.reason === 'unauthorized'
            ? 'Relay 令牌已失效，请联系管理员重新配置。'
            : `同步完成：发送 ${result.sent || 0} 条，待发送 ${result.pending || 0} 条。`;
        refreshUsageReportingUi(detail, result.reason ? 'error' : 'success');
        return { queued, result };
      } catch (error) {
        refreshUsageReportingUi(`同步未完成：${error.message}`, 'error');
        if (manual) throw error;
        return null;
      } finally {
        usageTelemetryInFlight = null;
        refreshUsageReportingUi(ui.usageReportingDetail.textContent);
      }
    })();
    return usageTelemetryInFlight;
  }

  function scheduleUsageTelemetry(delayMs) {
    if (!usageTelemetry || !usageTelemetry.isConfigured() || !usageTelemetry.isEnabled()) return;
    if (usageTelemetryTimer) clearTimeout(usageTelemetryTimer);
    usageTelemetryTimer = setTimeout(() => {
      usageTelemetryTimer = null;
      captureAndFlushUsageTelemetry(false);
    }, Math.max(1000, Number(delayMs) || 45000));
  }

  function latestProjectSaveStamp(projectPath, projectDirectory) {
    const root = KiviWorkspaceRecovery.resolveProjectRoot({ projectDirectory }).projectRoot;
    const folders = [root, path.join(root, 'Adobe After Effects Auto-Save')];
    const entries = [];
    if (projectPath && fs.existsSync(projectPath)) entries.push(projectPath);
    folders.forEach(directory => {
      if (!directory || !fs.existsSync(directory)) return;
      let names = [];
      try { names = fs.readdirSync(directory); } catch (_) { return; }
      names.forEach(name => {
        if (!/\.(aep|aepx)$/i.test(name)) return;
        const filePath = path.join(directory, name);
        try { if (fs.statSync(filePath).isFile()) entries.push(filePath); } catch (_) {}
      });
    });
    let newest = 0;
    let newestSize = 0;
    entries.forEach(filePath => {
      try {
        const stat = fs.statSync(filePath);
        if (stat.mtimeMs > newest) { newest = stat.mtimeMs; newestSize = stat.size; }
      } catch (_) {}
    });
    return `${path.resolve(root).toLowerCase()}|${Math.round(newest)}|${newestSize}`;
  }

  async function pollProjectSaveForTelemetry() {
    if (!usageTelemetry || !usageTelemetry.isConfigured() || !usageTelemetry.isEnabled()) return;
    try {
      const raw = await evalScript('CanvasBridge.getProjectContext()');
      const context = parseEvalJson(raw, '读取 AE 工程保存状态');
      if (!context.ok) return;
      const signature = latestProjectSaveStamp(context.projectPath || '', context.path || '');
      if (!signature) return;
      if (!lastProjectSaveSignature) {
        lastProjectSaveSignature = signature;
        return;
      }
      if (signature !== lastProjectSaveSignature) {
        lastProjectSaveSignature = signature;
        scheduleUsageTelemetry(1500);
      }
    } catch (_) {}
  }

  function startProjectSaveMonitor() {
    if (projectSaveMonitor) clearInterval(projectSaveMonitor);
    projectSaveMonitor = null;
    lastProjectSaveSignature = '';
    if (!usageTelemetry || !usageTelemetry.isConfigured() || !usageTelemetry.isEnabled()) return;
    pollProjectSaveForTelemetry();
    projectSaveMonitor = setInterval(pollProjectSaveForTelemetry, 20000);
  }

  async function initializeUsageTelemetry() {
    const relay = readUsageRelayConfig();
    let token = '';
    try {
      if (await runSecureCredential('exists', usageRelayTokenFile()) === '1') token = await runSecureCredential('read', usageRelayTokenFile());
    } catch (_) {}
    usageTelemetry = new UsageTelemetry({ root: usageTelemetryRoot(), endpoint: relay.endpoint, token, consentVersion: relay.consentVersion, defaultConsent: 'enabled' });
    refreshUsageReportingUi(relay.error || '');
    if (!usageTelemetry.isConfigured()) return usageTelemetry;
    if (usageTelemetry.isEnabled()) startProjectSaveMonitor();
    return usageTelemetry;
  }

  async function readDeepseekCredential() {
    const value = await runSecureCredential('read', deepseekCredentialFile());
    if (!value) throw new Error('DeepSeek API Key 为空，请重新保存');
    return value;
  }

  async function createDeepseekProvider() {
    return new DeepSeekProvider({
      apiKey: await readDeepseekCredential(),
      model: ui.agentModel && ui.agentModel.value ? ui.agentModel.value : 'deepseek-flash',
      timeoutMs: 90000,
      maxAttempts: 3
    });
  }

  async function readKiviCredential() {
    const token = await runKiviCredential('read');
    if (!token) throw new Error('KIVI Key 为空，请重新保存');
    return token;
  }

  function setKiviVideoStatus(message, kind) {
    if (!ui.kiviVideoStatus) return;
    ui.kiviVideoStatus.textContent = message;
    ui.kiviVideoStatus.style.color = kind === 'error' ? '#ffb4ab' : kind === 'success' ? '#8ce99a' : '';
  }

  async function refreshKiviCredentialState() {
    if (!ui.kiviKeyBadge) return;
    try {
      const exists = await runKiviCredential('exists');
      const configured = exists === '1';
      ui.kiviKeyBadge.textContent = configured ? 'Key 已加密保存' : '未配置 Key';
      ui.kiviKeyBadge.className = `badge ${configured ? 'online' : 'offline'}`;
      if (ui.kiviCredentialSummary) ui.kiviCredentialSummary.textContent = configured ? '已安全保存' : '点击配置';
    } catch (_) {
      ui.kiviKeyBadge.textContent = '凭据不可用';
      ui.kiviKeyBadge.className = 'badge offline';
      if (ui.kiviCredentialSummary) ui.kiviCredentialSummary.textContent = '凭据不可用';
    }
  }

  function setAgentProviderStatus(message, kind) {
    if (!ui.agentProviderStatus) return;
    ui.agentProviderStatus.textContent = message;
    ui.agentProviderStatus.style.color = kind === 'error' ? '#ffb4ab' : kind === 'success' ? '#8ce99a' : '';
  }

  async function refreshDeepseekCredentialState() {
    if (!ui.deepseekKeyBadge) return false;
    try {
      deepseekCredentialConfigured = await runSecureCredential('exists', deepseekCredentialFile()) === '1';
      ui.deepseekKeyBadge.textContent = deepseekCredentialConfigured ? 'DeepSeek Key 已加密保存' : 'DeepSeek 未配置';
      ui.deepseekKeyBadge.className = `badge ${deepseekCredentialConfigured ? 'online' : 'offline'}`;
    } catch (_) {
      deepseekCredentialConfigured = false;
      ui.deepseekKeyBadge.textContent = 'DeepSeek 凭据不可用';
      ui.deepseekKeyBadge.className = 'badge offline';
    }
    updateButtons();
    if (kiviStore) renderKiviWorkbench(true);
    return deepseekCredentialConfigured;
  }

  async function saveDeepseekCredential() {
    const value = ui.deepseekKeyInput && ui.deepseekKeyInput.value ? ui.deepseekKeyInput.value.trim() : '';
    if (value.length < 16) return setAgentProviderStatus('API Key 长度异常，请确认后重试。', 'error');
    try {
      await runSecureCredential('set', deepseekCredentialFile(), value);
      ui.deepseekKeyInput.value = '';
      await refreshDeepseekCredentialState();
      setAgentProviderStatus('DeepSeek Key 已使用 Windows DPAPI 加密保存。', 'success');
    } catch (error) { setAgentProviderStatus(error.message || 'DeepSeek Key 保存失败。', 'error'); }
  }

  async function clearDeepseekCredential() {
    try {
      await runSecureCredential('clear', deepseekCredentialFile());
      await refreshDeepseekCredentialState();
      setAgentProviderStatus('已清除 DeepSeek Key。');
    } catch (error) { setAgentProviderStatus(error.message || 'DeepSeek Key 清除失败。', 'error'); }
  }

  async function testDeepseekConnection() {
    if (!ui.testDeepseekConnection) return;
    ui.testDeepseekConnection.disabled = true;
    setAgentProviderStatus('正在读取模型列表…');
    try {
      const provider = await createDeepseekProvider();
      const result = await provider.testConnection();
      if (ui.agentModel) ui.agentModel.innerHTML = result.models.map(model => `<option value="${escapeHtml(model)}">${escapeHtml(model)}</option>`).join('');
      setAgentProviderStatus('连接成功，视觉模型可用。', 'success');
    } catch (error) { setAgentProviderStatus(error.message || 'DeepSeek 连接失败。', 'error'); }
    finally { ui.testDeepseekConnection.disabled = false; }
  }

  function ensureAgentSkillStore() {
    if (!agentSkillStore) {
      agentSkillStore = new AgentSkillStore({ root: path.join(agentDataRoot(), 'skills'), bundledRoot: path.join(extensionRoot, 'skills') });
      agentSkillStore.load();
    }
    return agentSkillStore;
  }

  function renderAgentSkillManager() {
    if (!ui.agentSkillSelect) return;
    const store = ensureAgentSkillStore();
    const skills = store.list();
    const active = store.getActive();
    ui.agentSkillSelect.innerHTML = skills.length
      ? skills.map(skill => `<option value="${escapeHtml(skill.id)}"${skill.id === store.state.activeSkillId ? ' selected' : ''}>${escapeHtml(skill.name)} · v${skill.version}${skill.readOnly ? ' · 内置' : ''}</option>`).join('')
      : '<option value="">请导入 Skill</option>';
    if (ui.agentSkillStatus) {
      ui.agentSkillStatus.textContent = active ? `已启用 · v${active.version}` : '未启用';
      ui.agentSkillStatus.className = `badge ${active ? 'online' : 'offline'}`;
    }
    if (ui.agentSkillName) { ui.agentSkillName.value = active ? active.name : ''; ui.agentSkillName.disabled = !active || active.readOnly; }
    if (ui.agentSkillEditor) { ui.agentSkillEditor.value = active ? active.content : ''; ui.agentSkillEditor.disabled = !active || active.readOnly; }
    if (ui.agentSkillMeta) ui.agentSkillMeta.textContent = active ? `${active.readOnly ? '内置只读' : '自定义'} · SHA256 ${active.hash.slice(0, 12)} · ${Math.round(Buffer.byteLength(active.content, 'utf8') / 1024)} KB` : '无活动 Skill，Prompt 生成功能已禁用';
    if (ui.duplicateAgentSkill) ui.duplicateAgentSkill.disabled = !active;
    if (ui.exportAgentSkill) ui.exportAgentSkill.disabled = !active;
    if (ui.deleteAgentSkill) ui.deleteAgentSkill.disabled = !active || active.readOnly;
    if (ui.reloadAgentSkill) ui.reloadAgentSkill.disabled = !active;
    if (ui.saveAgentSkill) ui.saveAgentSkill.disabled = !active || active.readOnly;
    updateButtons();
    if (kiviStore) renderKiviWorkbench(true);
  }

  function renderAgentDebugTasks() {
    if (!ui.agentDebugTask) return;
    const jobs = kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt) : [];
    const selected = ui.agentDebugTask.value;
    ui.agentDebugTask.innerHTML = jobs.length
      ? jobs.map(job => `<option value="${escapeHtml(job.id)}"${job.id === selected || (!selected && job.id === selectedKiviJobId) ? ' selected' : ''}>${escapeHtml(kiviJobLayerName(job))} · ${kiviStatusLabel(deriveJobStatus(job))}</option>`).join('')
      : '<option value="">暂无 KIVI 任务</option>';
    if (ui.runAgentDebug) ui.runAgentDebug.disabled = !jobs.length || !ensureAgentSkillStore().getActive() || !deepseekCredentialConfigured;
    updateAgentDebugSummary();
  }

  function updateAgentDebugSummary() {
    if (!ui.agentDebugSummary || !ui.agentDebugTask) return;
    const job = kiviStore && kiviStore.findJob(ui.agentDebugTask.value);
    const skill = ensureAgentSkillStore().getActive();
    if (ui.agentDebugPreview) {
      if (job && job.source && job.source.path && fs.existsSync(job.source.path)) {
        ui.agentDebugPreview.src = fileUrl(job.source.path);
        ui.agentDebugPreview.alt = job.name || '当前调试任务';
        ui.agentDebugPreview.classList.remove('hidden');
      } else {
        ui.agentDebugPreview.removeAttribute('src');
        ui.agentDebugPreview.classList.add('hidden');
      }
    }
    ui.agentDebugSummary.textContent = job
      ? `${job.source.width || '?'} × ${job.source.height || '?'} · ${job.mode === 'general_reference' ? '智能参考' : '首尾帧'} · ${job.settings.model} · ${job.settings.ratio} · ${job.settings.resolution} · ${job.settings.duration} 秒 · Skill ${skill ? `${skill.name} v${skill.version}` : '未启用'}`
      : '选择一个任务后可预览实际输入摘要。';
    renderAgentDebugConversation();
  }

  function currentAgentDebugSession() {
    const jobId = ui.agentDebugTask && ui.agentDebugTask.value;
    return jobId ? agentDebugSessions.get(jobId) || null : null;
  }

  function agentDebugResultJson(result) {
    if (!result) return '尚未运行';
    return JSON.stringify({ prompt: result.prompt, summary: result.summary, warnings: result.warnings, model: result.model, requestId: result.requestId, usage: result.usage, latencyMs: result.latencyMs }, null, 2);
  }

  function renderAgentDebugConversation() {
    if (!ui.agentDebugConversation) return;
    const session = currentAgentDebugSession();
    const ready = !!(session && session.result);
    const busySession = !!(session && session.busy);
    ui.agentDebugConversation.innerHTML = session && session.messages.length
      ? session.messages.map(message => `<div class="agent-debug-message ${message.role === 'user' ? 'user' : 'assistant'}"><strong>${message.role === 'user' ? '你的调整' : 'Agent Prompt'}</strong>${escapeHtml(message.text)}${message.summary ? `<small>${escapeHtml(message.summary)}</small>` : ''}</div>`).join('')
      : '<div class="agent-debug-empty">尚未运行测试</div>';
    ui.agentDebugConversation.scrollTop = ui.agentDebugConversation.scrollHeight;
    if (ui.agentDebugFeedback) ui.agentDebugFeedback.disabled = !ready || busySession;
    if (ui.sendAgentDebugFeedback) ui.sendAgentDebugFeedback.disabled = !ready || busySession || !String(ui.agentDebugFeedback.value || '').trim();
    if (ui.applyAgentDebugPrompt) ui.applyAgentDebugPrompt.disabled = !ready || busySession;
    if (ui.clearAgentDebugConversation) ui.clearAgentDebugConversation.disabled = !session || busySession;
    if (ui.runAgentDebug) ui.runAgentDebug.disabled = busySession || !ui.agentDebugTask.value || !ensureAgentSkillStore().getActive() || !deepseekCredentialConfigured;
    if (ui.agentDebugOutput) ui.agentDebugOutput.textContent = session && session.error ? `调试失败：${session.error}` : agentDebugResultJson(session && session.result);
  }

  async function importAgentSkill() {
    try {
      if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) throw new Error('当前 CEP 环境不支持文件选择器');
      const result = window.cep.fs.showOpenDialog(false, false, '导入 Prompt Skill', undefined, ['md']);
      if (!result || result.err !== 0 || !result.data || !result.data.length) return;
      ensureAgentSkillStore().importFile(result.data[0]);
      renderAgentSkillManager();
      renderAgentDebugTasks();
      setAgentProviderStatus('Skill 已导入并启用。', 'success');
    } catch (error) { setAgentProviderStatus(error.message || 'Skill 导入失败。', 'error'); }
  }

  function duplicateAgentSkill() {
    try { ensureAgentSkillStore().duplicate(ui.agentSkillSelect.value); renderAgentSkillManager(); setAgentProviderStatus('已复制为可编辑的自定义 Skill。', 'success'); }
    catch (error) { setAgentProviderStatus(error.message, 'error'); }
  }

  function saveAgentSkill() {
    try {
      ensureAgentSkillStore().update(ui.agentSkillSelect.value, ui.agentSkillEditor.value, ui.agentSkillName.value);
      renderAgentSkillManager();
      setAgentProviderStatus('Skill 已保存为新版本。', 'success');
    } catch (error) { setAgentProviderStatus(error.message, 'error'); }
  }

  function exportAgentSkill() {
    try {
      const skill = ensureAgentSkillStore().getActive();
      if (!skill) throw new Error('没有可导出的 Skill');
      const result = window.cep.fs.showOpenDialog(false, true, '选择 Skill 导出目录');
      if (!result || result.err !== 0 || !result.data || !result.data.length) return;
      const fileName = `${sanitizeFileName(skill.name)}-v${skill.version}.md`;
      ensureAgentSkillStore().exportFile(skill.id, path.join(result.data[0], fileName));
      setAgentProviderStatus(`Skill 已导出：${fileName}`, 'success');
    } catch (error) { setAgentProviderStatus(error.message, 'error'); }
  }

  async function deleteAgentSkill() {
    try {
      const skill = ensureAgentSkillStore().getActive();
      if (!skill) return;
      const confirmed = await confirmPanelAction('删除自定义 Skill', `将删除“${skill.name}”的本机副本。任务中已保存的 Skill 版本信息不会改变。`, '删除 Skill');
      if (!confirmed) return;
      ensureAgentSkillStore().remove(skill.id);
      renderAgentSkillManager();
      renderAgentDebugTasks();
    } catch (error) { setAgentProviderStatus(error.message, 'error'); }
  }

  async function runAgentDebug() {
    const job = kiviStore && kiviStore.findJob(ui.agentDebugTask.value);
    const skill = ensureAgentSkillStore().getActive();
    if (!job || !skill) return;
    const session = { jobId: job.id, result: null, messages: [], busy: true, error: '' };
    agentDebugSessions.set(job.id, session);
    renderAgentDebugConversation();
    ui.agentDebugOutput.textContent = '正在分析图片并生成结构化 Prompt…';
    try {
      const provider = await createDeepseekProvider();
      const result = await provider.generatePrompt({ imagePath: job.source.path, job, skill });
      session.result = result;
      session.messages.push({ role: 'assistant', text: result.prompt, summary: result.summary });
      setAgentProviderStatus('单任务调试完成，未写入任务 Prompt。', 'success');
    } catch (error) {
      session.error = error.message;
      setAgentProviderStatus(error.message, 'error');
    } finally { session.busy = false; renderAgentDebugConversation(); }
  }

  async function continueAgentDebugConversation() {
    const job = kiviStore && kiviStore.findJob(ui.agentDebugTask.value);
    const skill = ensureAgentSkillStore().getActive();
    const session = currentAgentDebugSession();
    const feedback = String(ui.agentDebugFeedback && ui.agentDebugFeedback.value || '').trim();
    if (!job || !skill || !session || !session.result || !feedback || session.busy) return;
    const previousHistory = session.messages.slice();
    session.messages.push({ role: 'user', text: feedback });
    session.busy = true;
    session.error = '';
    ui.agentDebugFeedback.value = '';
    renderAgentDebugConversation();
    try {
      const provider = await createDeepseekProvider();
      const result = await provider.refinePrompt({
        imagePath: job.source.path,
        job,
        skill,
        currentPrompt: session.result.prompt,
        feedback,
        history: previousHistory
      });
      session.result = result;
      session.messages.push({ role: 'assistant', text: result.prompt, summary: result.summary });
      setAgentProviderStatus('Agent 已按本轮要求调整，可继续对话或采用当前 Prompt。', 'success');
    } catch (error) {
      session.error = error.message;
      session.messages.push({ role: 'assistant', text: `本轮调整失败：${error.message}` });
      setAgentProviderStatus(error.message, 'error');
    } finally { session.busy = false; renderAgentDebugConversation(); }
  }

  function applyAgentDebugPrompt() {
    const job = kiviStore && kiviStore.findJob(ui.agentDebugTask.value);
    const skill = ensureAgentSkillStore().getActive();
    const session = currentAgentDebugSession();
    if (!job || !skill || !session || !session.result) return;
    const result = session.result;
    kiviStore.applyGeneratedPrompt(job.id, result.prompt, {
      provider: result.provider,
      model: result.model,
      skillId: skill.id,
      skillVersion: skill.version,
      skillHash: skill.hash,
      usage: result.usage,
      requestId: result.requestId,
      summary: result.summary,
      warnings: result.warnings
    });
    renderKiviWorkbench(true);
    renderAgentDebugTasks();
    setAgentProviderStatus('当前 Prompt 已写入任务，并保留原 Prompt 历史。', 'success');
  }

  function clearAgentDebugConversation() {
    const jobId = ui.agentDebugTask && ui.agentDebugTask.value;
    if (jobId) agentDebugSessions.delete(jobId);
    if (ui.agentDebugFeedback) ui.agentDebugFeedback.value = '';
    renderAgentDebugConversation();
  }

  async function sendSinglePreviewToBoard(itemId) {
    if (busy) return;
    const item = selectionItems.find(candidate => String(candidate.id) === String(itemId));
    if (!item || !previewSources.has(item.id)) {
      setStatus('该素材尚未完成预览，无法发送到 KIVI 画板。', 'error');
      return;
    }
    busy = true;
    updateButtons();
    ui.progress.classList.remove('hidden');
    ui.bar.style.width = '0%';
    let rendered = [];
    try {
      rendered = await renderFinalAssets([item]);
      await sendAssets(rendered);
      ui.bar.style.width = '100%';
      setStatus(`已将“${itemOptions.get(item.id).name}”发送至 KIVI 画板`, 'success');
    } catch (error) {
      if (!lastRetryAssets.length) rendered.forEach(asset => safeUnlink(asset.path));
      setStatus(error.message, 'error');
      if (lastRetryAssets.length) ui.retry.classList.remove('hidden');
    } finally {
      busy = false;
      ui.batchProgress.textContent = '';
      ui.progress.classList.add('hidden');
      updateButtons();
    }
  }

  function kiviStatusLabel(status) {
    return ({ draft: '草稿', generating: '生成中', review: '待筛选', accepted: '已采用', failed: '失败' })[status] || '草稿';
  }

  function promptStatusLabel(status) {
    return ({ idle: 'Prompt 未生成', queued: 'Prompt 排队', analyzing: 'Agent 分析中', ready: 'Prompt 已生成', failed: 'Prompt 失败', interrupted: 'Prompt 已中断' })[status] || 'Prompt 未生成';
  }

  function kiviJobLayerName(job) {
    return String(job && job.origin && job.origin.layer && job.origin.layer.name
      || job && job.source && job.source.layerName
      || job && job.name
      || '未命名图层');
  }

  function kiviRunStageLabel(run) {
    return ({ uploading: '上传中', submitting: '等待提交', queued: 'KIVI 排队', running: '生成中', downloading: '下载中', review: '待筛选', failed: '失败' })[run && run.stage] || '等待提交';
  }

  function kiviCandidateLabel(candidate) {
    return ({ ready: '待选择', accepted: '已采用', rejected: '已淘汰', failed: '下载失败', missing: '文件缺失' })[candidate && candidate.status] || '待选择';
  }

  function updateKiviCountdowns() {
    if (!ui.kiviJobDetail) return;
    const now = Date.now();
    ui.kiviJobDetail.querySelectorAll('[data-kivi-countdown-start]').forEach(element => {
      const elapsed = Math.floor((now - Number(element.dataset.kiviCountdownStart || now)) / 1000);
      const remaining = Math.max(0, 170 - Math.max(0, elapsed));
      element.textContent = remaining > 0 ? `${remaining}s` : '处理中';
    });
  }

  function ensureKiviCountdownTicker() {
    updateKiviCountdowns();
    if (!kiviCountdownTimer) kiviCountdownTimer = window.setInterval(updateKiviCountdowns, 1000);
  }

  function visibleKiviJobs() {
    if (!kiviStore) return [];
    const filter = ui.kiviJobFilter ? ui.kiviJobFilter.value : 'all';
    const jobs = kiviStore.state.jobs.filter(job => {
      if ((kiviQueueView === 'archive') !== !!job.archivedAt) return false;
      const status = deriveJobStatus(job);
      if (filter !== 'all' && status !== filter) return false;
      return true;
    });
    return sortJobs(jobs, ui.kiviJobSort ? ui.kiviJobSort.value : 'recent');
  }

  function firstKiviJobInView() {
    const jobs = visibleKiviJobs();
    return jobs.length ? jobs[0] : null;
  }

  function archiveKiviJob(job) {
    if (!job || job.archivedAt || deriveJobStatus(job) === 'generating' || ['queued', 'analyzing'].includes(job.promptState && job.promptState.status)) return;
    kiviStore.archiveJob(job.id);
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
    setKiviVideoStatus(`“${job.name}”已移入草稿箱，可随时恢复。`, 'success');
  }

  function restoreKiviJob(job) {
    if (!job || !job.archivedAt) return;
    kiviStore.restoreJob(job.id);
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
    setKiviVideoStatus(`“${job.name}”已恢复到任务队列。`, 'success');
  }

  async function archiveAllKiviJobs() {
    const jobs = kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt && deriveJobStatus(job) !== 'generating' && !['queued', 'analyzing'].includes(job.promptState && job.promptState.status)) : [];
    if (!jobs.length) return setKiviVideoStatus('当前没有可移入草稿箱的任务。');
    const confirmed = await confirmPanelAction('清除任务面板', `将 ${jobs.length} 个任务移入草稿箱。Prompt、候选视频、来源和历史记录都会保留，可在“草稿箱”中恢复。正在生成的任务不会移动。`, '移入草稿箱', { warningText: '任务可在草稿箱中恢复' });
    if (!confirmed) return;
    const count = kiviStore.archiveJobs(jobs.map(job => job.id));
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
    setKiviVideoStatus(`已将 ${count} 个任务移入草稿箱。`, 'success');
  }

  function restoreAllArchivedJobs() {
    const jobs = kiviStore ? kiviStore.state.jobs.filter(job => job.archivedAt) : [];
    if (!jobs.length) return;
    const count = kiviStore.restoreJobs(jobs.map(job => job.id));
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
    setKiviVideoStatus(`已恢复 ${count} 个任务。`, 'success');
  }

  async function permanentlyDeleteArchivedJobs(jobs) {
    const removable = (jobs || []).filter(job => job && job.archivedAt && deriveJobStatus(job) !== 'generating');
    if (!removable.length) return setKiviVideoStatus('草稿箱中没有可永久删除的任务。');
    const confirmed = await confirmPanelAction('永久删除任务', `将永久删除 ${removable.length} 个草稿箱任务及其任务工作区文件，此操作不可恢复。已加入素材库的副本和已经添加到 AE 项目的合成不会被删除。`, '永久删除');
    if (!confirmed) return;
    const count = kiviStore.removeJobs(removable.map(job => job.id));
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
    setKiviVideoStatus(`已永久删除 ${count} 个草稿箱任务；素材库与 AE 合成保持不变。`, 'success');
  }

  function duplicateKiviJob(job) {
    if (!job || deriveJobStatus(job) === 'generating') throw new Error('生成中的任务不能复制');
    const duplicate = kiviStore.duplicateJob(job.id);
    selectedKiviJobId = duplicate.id;
    renderKiviWorkbench();
    setKiviVideoStatus('已复制任务方案，可独立修改提示词和参数。', 'success');
  }

  function renderKiviJobList() {
    if (!ui.kiviJobList) return;
    const jobs = visibleKiviJobs();
    const activeJobs = kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt) : [];
    const archivedJobs = kiviStore ? kiviStore.state.jobs.filter(job => job.archivedAt) : [];
    const total = kiviQueueView === 'archive' ? archivedJobs.length : activeJobs.length;
    if (ui.kiviJobCount) ui.kiviJobCount.textContent = `${jobs.length} / ${total} 项`;
    if (ui.kiviArchiveCount) ui.kiviArchiveCount.textContent = archivedJobs.length;
    if (ui.kiviQueueTab) {
      ui.kiviQueueTab.classList.toggle('active', kiviQueueView === 'queue');
      ui.kiviQueueTab.setAttribute('aria-selected', String(kiviQueueView === 'queue'));
    }
    if (ui.kiviArchiveTab) {
      ui.kiviArchiveTab.classList.toggle('active', kiviQueueView === 'archive');
      ui.kiviArchiveTab.setAttribute('aria-selected', String(kiviQueueView === 'archive'));
    }
    if (ui.archiveAllKiviJobs) ui.archiveAllKiviJobs.classList.toggle('hidden', kiviQueueView !== 'queue');
    if (ui.purgeUnusedKiviMedia) ui.purgeUnusedKiviMedia.classList.toggle('hidden', kiviQueueView !== 'queue');
    if (ui.restoreAllArchivedJobs) ui.restoreAllArchivedJobs.classList.toggle('hidden', kiviQueueView !== 'archive');
    if (ui.deleteAllArchivedJobs) ui.deleteAllArchivedJobs.classList.toggle('hidden', kiviQueueView !== 'archive');
    if (ui.kiviSelectAll) {
      const selectedCount = jobs.filter(job => job.selected).length;
      ui.kiviSelectAll.disabled = kiviQueueView === 'archive';
      ui.kiviSelectAll.checked = kiviQueueView === 'queue' && jobs.length > 0 && selectedCount === jobs.length;
      ui.kiviSelectAll.indeterminate = kiviQueueView === 'queue' && selectedCount > 0 && selectedCount < jobs.length;
    }
    if (!jobs.length) {
      ui.kiviJobList.innerHTML = `<div class="kivi-empty">${kiviQueueView === 'archive' ? '草稿箱为空。移入草稿箱的任务会保留 Prompt、候选和来源信息。' : activeJobs.length ? '当前筛选条件没有任务。' : '任务队列为空，请先添加当前排版。'}</div>`;
      updateButtons();
      return;
    }
    ui.kiviJobList.innerHTML = jobs.map(job => {
      const status = deriveJobStatus(job);
      const promptStatus = job.promptState && job.promptState.status || 'idle';
      const candidateCount = (job.runs || []).reduce((count, run) => count + (run.candidates || []).filter(candidate => candidate.status !== 'failed').length, 0);
      const layerName = kiviJobLayerName(job);
      const archived = !!job.archivedAt;
      return `<div class="kivi-job-row${job.id === selectedKiviJobId ? ' active' : ''}${archived ? ' archived' : ''}" data-kivi-job="${job.id}" tabindex="0" role="button" aria-label="打开任务 ${escapeHtml(job.name)}" title="${escapeHtml(job.name)}${archived ? ' · 草稿箱任务' : ' · 右键复制方案'}">
        ${archived ? '<span class="kivi-job-archive-mark" aria-hidden="true">•</span>' : `<input type="checkbox" data-kivi-select-job="${job.id}"${job.selected ? ' checked' : ''} aria-label="选择任务 ${escapeHtml(job.name)}">`}
        <img src="${fileUrl(job.source.path)}" alt="">
        <div class="kivi-job-row-main">
          <div class="kivi-job-row-title" title="${escapeHtml(layerName)}">${escapeHtml(layerName)}</div>
          <div class="kivi-job-row-meta"><span>${job.mode === 'general_reference' ? '参考' : '首尾'} · ${candidateCount}</span><span class="kivi-job-status ${status}">${kiviStatusLabel(status)}</span><span class="kivi-agent-status ${promptStatus}">${promptStatusLabel(promptStatus)}</span></div>
        </div><button class="kivi-job-delete" data-kivi-delete-job="${job.id}" title="${archived ? '恢复任务' : '移入草稿箱'}" aria-label="${archived ? '恢复任务' : '移入草稿箱'}"${status === 'generating' ? ' disabled' : ''}>${archived ? '↩' : '×'}</button>
      </div>`;
    }).join('');
    ui.kiviJobList.querySelectorAll('[data-kivi-job]').forEach(row => {
      const select = () => { selectedKiviJobId = row.dataset.kiviJob; renderKiviWorkbench(); };
      row.addEventListener('click', event => { if (!event.target.closest('[data-kivi-select-job],[data-kivi-delete-job]')) select(); });
      row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); select(); } });
      row.addEventListener('contextmenu', event => {
        const job = kiviStore.findJob(row.dataset.kiviJob);
        const actions = job && job.archivedAt
          ? [{ label: '恢复到任务队列', run: () => restoreKiviJob(job) }, { label: '永久删除', run: () => permanentlyDeleteArchivedJobs([job]) }]
          : [{ label: '复制任务方案', disabled: !job || deriveJobStatus(job) === 'generating', run: () => duplicateKiviJob(job) }, { label: '移入草稿箱', disabled: !job || deriveJobStatus(job) === 'generating', run: () => archiveKiviJob(job) }];
        showPanelContextMenu(event, actions);
      });
    });
    ui.kiviJobList.querySelectorAll('[data-kivi-select-job]').forEach(input => input.addEventListener('change', event => {
      event.stopPropagation();
      const job = kiviStore.findJob(input.dataset.kiviSelectJob);
      if (job) { job.selected = input.checked; job.updatedAt = Date.now(); kiviStore.save(); }
      renderKiviJobList();
    }));
    ui.kiviJobList.querySelectorAll('[data-kivi-delete-job]').forEach(button => button.addEventListener('click', event => {
      event.stopPropagation();
      const job = kiviStore.findJob(button.dataset.kiviDeleteJob);
      if (job && job.archivedAt) restoreKiviJob(job);
      else archiveKiviJob(job);
    }));
    updateButtons();
  }

  function kiviRunResultsHtml(job) {
    if (!job.runs || !job.runs.length) return '<div class="kivi-empty">尚未生成。完成提示词和参数后，可生成当前任务或批量生成所选任务。</div>';
    const candidates = [];
    const placeholders = [];
    const errors = [];
    job.runs.forEach((run, runIndex) => {
      if (['uploading', 'submitting', 'queued', 'running', 'downloading'].includes(run.status)) {
        const count = Math.max(1, Math.min(2, Number(run.settings && run.settings.outputCount) || 1));
        for (let index = 0; index < count; index += 1) placeholders.push({ run, runNumber: runIndex + 1, index });
      }
      if (run.status === 'failed' && !(run.candidates || []).length) {
        errors.push(`<div class="kivi-run-error"><strong>第 ${runIndex + 1} 轮失败：</strong>${escapeHtml(run.error || '生成失败，可按当前设置重新生成。')}</div>`);
      }
      (run.candidates || []).forEach(candidate => candidates.push({ run, runNumber: runIndex + 1, candidate }));
    });
    candidates.sort((a, b) => Number(b.candidate.sequence || 0) - Number(a.candidate.sequence || 0));
    const placeholderCard = item => `<article class="kivi-candidate placeholder" aria-label="候选视频正在生成">
      <div class="kivi-placeholder-media"><img src="${fileUrl(job.source.path)}" alt=""><span class="kivi-countdown" data-kivi-countdown-start="${Number(item.run.createdAt) || Date.now()}">170s</span></div>
      <div class="kivi-candidate-body"><div class="kivi-candidate-state"><strong>生成占位 ${item.index + 1}/${Math.max(1, Number(item.run.settings && item.run.settings.outputCount) || 1)}</strong><span class="kivi-placeholder-stage">${escapeHtml(kiviRunStageLabel(item.run))}</span></div><div class="kivi-candidate-meta">第 ${item.runNumber} 轮 · 预计时间提示，完成后自动替换</div></div>
    </article>`;
    const card = item => {
      const run = item.run;
      const candidate = item.candidate;
      const playbackPath = candidate.localPath && fs.existsSync(candidate.localPath)
        ? candidate.localPath
        : candidate.acceptedPath && fs.existsSync(candidate.acceptedPath) ? candidate.acceptedPath : '';
      const exists = !!playbackPath;
      const number = `C${String(Number(candidate.sequence) || 0).padStart(3, '0')}`;
      const preview = exists ? `<video src="${fileUrl(playbackPath)}" controls preload="metadata" muted playsinline></video>` : `<div class="kivi-empty">${escapeHtml(candidate.error || '等待结果')}</div>`;
      const taskMeta = run.taskId ? ` · ${escapeHtml(String(run.taskId))}` : '';
      return `<article class="kivi-candidate ${candidate.status}" data-kivi-candidate="${candidate.id}" data-kivi-run="${run.id}" title="右键在资源管理器中定位">
        <div class="kivi-candidate-media">${preview}<button class="kivi-loop-overlay" data-kivi-loop="${candidate.id}" data-kivi-run="${run.id}"${!exists ? ' disabled' : ''}>${kiviLoopDurationLabel()}</button></div>
        <div class="kivi-candidate-body">
          <div class="kivi-candidate-state"><strong>候选 ${number}</strong><span>${escapeHtml(kiviCandidateLabel(candidate))}</span></div>
          <div class="kivi-candidate-meta">第 ${item.runNumber} 轮 · ${run.mode === 'general_reference' ? '智能参考' : '首尾帧'}${taskMeta}</div>
          <div class="kivi-candidate-actions">
            <button class="primary" data-kivi-origin="${candidate.id}" data-kivi-run="${run.id}"${!exists || candidate.status === 'rejected' ? ' disabled' : ''}>加入原始</button>
            <button class="secondary" data-kivi-origin-manual="${candidate.id}" data-kivi-run="${run.id}"${!exists || candidate.status === 'rejected' ? ' disabled' : ''}>手动替换</button>
            <button class="secondary" data-kivi-accept="${candidate.id}" data-kivi-run="${run.id}"${!exists || candidate.status === 'accepted' || candidate.status === 'rejected' ? ' disabled' : ''}>${candidate.status === 'accepted' ? '已加入素材' : '加入素材'}</button>
            <button class="secondary" data-kivi-reject="${candidate.id}" data-kivi-run="${run.id}"${!exists ? ' disabled' : ''}>${candidate.status === 'rejected' ? '恢复' : '淘汰'}</button>
            <button class="secondary" data-kivi-rerun="${job.id}">再生成</button>
          </div>
        </div>
      </article>`;
    };
    const available = candidates.filter(item => item.candidate.status !== 'rejected' && item.candidate.status !== 'failed');
    const rejected = candidates.filter(item => item.candidate.status === 'rejected');
    const lane = (title, items, rejectedLane) => `<section class="kivi-result-lane${rejectedLane ? ' rejected-lane' : ''}">
      <div class="kivi-lane-header"><span>${title} <strong>${items.length + (rejectedLane ? 0 : placeholders.length)}</strong></span>${rejectedLane && items.length ? '<button class="secondary kivi-danger" data-kivi-purge-rejected>清理全部淘汰</button>' : ''}</div>
      <div class="kivi-candidate-strip">${!rejectedLane ? placeholders.map(placeholderCard).join('') : ''}${items.length ? items.map(card).join('') : (!placeholders.length || rejectedLane ? `<div class="kivi-lane-empty">${rejectedLane ? '没有已淘汰的视频' : '暂无可筛选候选'}</div>` : '')}</div>
    </section>`;
    return `${lane('可用候选', available, false)}${lane('已淘汰', rejected, true)}${errors.join('')}`;
  }

  function kiviModelOptions(selectedModel) {
    const selected = String(selectedModel || 'seedance-2.0');
    const models = kiviVideoModels.slice();
    if (!models.some(model => model.name === selected)) {
      models.unshift({ name: selected, label: selected, tags: '', description: '', priority: -1 });
    }
    return models.map(model => {
      const details = [model.tags, model.description].filter(Boolean).join(' · ');
      return `<option value="${escapeHtml(model.name)}"${model.name === selected ? ' selected' : ''}${details ? ` title="${escapeHtml(details)}"` : ''}>${escapeHtml(model.label)}</option>`;
    }).join('');
  }

  async function refreshKiviVideoModels(force) {
    if (kiviVideoModelsLoaded && !force) return kiviVideoModels;
    if (kiviVideoModelsLoading) return kiviVideoModelsLoading;
    kiviVideoModelsLoading = (async () => {
      try {
        if (!kiviRunner) return kiviVideoModels;
        const client = await kiviRunner.client();
        const models = await client.listVideoModels();
        if (models.length) kiviVideoModels = models;
        kiviVideoModelsLoaded = true;
        renderKiviWorkbench(true);
      } catch (_) {
        kiviVideoModels = fallbackKiviVideoModels.slice();
      }
      return kiviVideoModels;
    })();
    try { return await kiviVideoModelsLoading; }
    finally { kiviVideoModelsLoading = null; }
  }

  function renderKiviJobDetail() {
    if (!ui.kiviJobDetail || !kiviStore) return;
    let job = kiviStore.findJob(selectedKiviJobId);
    if (job && ((kiviQueueView === 'archive') !== !!job.archivedAt)) job = null;
    if (!job) {
      const next = firstKiviJobInView();
      if (next) { selectedKiviJobId = next.id; job = next; }
    }
    if (!job) {
      ui.kiviJobDetail.innerHTML = `<div class="kivi-empty">${kiviQueueView === 'archive' ? '草稿箱中没有任务。' : '从任务队列选择一个任务。'}</div>`;
      return;
    }
    const archived = !!job.archivedAt;
    const status = deriveJobStatus(job);
    const generating = status === 'generating';
    const promptState = job.promptState || { status: 'idle' };
    const promptBusy = ['queued', 'analyzing'].includes(promptState.status);
    const hasPrompt = !!String(job.prompt || '').trim();
    const agentAvailable = deepseekCredentialConfigured && !!(agentSkillStore && agentSkillStore.getActive());
    const settings = job.settings;
    const selectOptions = (values, selected) => values.map(value => `<option value="${value}"${String(value) === String(selected) ? ' selected' : ''}>${value}${value === 4 || value === 5 || value === 8 || value === 10 ? ' 秒' : ''}</option>`).join('');
    const ratioControl = job.mode === 'flf2v'
      ? `<label>比例（跟随首帧）<select id="kiviJobRatio" disabled title="首尾帧生成的输出比例由首帧图片决定"><option value="${escapeHtml(settings.ratio)}" selected>跟随首帧</option></select></label>`
      : `<label>比例<select id="kiviJobRatio">${selectOptions(['1:1', '16:9', '9:16', '4:3', '3:4'], settings.ratio)}</select></label>`;
    const promptMeta = promptState.status === 'ready'
      ? `${escapeHtml(promptState.provider || 'Agent')} · ${escapeHtml(promptState.model || '')} · Skill v${Number(promptState.skillVersion) || 1}${promptState.usage && promptState.usage.total_tokens ? ` · ${Number(promptState.usage.total_tokens)} tokens` : ''}`
      : promptStatusLabel(promptState.status);
    const historyOptions = (job.promptHistory || []).slice().reverse().map(entry => `<option value="${escapeHtml(entry.id)}">${new Date(entry.createdAt).toLocaleString()} · ${entry.source === 'agent' ? 'Agent' : entry.source === 'restore-backup' ? '恢复备份' : '手动'} · ${escapeHtml(String(entry.text || '').replace(/\s+/g, ' ').slice(0, 42))}</option>`).join('');
    const sourceActions = archived
      ? `<button id="restoreCurrentKiviJob" class="primary">恢复任务</button><button id="deleteCurrentKiviJobPermanently" class="secondary kivi-danger">永久删除</button>`
      : `<button id="generateCurrentKiviJob" class="primary"${generating || promptBusy || !hasPrompt ? ' disabled' : ''} title="${!hasPrompt ? '请先填写或生成 Prompt' : ''}">${generating ? '视频生成中' : '生成视频'}</button><button id="generateCurrentPrompt" class="secondary"${promptBusy || !agentAvailable ? ' disabled' : ''} title="${!agentAvailable ? '请先在 Agent 调试中配置 DeepSeek Key 并启用 Skill' : ''}">${promptBusy ? 'Agent 分析中' : '生成 Prompt'}</button><button id="deleteCurrentKiviJob" class="secondary kivi-danger"${generating || promptBusy ? ' disabled' : ''}>移入草稿箱</button>`;
    ui.kiviJobDetail.innerHTML = `<div class="kivi-detail${archived ? ' archived' : ''}">
      <div class="kivi-detail-setup">
        <div class="kivi-detail-source-column"><img class="kivi-detail-source" src="${fileUrl(job.source.path)}" alt="${escapeHtml(job.name)}"><div class="kivi-source-actions">${sourceActions}</div></div>
        <div class="kivi-detail-editor">
          <div class="kivi-detail-header"><div class="kivi-detail-title"><h2 title="${escapeHtml(job.name)}">${escapeHtml(job.name)}</h2><div class="kivi-detail-meta">${job.source.width} × ${job.source.height} · ${new Date(job.createdAt).toLocaleString()}</div></div><div class="kivi-mode-switch" aria-label="视频生成模式"><button data-kivi-mode="flf2v" class="${job.mode === 'flf2v' ? 'active' : ''}">首尾帧</button><button data-kivi-mode="general_reference" class="${job.mode === 'general_reference' ? 'active' : ''}">智能参考</button></div></div>
          <div class="kivi-parameter-grid">
            <label>模型<select id="kiviJobModel">${kiviModelOptions(settings.model)}</select></label>
            ${ratioControl}
            <label>分辨率<select id="kiviJobResolution">${selectOptions(['720P', '1080P'], settings.resolution)}</select></label>
            <label>时长<select id="kiviJobDuration">${selectOptions([4, 5, 8, 10], settings.duration)}</select></label>
            <label>候选数<select id="kiviJobOutputCount">${selectOptions([1, 2], settings.outputCount)}</select></label>
          </div>
          <div class="kivi-editor">
            <label>提示词<textarea id="kiviJobPrompt" placeholder="描述这张图片需要怎样运动"${archived ? ' readonly' : ''}>${escapeHtml(job.prompt)}</textarea></label>
            <div id="kiviPromptResizer" class="vertical-resizer prompt-resizer" role="separator" aria-label="调整提示词区域高度" title="拖动调整提示词区域高度"></div>
            <div class="kivi-prompt-meta"><span title="${escapeHtml(promptMeta)}">${promptMeta}</span>${promptState.generatedAt ? `<time>${new Date(promptState.generatedAt).toLocaleString()}</time>` : ''}</div>
            ${historyOptions ? `<div class="kivi-prompt-history"><select id="kiviPromptHistory"><option value="">历史版本（${job.promptHistory.length}）</option>${historyOptions}</select><button id="restoreKiviPrompt" class="secondary" disabled>恢复</button></div>` : ''}
            ${promptState.error ? `<div class="kivi-prompt-error">${escapeHtml(promptState.error)}</div>` : ''}
          </div>
        </div>
      </div>
      <div class="kivi-results-heading"><strong>生成结果 <span id="kiviResultZoomValue" class="zoom-readout" title="Ctrl + 滚轮缩放">${Math.round(kiviResultZoom * 100)}%</span></strong><span class="kivi-job-status ${status}">${kiviStatusLabel(status)}</span></div>
      <div class="kivi-results">${kiviRunResultsHtml(job)}</div>
    </div>`;
    applyKiviResultZoom();
    ensureKiviCountdownTicker();
    bindKiviJobDetail(job);
  }

  function renderKiviWorkbench(preserveEditor) {
    renderKiviJobList();
    const editing = preserveEditor && document.activeElement && document.activeElement.closest && document.activeElement.closest('.kivi-editor');
    const playingVideo = preserveEditor && ui.kiviJobDetail && Array.from(ui.kiviJobDetail.querySelectorAll('video')).some(video => !video.paused);
    if (!editing && !playingVideo) renderKiviJobDetail();
    renderAgentDebugTasks();
  }

  function saveKiviEditor(job) {
    if (!job || !kiviStore) return;
    const prompt = $('kiviJobPrompt');
    const model = $('kiviJobModel');
    const ratio = $('kiviJobRatio');
    const resolution = $('kiviJobResolution');
    const duration = $('kiviJobDuration');
    const outputCount = $('kiviJobOutputCount');
    if (prompt) job.prompt = prompt.value;
    if (model) job.settings.model = model.value;
    if (ratio) job.settings.ratio = ratio.value;
    if (resolution) job.settings.resolution = resolution.value;
    if (duration) job.settings.duration = Number(duration.value) || 4;
    if (outputCount) job.settings.outputCount = Math.max(1, Math.min(2, Number(outputCount.value) || 1));
    job.updatedAt = Date.now();
    kiviStore.save();
    renderKiviJobList();
  }

  function findKiviCandidate(job, runId, candidateId) {
    const run = job && (job.runs || []).find(item => item.id === runId);
    const candidate = run && (run.candidates || []).find(item => item.id === candidateId);
    return { run, candidate };
  }

  function kiviCandidateFile(candidate) {
    if (candidate && candidate.localPath && fs.existsSync(candidate.localPath)) return candidate.localPath;
    if (candidate && candidate.acceptedPath && fs.existsSync(candidate.acceptedPath)) return candidate.acceptedPath;
    return '';
  }

  async function ensureAcceptedCandidateCopy(job, found) {
    if (!found || !found.candidate) throw new Error('候选视频不存在');
    let target = found.candidate.acceptedPath;
    if (!target || !fs.existsSync(target)) {
      const sourcePath = found.candidate.localPath;
      if (!sourcePath || !fs.existsSync(sourcePath)) throw new Error('候选视频文件不存在');
      const root = await defaultImportDirectory();
      const directory = path.join(root, 'Kivi Videos');
      ensureDirectory(directory);
      const candidateNumber = `C${String(Number(found.candidate.sequence) || 0).padStart(3, '0')}`;
      target = uniquePath(directory, `${sanitizeFileName(job.name)}-${candidateNumber}.mp4`);
      fs.copyFileSync(sourcePath, target);
    }
    const stat = fs.statSync(target);
    upsertImportHistory({
      localPath: target,
      fileName: path.basename(target),
      displayName: path.basename(target),
      mimeType: 'video/mp4',
      nodeType: 'video',
      format: 'video',
      folderName: 'Kivi Videos',
      byteSize: stat.size,
      at: Date.now(),
      importedAt: Date.now(),
      taskId: String(found.run && found.run.taskId || ''),
      kiviJobId: job.id,
      kiviJobName: job.name,
      kiviCandidateId: found.candidate.id,
      kiviCandidateLabel: `候选 C${String(Number(found.candidate.sequence) || 0).padStart(3, '0')}`,
      origin: job.origin ? JSON.parse(JSON.stringify(job.origin)) : null
    });
    saveImportHistory();
    found.candidate.acceptedPath = target;
    found.candidate.status = 'accepted';
    if (!found.candidate.acceptedAt) found.candidate.acceptedAt = Date.now();
    found.candidate.rejectedAt = 0;
    job.updatedAt = Date.now();
    kiviStore.save();
    return target;
  }

  async function addKiviCandidateToOrigin(job, runId, candidateId, manualSelection) {
    const found = findKiviCandidate(job, runId, candidateId);
    if (!found.candidate || !kiviCandidateFile(found.candidate)) throw new Error('候选视频文件不存在');
    const filePath = await ensureAcceptedCandidateCopy(job, found);
    let origin = job.origin;
    if (!origin || !origin.projectPath) {
      if (!manualSelection) throw new Error('该任务没有原始合成来源信息；请选中时间线目标图层后使用“手动替换”恢复');
      origin = await selectedOriginForRecovery(job, filePath);
    }
    const number = `C${String(Number(found.candidate.sequence) || 0).padStart(3, '0')}`;
    const payload = {
      jobId: job.id,
      jobName: job.name,
      candidateId: found.candidate.id,
      candidateLabel: `候选 ${number}`,
      filePath,
      origin,
      manualSelection: !!manualSelection,
      loopDuration: kiviAdoptionDuration
    };
    const method = manualSelection ? 'addKiviCandidateToSelectedLayer' : 'addKiviCandidateToOrigin';
    const raw = await evalScript(`CanvasBridge.${method}(${quote(JSON.stringify(payload))})`);
    const result = parseEvalJson(raw, manualSelection ? '手动替换原始' : '加入原始合成');
    if (!result.ok) throw new Error(result.error);
    found.candidate.addedToOriginAt = Date.now();
    if (result.origin) persistRecoveredOrigin(job, result.origin);
    job.updatedAt = Date.now();
    kiviStore.save();
    renderKiviWorkbench();
    setKiviVideoStatus(`${result.reused ? '已切换' : '已加入'}${manualSelection ? '所选原始图层' : '原始合成'}：候选 ${number}`, 'success');
  }

  async function acceptKiviCandidate(job, runId, candidateId) {
    const found = findKiviCandidate(job, runId, candidateId);
    if (!found.candidate || !found.candidate.localPath || !fs.existsSync(found.candidate.localPath)) throw new Error('候选视频文件不存在');
    await ensureAcceptedCandidateCopy(job, found);
    renderKiviWorkbench();
    setKiviVideoStatus(`已采用“${job.name}”的候选视频，并加入“素材库”。`, 'success');
  }

  async function purgeRejectedKiviCandidates(job) {
    const rejected = [];
    for (const run of job.runs || []) {
      for (const candidate of run.candidates || []) if (candidate.status === 'rejected') rejected.push({ run, candidate });
    }
    if (!rejected.length) return;
    const confirmed = await confirmPanelAction('永久清理淘汰视频', `将删除 ${rejected.length} 个淘汰视频的本地原始文件，并同步移除 AE 项目素材和素材库记录。`, '永久删除', { allowSuppress: true, suppressionKey: 'destructive-delete' });
    if (!confirmed) {
      setKiviVideoStatus('已取消清理淘汰视频。');
      return;
    }
    const payload = { candidates: rejected.map(item => ({
      id: item.candidate.id,
      paths: [...new Set([item.candidate.localPath, item.candidate.acceptedPath].filter(Boolean))]
    })) };
    const raw = await evalScript(`CanvasBridge.removeKiviCandidateEverywhere(${quote(JSON.stringify(payload))})`);
    const result = parseEvalJson(raw, '清理 AE 淘汰视频');
    if (!result.ok) throw new Error(result.error);
    const removedIds = new Set();
    const failures = [];
    for (const item of rejected) {
      let failed = '';
      for (const filePath of [...new Set([item.candidate.localPath, item.candidate.acceptedPath].filter(Boolean))]) {
        try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); }
        catch (error) { failed = `${path.basename(filePath)}：${error.message}`; }
      }
      if (failed) {
        item.candidate.error = `清理未完成：${failed}`;
        failures.push(failed);
      } else removedIds.add(item.candidate.id);
    }
    for (const run of job.runs || []) run.candidates = (run.candidates || []).filter(candidate => !removedIds.has(candidate.id));
    importHistory = importHistory.filter(item => !removedIds.has(item.kiviCandidateId));
    saveImportHistory();
    job.updatedAt = Date.now();
    kiviStore.save();
    renderKiviWorkbench();
    if (failures.length) throw new Error(`已清理 ${removedIds.size} 个，${failures.length} 个文件被占用：${failures.join('；')}`);
    setKiviVideoStatus(`已永久清理 ${removedIds.size} 个淘汰视频，并移除 ${result.removedLayers || 0} 个 AE 图层、${result.removedItems || 0} 个项目素材。`, 'success');
  }

  async function purgeUnusedKiviMedia() {
    if (!kiviStore) return;
    const libraryCandidateIds = new Set(importHistory.map(item => String(item.kiviCandidateId || '')).filter(Boolean));
    const candidates = [];
    for (const job of kiviStore.state.jobs) {
      for (const run of job.runs || []) {
        for (const candidate of run.candidates || []) {
          if (!['ready', 'rejected'].includes(candidate.status)) continue;
          if (candidate.acceptedPath || candidate.addedToOriginAt || libraryCandidateIds.has(String(candidate.id))) continue;
          if (!candidate.localPath || !fs.existsSync(candidate.localPath)) continue;
          candidates.push({ job, run, candidate });
        }
      }
    }
    if (!candidates.length) return setKiviVideoStatus('没有可清理的未用候选视频。');
    const inspectionRaw = await evalScript(`CanvasBridge.inspectKiviCandidateReferences(${quote(JSON.stringify({ candidates: candidates.map(item => ({ id: item.candidate.id, paths: [item.candidate.localPath, item.candidate.acceptedPath].filter(Boolean) })) }))})`);
    const inspection = parseEvalJson(inspectionRaw, '检查 AE 候选引用');
    if (!inspection.ok) throw new Error(inspection.error);
    const referencedIds = new Set((inspection.referencedIds || []).map(String));
    const unused = candidates.filter(item => !referencedIds.has(String(item.candidate.id)));
    if (!unused.length) return setKiviVideoStatus('候选视频均已在 AE 合成中使用，没有可清理内容。');
    const confirmed = await confirmPanelAction('清除未用素材', `将永久删除 ${unused.length} 个未加入合成、未进入素材库的待筛选或已淘汰视频。已采用素材和 AE 合成中的视频不会受影响。`, '永久清理');
    if (!confirmed) return;
    const payload = { candidates: unused.map(item => ({ id: item.candidate.id, paths: [item.candidate.localPath].filter(Boolean) })) };
    const raw = await evalScript(`CanvasBridge.removeKiviCandidateEverywhere(${quote(JSON.stringify(payload))})`);
    const result = parseEvalJson(raw, '清除未用素材');
    if (!result.ok) throw new Error(result.error);
    const removedIds = new Set();
    const failures = [];
    for (const item of unused) {
      try {
        if (item.candidate.localPath && fs.existsSync(item.candidate.localPath)) fs.unlinkSync(item.candidate.localPath);
        removedIds.add(item.candidate.id);
      } catch (error) {
        item.candidate.error = `清理未完成：${error.message}`;
        failures.push(`${path.basename(item.candidate.localPath)}：${error.message}`);
      }
    }
    for (const job of kiviStore.state.jobs) {
      for (const run of job.runs || []) run.candidates = (run.candidates || []).filter(candidate => !removedIds.has(candidate.id));
      job.updatedAt = Date.now();
    }
    importHistory = importHistory.filter(item => !removedIds.has(item.kiviCandidateId));
    saveImportHistory();
    kiviStore.save();
    renderKiviWorkbench();
    if (failures.length) throw new Error(`已清理 ${removedIds.size} 个，${failures.length} 个文件被占用：${failures.join('；')}`);
    setKiviVideoStatus(`已清理 ${removedIds.size} 个未用候选视频；跳过 ${referencedIds.size} 个 AE 已引用视频。`, 'success');
  }

  function bindKiviJobDetail(job) {
    let promptTimer = null;
    const prompt = $('kiviJobPrompt');
    const promptResizer = $('kiviPromptResizer');
    bindVerticalResizer(promptResizer, prompt, 'canvasBridgeKiviPromptHeight', 190, 120, 520);
    if (job.archivedAt) {
      const restoreArchived = $('restoreCurrentKiviJob');
      const deleteArchived = $('deleteCurrentKiviJobPermanently');
      if (restoreArchived) restoreArchived.addEventListener('click', () => restoreKiviJob(job));
      if (deleteArchived) deleteArchived.addEventListener('click', () => permanentlyDeleteArchivedJobs([job]).catch(error => setKiviVideoStatus(error.message, 'error')));
      return;
    }
    if (prompt) prompt.addEventListener('input', () => {
      const value = prompt.value;
      clearTimeout(promptTimer);
      promptTimer = setTimeout(() => {
        kiviStore.markPromptManual(job.id, value);
        renderKiviJobList();
      }, 350);
    });
    if (prompt) prompt.addEventListener('change', () => {
      clearTimeout(promptTimer);
      kiviStore.markPromptManual(job.id, prompt.value);
      renderKiviJobList();
    });
    ['kiviJobModel', 'kiviJobRatio', 'kiviJobResolution', 'kiviJobDuration', 'kiviJobOutputCount'].forEach(id => {
      const control = $(id);
      if (control) control.addEventListener('change', () => saveKiviEditor(job));
    });
    ui.kiviJobDetail.querySelectorAll('[data-kivi-mode]').forEach(button => button.addEventListener('click', () => {
      job.mode = button.dataset.kiviMode === 'general_reference' ? 'general_reference' : 'flf2v';
      job.updatedAt = Date.now();
      kiviStore.save();
      renderKiviWorkbench();
    }));
    const generate = $('generateCurrentKiviJob');
    if (generate) generate.addEventListener('click', () => generateKiviJobs([job.id]));
    const generatePrompt = $('generateCurrentPrompt');
    if (generatePrompt) generatePrompt.addEventListener('click', () => generateAgentPrompts([job.id], false));
    const remove = $('deleteCurrentKiviJob');
    if (remove) remove.addEventListener('click', () => archiveKiviJob(job));
    const history = $('kiviPromptHistory');
    const restore = $('restoreKiviPrompt');
    if (history && restore) {
      history.addEventListener('change', () => { restore.disabled = !history.value; });
      restore.addEventListener('click', () => {
        try {
          if (!history.value) return;
          kiviStore.restorePrompt(job.id, history.value);
          renderKiviWorkbench();
          setKiviVideoStatus('已恢复 Prompt 历史版本。', 'success');
        } catch (error) { setKiviVideoStatus(error.message, 'error'); }
      });
    }
    ui.kiviJobDetail.querySelectorAll('[data-kivi-accept]').forEach(button => button.addEventListener('click', () => {
      acceptKiviCandidate(job, button.dataset.kiviRun, button.dataset.kiviAccept).catch(error => setKiviVideoStatus(error.message, 'error'));
    }));
    ui.kiviJobDetail.querySelectorAll('[data-kivi-origin]').forEach(button => button.addEventListener('click', () => {
      addKiviCandidateToOrigin(job, button.dataset.kiviRun, button.dataset.kiviOrigin, false).catch(error => setKiviVideoStatus(error.message, 'error'));
    }));
    ui.kiviJobDetail.querySelectorAll('[data-kivi-origin-manual]').forEach(button => button.addEventListener('click', () => {
      addKiviCandidateToOrigin(job, button.dataset.kiviRun, button.dataset.kiviOriginManual, true).catch(error => setKiviVideoStatus(error.message, 'error'));
    }));
    ui.kiviJobDetail.querySelectorAll('[data-kivi-rerun]').forEach(button => button.addEventListener('click', () => generateKiviJobs([button.dataset.kiviRerun])));
    ui.kiviJobDetail.querySelectorAll('[data-kivi-loop]').forEach(button => button.addEventListener('click', () => {
      const card = button.closest('.kivi-candidate');
      const video = card && card.querySelector('video');
      if (!video) return;
      const active = button.classList.toggle('active');
      ui.kiviJobDetail.querySelectorAll('[data-kivi-loop].active').forEach(other => {
        if (other === button) return;
        stopLoopPreview(other);
      });
      if (!active) {
        video.pause();
        video.loop = false;
        video.playbackRate = 1;
        button.textContent = kiviLoopDurationLabel();
        return;
      }
      const playLoop = () => {
        if (!Number.isFinite(video.duration) || video.duration <= 0) return;
        video.dataset.looping = 'true';
        video.playbackRate = Math.max(0.25, Math.min(16, video.duration / kiviAdoptionDuration));
        video.loop = true;
        video.currentTime = 0;
        button.textContent = '停止循环';
        video.play().catch(() => {});
      };
      if (video.readyState >= 1) playLoop();
      else video.addEventListener('loadedmetadata', playLoop, { once: true });
    }));
    ui.kiviJobDetail.querySelectorAll('.kivi-candidate').forEach(card => {
      const video = card.querySelector('video');
      if (video) video.addEventListener('play', () => {
        ui.kiviJobDetail.querySelectorAll('video').forEach(other => {
          if (other === video) return;
          other.pause();
          other.loop = false;
          other.playbackRate = 1;
          const otherButton = other.closest('.kivi-candidate').querySelector('[data-kivi-loop]');
          if (otherButton) stopLoopPreview(otherButton);
        });
      });
      card.addEventListener('contextmenu', event => {
        const found = findKiviCandidate(job, card.dataset.kiviRun, card.dataset.kiviCandidate);
        const revealPath = kiviCandidateFile(found.candidate);
        showPanelContextMenu(event, [{ label: '在资源管理器中显示', disabled: !revealPath, run: () => openInExplorer(revealPath) }]);
      });
    });
    const purgeRejected = ui.kiviJobDetail.querySelector('[data-kivi-purge-rejected]');
    if (purgeRejected) purgeRejected.addEventListener('click', () => {
      purgeRejectedKiviCandidates(job).catch(error => setKiviVideoStatus(error.message, 'error'));
    });
    ui.kiviJobDetail.querySelectorAll('[data-kivi-reject]').forEach(button => button.addEventListener('click', () => {
      const found = findKiviCandidate(job, button.dataset.kiviRun, button.dataset.kiviReject);
      if (!found.candidate) return;
      if (found.candidate.status === 'rejected') {
        found.candidate.status = found.candidate.rejectedFromStatus === 'accepted' ? 'accepted' : 'ready';
        found.candidate.rejectedFromStatus = '';
        found.candidate.rejectedAt = 0;
      } else {
        found.candidate.rejectedFromStatus = found.candidate.status === 'accepted' ? 'accepted' : 'ready';
        found.candidate.status = 'rejected';
        found.candidate.rejectedAt = Date.now();
      }
      job.updatedAt = Date.now();
      kiviStore.save();
      renderKiviWorkbench();
    }));
  }

  async function ensureKiviWorkspace(options) {
    options = options || {};
    if (kiviWorkspaceLoading) return kiviWorkspaceLoading;
    kiviWorkspaceLoading = (async () => {
      const resolved = await resolveProjectStorage(options.selectedPath);
      const importRoot = path.join(resolved.projectRoot, KiviWorkspaceRecovery.IMPORT_DIRECTORY);
      const root = resolved.workspaceRoot;
      if (!options.force && kiviStore && path.resolve(root) === path.resolve(kiviWorkspaceRoot)) {
        renderKiviWorkbench(true);
        return kiviStore;
      }
      if (kiviRunner) kiviRunner.stop();
      if (promptAgentRunner) promptAgentRunner.cancelPending();
      kiviProjectRoot = resolved.projectRoot;
      kiviWorkspaceRoot = root;
      kiviStore = new KiviJobStore(root);
      kiviStore.load();
      const persistKiviStore = kiviStore.save.bind(kiviStore);
      kiviStore.save = function saveAndScheduleUsageSnapshot() {
        const state = persistKiviStore();
        scheduleUsageTelemetry(3000);
        return state;
      };
      const repairs = kiviStore.relinkPaths(importRoot);
      if (resolved.recovered) {
        restoreAcceptedHistoryFromJobs();
        saveImportHistory();
      }
      kiviRunner = new KiviJobRunner({
        store: kiviStore,
        readToken: readKiviCredential,
        createClient: createKiviClient,
        onChange: () => renderKiviWorkbench(true),
        pollIntervalMs: 4000
      });
      promptAgentRunner = new PromptAgentRunner({
        store: kiviStore,
        createProvider: createDeepseekProvider,
        readSkill: () => ensureAgentSkillStore().getActive(),
        concurrency: 3,
        onChange: () => {
          renderKiviWorkbench(true);
          updateButtons();
          renderAgentDebugTasks();
        }
      });
      const selectedJob = kiviStore.findJob(selectedKiviJobId);
      if (!selectedJob || ((kiviQueueView === 'archive') !== !!selectedJob.archivedAt)) {
        const next = firstKiviJobInView();
        selectedKiviJobId = next ? next.id : '';
      }
      renderKiviWorkbench();
      renderAgentDebugTasks();
      kiviRunner.resume();
      const repairedCount = repairs.repairedSources + repairs.repairedCandidates + repairs.repairedAccepted;
      const recoveryNote = resolved.recovered ? '，已连接原工程工作区' : '';
      const repairNote = repairedCount ? `，修复 ${repairedCount} 个文件链接` : '';
      setKiviVideoStatus(kiviStore.state.jobs.length ? `已恢复 ${kiviStore.state.jobs.length} 个任务${recoveryNote}${repairNote}。` : '当前工程尚无 KIVI 视频任务。', 'success');
      return kiviStore;
    })();
    try { return await kiviWorkspaceLoading; }
    finally { kiviWorkspaceLoading = null; }
  }

  async function recoverKiviWorkspace(manual) {
    try {
      let selectedPath = '';
      if (manual) {
        if (!window.cep || !window.cep.fs || !window.cep.fs.showOpenDialog) throw new Error('当前 CEP 环境不支持目录选择器');
        const dialog = window.cep.fs.showOpenDialog(false, true, '选择原工程文件夹、Canvas Bridge 导入或 _KIVI任务工作区');
        if (!dialog || dialog.err !== 0 || !dialog.data || !dialog.data.length) return;
        selectedPath = dialog.data[0];
        const selectedRoot = KiviWorkspaceRecovery.projectRootFromSelection(selectedPath);
        const importRoot = path.join(selectedRoot, KiviWorkspaceRecovery.IMPORT_DIRECTORY);
        if (!fs.existsSync(importRoot)) throw new Error('所选目录中没有“Canvas Bridge 导入”，请改选原工程文件夹或其导入目录');
      }
      setKiviVideoStatus(manual ? '正在验证所选工作区并恢复链接…' : '正在从原工程目录自动恢复任务和素材…');
      await ensureKiviWorkspace({ force: true, selectedPath });
      await reloadImportAssets();
      const restored = restoreAcceptedHistoryFromJobs();
      saveImportHistory();
      const aePaths = [...new Set(importHistory.filter(item => item.nodeType === 'video' && item.folderName === 'Kivi Videos' && item.localPath && fs.existsSync(item.localPath)).map(item => item.localPath))];
      const aeRaw = await evalScript(`CanvasBridge.relinkKiviAssets(${quote(JSON.stringify({ paths: aePaths }))})`);
      const aeRecovery = parseEvalJson(aeRaw, '恢复 AE 项目素材');
      if (!aeRecovery.ok) throw new Error(aeRecovery.error);
      refreshImportDirectoryLabel();
      setKiviVideoStatus(`恢复完成：${kiviStore.state.jobs.length} 个任务，${restored} 个已采用素材，AE 重连 ${aeRecovery.relinked || 0}、补导入 ${aeRecovery.imported || 0}。`, 'success');
    } catch (error) {
      setKiviVideoStatus(`恢复失败：${error.message}`, 'error');
    }
  }

  async function prepareKiviVideoAssets(items) {
    const targets = Array.isArray(items) ? items.filter(item => selectionItems.some(source => String(source.id) === String(item.id))) : selectionItems;
    if (!previewReady || !targets.length) {
      setKiviVideoStatus('请先在“预览导出”完成至少一张图片的排版预览。', 'error');
      return;
    }
    if (busy) return;
    busy = true;
    updateButtons();
    setKiviVideoStatus('正在渲染当前排版并创建独立任务…');
    let rendered = [];
    try {
      await ensureKiviWorkspace();
      rendered = await renderFinalAssets(targets);
      const created = kiviStore.addRenderedAssets(rendered);
      created.forEach(job => { job.selected = true; });
      kiviStore.save();
      kiviQueueView = 'queue';
      localStorage.setItem('canvasBridgeKiviQueueView', kiviQueueView);
      selectedKiviJobId = created.length ? created[0].id : selectedKiviJobId;
      switchModule('kivi-video');
      renderKiviWorkbench();
      setKiviVideoStatus(`已添加 ${created.length} 个任务。它们已选中，可逐项填写提示词后单独或批量生成。`, 'success');
    } catch (error) {
      setKiviVideoStatus(error.message || '无法创建 KIVI 视频任务。请先保存 AE 工程。', 'error');
    } finally {
      rendered.forEach(asset => safeUnlink(asset.path));
      busy = false;
      ui.batchProgress.textContent = '';
      ui.progress.classList.add('hidden');
      updateButtons();
    }
  }

  async function saveKiviCredential() {
    const token = ui.kiviKeyInput && ui.kiviKeyInput.value ? ui.kiviKeyInput.value.trim() : '';
    if (!token) {
      setKiviVideoStatus('请输入新的 KIVI Key。', 'error');
      return;
    }
    if (token.length < 24) {
      setKiviVideoStatus('KIVI Key 长度异常，请确认后重试。', 'error');
      return;
    }
    try {
      await runKiviCredential('set', token);
      ui.kiviKeyInput.value = '';
      if (kiviRunner) kiviRunner.resetClient();
      kiviVideoModelsLoaded = false;
      await refreshKiviCredentialState();
      await refreshKiviVideoModels(true);
      setKiviVideoStatus('KIVI Key 已在当前 Windows 用户下加密保存。', 'success');
    } catch (error) {
      setKiviVideoStatus(error.message || 'KIVI Key 保存失败。', 'error');
    }
  }

  async function clearKiviCredential() {
    try {
      await runKiviCredential('clear');
      if (kiviRunner) kiviRunner.resetClient();
      kiviVideoModels = fallbackKiviVideoModels.slice();
      kiviVideoModelsLoaded = false;
      await refreshKiviCredentialState();
      renderKiviWorkbench(true);
      setKiviVideoStatus('已清除本机 KIVI Key。');
    } catch (error) {
      setKiviVideoStatus(error.message || 'KIVI Key 清除失败。', 'error');
    }
  }

  async function generateAgentPrompts(jobIds, onlyBlank) {
    try {
      await ensureKiviWorkspace();
      const skill = ensureAgentSkillStore().getActive();
      if (!skill) throw new Error('请先在“Agent 调试”中导入并启用 Markdown Skill');
      if (!deepseekCredentialConfigured) throw new Error('请先在“Agent 调试”中安全保存 DeepSeek API Key');
      const ids = [...new Set(jobIds || [])].filter(id => {
        const job = kiviStore.findJob(id);
        if (!job) return false;
        if (onlyBlank && (deriveJobStatus(job) !== 'draft' || String(job.prompt || '').trim())) return false;
        return !['queued', 'analyzing'].includes(job.promptState && job.promptState.status);
      });
      if (!ids.length) throw new Error(onlyBlank ? '没有“草稿且 Prompt 为空”的任务' : '没有可生成 Prompt 的任务');
      setKiviVideoStatus(`Agent 已开始分析 ${ids.length} 个任务，最多并发 3 个…`);
      updateButtons();
      const results = await promptAgentRunner.startJobs(ids, { onlyBlank });
      const completed = results.filter(result => result.status === 'fulfilled').length;
      const failed = results.filter(result => result.status === 'rejected').length;
      const cancelled = ids.length - completed - failed;
      renderKiviWorkbench();
      renderAgentDebugTasks();
      setKiviVideoStatus(`Prompt 完成 ${completed} 个${failed ? `，失败 ${failed} 个` : ''}${cancelled ? `，取消 ${cancelled} 个` : ''}。`, failed ? 'error' : 'success');
    } catch (error) {
      setKiviVideoStatus(error.message || 'Prompt 生成失败。', 'error');
    } finally { updateButtons(); }
  }

  async function generateKiviJobs(jobIds) {
    try {
      await ensureKiviWorkspace();
      const requested = [...new Set(jobIds || [])].map(id => kiviStore.findJob(id)).filter(Boolean);
      const blank = requested.filter(job => !String(job.prompt || '').trim());
      if (blank.length) throw new Error(`${blank.length} 个任务的 Prompt 为空，请先填写或使用 Agent 生成 Prompt`);
      const promptBusy = requested.filter(job => ['queued', 'analyzing'].includes(job.promptState && job.promptState.status));
      if (promptBusy.length) throw new Error(`${promptBusy.length} 个任务正在生成 Prompt，请等待完成后再生成视频`);
      const ids = [...new Set(jobIds || [])].filter(id => {
        const job = kiviStore.findJob(id);
        return job && deriveJobStatus(job) !== 'generating';
      });
      if (!ids.length) throw new Error('没有可生成的任务');
      setKiviVideoStatus(`正在提交 ${ids.length} 个任务，提交后将由 KIVI 并行处理…`);
      const results = await kiviRunner.startJobs(ids);
      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          const job = kiviStore.findJob(ids[index]);
          if (job) job.selected = false;
        }
      });
      kiviStore.save();
      renderKiviWorkbench();
      const failed = results.filter(result => result.status === 'rejected').length;
      setKiviVideoStatus(failed ? `${ids.length - failed} 个任务已提交，${failed} 个提交失败，可在失败任务中重试。` : `${ids.length} 个任务已提交，正在 KIVI 云端生成。`, failed ? 'error' : 'success');
    } catch (error) {
      setKiviVideoStatus(error.message || 'KIVI 视频任务提交失败。', 'error');
    }
  }

  ui.loadSelection.addEventListener('click', () => loadSelection(true));
  if (ui.clearSelection) ui.clearSelection.addEventListener('click', () => clearPreviewPanelToArchive().catch(error => setStatus(error.message, 'error')));
  if (ui.previewActiveTab) ui.previewActiveTab.addEventListener('click', () => switchPreviewView('active'));
  if (ui.previewArchiveTab) ui.previewArchiveTab.addEventListener('click', () => switchPreviewView('archive'));
  if (ui.restoreAllPreviewArchive) ui.restoreAllPreviewArchive.addEventListener('click', () => restorePreviewEntries(previewArchiveEntries().map(entry => entry.id)));
  if (ui.deleteAllPreviewArchive) ui.deleteAllPreviewArchive.addEventListener('click', () => deleteAllPreviewArchive().catch(error => setStatus(error.message, 'error')));
  if (ui.preview) ui.preview.addEventListener('click', generatePreviews);
  if (ui.previewZoom) ui.previewZoom.addEventListener('input', updatePreviewZoom);
  if (ui.previewSection) ui.previewSection.addEventListener('wheel', zoomPreviewWithWheel, { passive: false });
  if (ui.importHistory) ui.importHistory.addEventListener('wheel', zoomImportAssetsWithWheel, { passive: false });
  if (ui.kiviJobList) ui.kiviJobList.addEventListener('wheel', zoomKiviTasksWithWheel, { passive: false });
  if (ui.kiviJobDetail) ui.kiviJobDetail.addEventListener('wheel', zoomKiviResultsWithWheel, { passive: false });
  ui.send.addEventListener('click', exportAndSend);
  ui.localExport.addEventListener('click', exportToLocal);
  ui.eagleExport.addEventListener('click', exportToEagle);
  ui.browseExportPath.addEventListener('click', chooseExportDirectory);
  ui.exportPath.value = localStorage.getItem('canvasBridgeExportPath') || '';
  ui.exportPath.addEventListener('change', () => localStorage.setItem('canvasBridgeExportPath', ui.exportPath.value.trim()));
  ui.retry.addEventListener('click', retryRemaining);
  ui.sizePresets.addEventListener('click', event => {
    const button = event.target.closest('button[data-size]');
    if (!button) return;
    selectedSize = button.dataset.size;
    for (const item of ui.sizePresets.querySelectorAll('button')) item.classList.toggle('active', item === button);
    ui.customSize.classList.toggle('hidden', selectedSize !== 'custom');
    applyGlobalSettingsToAll();
  });
  ui.customWidth.addEventListener('change', applyGlobalSettingsToAll);
  ui.customHeight.addEventListener('change', applyGlobalSettingsToAll);
  ui.backgroundMode.addEventListener('change', () => { ui.customColorRow.classList.toggle('hidden', ui.backgroundMode.value !== 'custom'); applyGlobalSettingsToAll(); });
  ui.customColor.addEventListener('input', () => { ui.customColorText.value = ui.customColor.value.toUpperCase(); applyGlobalSettingsToAll(); });
  ui.customColorText.addEventListener('change', () => { if (/^#[0-9a-fA-F]{6}$/.test(ui.customColorText.value)) ui.customColor.value = ui.customColorText.value; applyGlobalSettingsToAll(); });
  ui.moduleTabs.forEach(button => button.addEventListener('click', () => switchModule(button.dataset.module)));
  if (ui.kiviLoopDuration) {
    ui.kiviLoopDuration.addEventListener('click', event => {
      const button = event.target.closest('[data-loop-duration]');
      if (button) setKiviAdoptionDuration(button.dataset.loopDuration, true);
    });
    setKiviAdoptionDuration(2, false);
  }
  if (ui.importSortMode) {
    ui.importSortMode.value = localStorage.getItem('canvasBridgeImportSortMode') || 'recent';
    ui.importSortMode.addEventListener('change', () => {
      localStorage.setItem('canvasBridgeImportSortMode', ui.importSortMode.value);
      renderImportHistory();
    });
  }
  [ui.importFormatFilter, ui.importRatingFilter, ui.importLayoutMode, ui.importVideoSound].forEach(control => {
    if (!control) return;
    const key = `canvasBridge${control.id}`;
    if (control.type === 'checkbox') control.checked = localStorage.getItem(key) === 'true';
    else if (localStorage.getItem(key)) control.value = localStorage.getItem(key);
    control.addEventListener('change', () => {
      localStorage.setItem(key, control.type === 'checkbox' ? String(control.checked) : control.value);
      renderImportHistory();
    });
  });
  if (ui.toggleImportInfo) ui.toggleImportInfo.addEventListener('click', () => {
    ui.importInfoPanel.classList.toggle('hidden');
    ui.toggleImportInfo.textContent = ui.importInfoPanel.classList.contains('hidden') ? '详情' : '收起';
  });
  if (ui.reloadImportAssets) ui.reloadImportAssets.addEventListener('click', reloadImportAssets);
  if (ui.externalImportAssets) ui.externalImportAssets.addEventListener('click', importExternalAssets);
  if (ui.batchImportEagle) ui.batchImportEagle.addEventListener('click', () => runImportBatch('eagle').catch(error => setImportStatus(error.message, 'error')));
  if (ui.batchExportLocal) ui.batchExportLocal.addEventListener('click', () => runImportBatch('local').catch(error => setImportStatus(error.message, 'error')));
  if (ui.checkUpdate) ui.checkUpdate.addEventListener('click', () => checkForUpdates(true));
  if (ui.installUpdate) ui.installUpdate.addEventListener('click', installLatestUpdate);
  if (ui.prepareKiviVideoAssets) ui.prepareKiviVideoAssets.addEventListener('click', () => prepareKiviVideoAssets());
  if (ui.queueKiviVideo) ui.queueKiviVideo.addEventListener('click', () => prepareKiviVideoAssets());
  if (ui.kiviJobFilter) ui.kiviJobFilter.addEventListener('change', renderKiviWorkbench);
  function switchKiviQueueView(view) {
    kiviQueueView = view === 'archive' ? 'archive' : 'queue';
    localStorage.setItem('canvasBridgeKiviQueueView', kiviQueueView);
    const next = firstKiviJobInView();
    selectedKiviJobId = next ? next.id : '';
    renderKiviWorkbench();
  }
  if (ui.kiviQueueTab) ui.kiviQueueTab.addEventListener('click', () => switchKiviQueueView('queue'));
  if (ui.kiviArchiveTab) ui.kiviArchiveTab.addEventListener('click', () => switchKiviQueueView('archive'));
  if (ui.archiveAllKiviJobs) ui.archiveAllKiviJobs.addEventListener('click', () => archiveAllKiviJobs().catch(error => setKiviVideoStatus(error.message, 'error')));
  if (ui.purgeUnusedKiviMedia) ui.purgeUnusedKiviMedia.addEventListener('click', () => purgeUnusedKiviMedia().catch(error => setKiviVideoStatus(error.message, 'error')));
  if (ui.restoreAllArchivedJobs) ui.restoreAllArchivedJobs.addEventListener('click', restoreAllArchivedJobs);
  if (ui.deleteAllArchivedJobs) ui.deleteAllArchivedJobs.addEventListener('click', () => permanentlyDeleteArchivedJobs(kiviStore ? kiviStore.state.jobs.filter(job => job.archivedAt) : []).catch(error => setKiviVideoStatus(error.message, 'error')));
  if (ui.kiviJobSort) {
    ui.kiviJobSort.value = localStorage.getItem('canvasBridgeKiviJobSort') || 'recent';
    ui.kiviJobSort.addEventListener('change', () => {
      localStorage.setItem('canvasBridgeKiviJobSort', ui.kiviJobSort.value);
      renderKiviWorkbench();
    });
  }
  if (ui.kiviSelectAll) ui.kiviSelectAll.addEventListener('change', () => {
    if (!kiviStore) return;
    visibleKiviJobs().forEach(job => { job.selected = ui.kiviSelectAll.checked; job.updatedAt = Date.now(); });
    kiviStore.save();
    renderKiviJobList();
  });
  if (ui.generateSelectedKiviJobs) ui.generateSelectedKiviJobs.addEventListener('click', () => {
    generateKiviJobs(kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt && job.selected).map(job => job.id) : []);
  });
  if (ui.generateDraftPrompts) ui.generateDraftPrompts.addEventListener('click', () => {
    generateAgentPrompts(kiviStore ? kiviStore.state.jobs.filter(job => !job.archivedAt).map(job => job.id) : [], true);
  });
  if (ui.cancelPromptBatch) ui.cancelPromptBatch.addEventListener('click', () => {
    const cancelled = promptAgentRunner ? promptAgentRunner.cancelPending() : 0;
    setKiviVideoStatus(cancelled ? `已取消 ${cancelled} 个尚未开始的 Prompt 请求；正在分析的任务会安全结束。` : '没有尚未开始的 Prompt 请求。');
    updateButtons();
  });
  if (ui.autoRecoverKiviWorkspace) ui.autoRecoverKiviWorkspace.addEventListener('click', () => recoverKiviWorkspace(false));
  if (ui.chooseKiviWorkspace) ui.chooseKiviWorkspace.addEventListener('click', () => recoverKiviWorkspace(true));
  if (ui.saveKiviKey) ui.saveKiviKey.addEventListener('click', saveKiviCredential);
  if (ui.clearKiviKey) ui.clearKiviKey.addEventListener('click', clearKiviCredential);
  if (ui.saveDeepseekKey) ui.saveDeepseekKey.addEventListener('click', saveDeepseekCredential);
  if (ui.clearDeepseekKey) ui.clearDeepseekKey.addEventListener('click', clearDeepseekCredential);
  if (ui.testDeepseekConnection) ui.testDeepseekConnection.addEventListener('click', testDeepseekConnection);
  if (ui.agentSkillSelect) ui.agentSkillSelect.addEventListener('change', () => {
    try { if (ui.agentSkillSelect.value) ensureAgentSkillStore().activate(ui.agentSkillSelect.value); renderAgentSkillManager(); renderAgentDebugTasks(); }
    catch (error) { setAgentProviderStatus(error.message, 'error'); }
  });
  if (ui.importAgentSkill) ui.importAgentSkill.addEventListener('click', importAgentSkill);
  if (ui.duplicateAgentSkill) ui.duplicateAgentSkill.addEventListener('click', duplicateAgentSkill);
  if (ui.exportAgentSkill) ui.exportAgentSkill.addEventListener('click', exportAgentSkill);
  if (ui.deleteAgentSkill) ui.deleteAgentSkill.addEventListener('click', deleteAgentSkill);
  if (ui.saveAgentSkill) ui.saveAgentSkill.addEventListener('click', saveAgentSkill);
  if (ui.reloadAgentSkill) ui.reloadAgentSkill.addEventListener('click', renderAgentSkillManager);
  if (ui.agentSkillCard) {
    ui.agentSkillCard.open = localStorage.getItem('canvasBridgeAgentSkillOpen') === 'true';
    ui.agentSkillCard.addEventListener('toggle', () => localStorage.setItem('canvasBridgeAgentSkillOpen', ui.agentSkillCard.open ? 'true' : 'false'));
  }
  if (ui.agentDebugTask) ui.agentDebugTask.addEventListener('change', updateAgentDebugSummary);
  if (ui.runAgentDebug) ui.runAgentDebug.addEventListener('click', runAgentDebug);
  if (ui.agentDebugFeedback) {
    ui.agentDebugFeedback.addEventListener('input', renderAgentDebugConversation);
    ui.agentDebugFeedback.addEventListener('keydown', event => {
      if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        continueAgentDebugConversation();
      }
    });
  }
  if (ui.sendAgentDebugFeedback) ui.sendAgentDebugFeedback.addEventListener('click', continueAgentDebugConversation);
  if (ui.applyAgentDebugPrompt) ui.applyAgentDebugPrompt.addEventListener('click', applyAgentDebugPrompt);
  if (ui.clearAgentDebugConversation) ui.clearAgentDebugConversation.addEventListener('click', clearAgentDebugConversation);
  if (ui.usageReportingToggle) ui.usageReportingToggle.addEventListener('change', () => {
    if (!usageTelemetry || !usageTelemetry.isConfigured()) {
      ui.usageReportingToggle.checked = false;
      refreshUsageReportingUi('公司内部 Relay 尚未配置。', 'error');
      return;
    }
    usageTelemetry.setConsent(ui.usageReportingToggle.checked);
    if (usageTelemetry.isEnabled()) {
      startProjectSaveMonitor();
    } else {
      if (usageTelemetryTimer) clearTimeout(usageTelemetryTimer);
      usageTelemetryTimer = null;
      if (projectSaveMonitor) clearInterval(projectSaveMonitor);
      projectSaveMonitor = null;
      lastProjectSaveSignature = '';
    }
    refreshUsageReportingUi();
  });
  if (ui.usageReportingSync) ui.usageReportingSync.addEventListener('click', () => {
    captureAndFlushUsageTelemetry(true).catch(() => {});
  });
  ui.clearImportHistory.addEventListener('click', () => { importHistory = []; saveImportHistory(); setImportStatus('已清空导入记录'); });

  window.addEventListener('beforeunload', () => { clearPreviews(); for (const asset of lastRetryAssets) safeUnlink(asset.path); if (kiviCountdownTimer) clearInterval(kiviCountdownTimer); if (usageTelemetryTimer) clearTimeout(usageTelemetryTimer); if (projectSaveMonitor) clearInterval(projectSaveMonitor); if (promptAgentRunner) promptAgentRunner.cancelPending(); if (kiviRunner) kiviRunner.stop(); server.stop(); });
  cleanupEagleStaging();
  loadImportHistory();
  switchModule(localStorage.getItem('canvasBridgeKiviVideoDevActiveModule') || 'export');
  refreshImportDirectoryLabel();
  switchPreviewView(previewView);
  updatePreviewZoom();
  applyImportAssetZoom();
  applyKiviResultZoom();
  applyKiviTaskZoom();
  bindVerticalResizer(ui.kiviQueueResizer, ui.kiviJobList, 'canvasBridgeKiviQueueHeight', 320, 180, 720);
  if (ui.currentAeVersion) {
    ui.currentAeVersion.textContent = CURRENT_AE_VERSION;
    setTimeout(() => checkForUpdates(false), 1500);
  }
  refreshKiviCredentialState();
  initializeUsageTelemetry().catch(error => refreshUsageReportingUi(`统计模块初始化失败：${error.message}`, 'error'));
  ensureAgentSkillStore();
  renderAgentSkillManager();
  refreshDeepseekCredentialState().then(renderAgentDebugTasks);
  ensureKiviWorkspace().catch(error => setKiviVideoStatus(error.message || '请先保存 AE 工程。', 'error'));
  server.start().then(() => loadSelection(false)).catch(error => setStatus(`本机服务启动失败：${error.message}`, 'error'));
}());
